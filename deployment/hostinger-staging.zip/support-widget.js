(function(){
  var cfg=window.SUP_CFG;if(!cfg)return;
  var last=0,open=false,needName=cfg.guest,timer=null,unread=0;
  var css='.supw-btn{position:fixed;bottom:20px;left:20px;z-index:9998;width:58px;height:58px;border-radius:50%;border:0;background:var(--primary);color:var(--on-primary,#fff);box-shadow:0 8px 24px rgba(0,0,0,.25);cursor:pointer;display:grid;place-items:center}'+
  '.supw-btn .supw-dot{position:absolute;top:2px;right:2px;min-width:18px;height:18px;border-radius:9px;background:#e5484d;color:#fff;font-size:11px;display:none;place-items:center;padding:0 4px}'+
  '.supw{position:fixed;bottom:90px;left:20px;z-index:9999;width:340px;max-width:calc(100vw - 30px);height:480px;max-height:calc(100vh - 120px);background:var(--surface,#fff);color:var(--ink,#111);border:1px solid var(--border,#ddd);border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.3);display:none;flex-direction:column;overflow:hidden;font-family:inherit}'+
  '.supw.open{display:flex}.supw-h{background:var(--primary);color:var(--on-primary,#fff);padding:14px 16px;display:flex;justify-content:space-between;align-items:center}.supw-h b{font-size:15px}.supw-h small{display:block;opacity:.85;font-size:12px}'+
  '.supw-h button{background:transparent;border:0;color:inherit;font-size:22px;cursor:pointer;line-height:1}'+
  '.supw-m{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px;background:var(--bg,#f5f5f5)}'+
  '.supw-b{max-width:80%;padding:8px 12px;border-radius:14px;font-size:14px;line-height:1.6;white-space:pre-wrap;word-break:break-word}'+
  '.supw-b.user{align-self:flex-end;background:var(--primary);color:var(--on-primary,#fff)}.supw-b.admin{align-self:flex-start;background:var(--surface,#fff);border:1px solid var(--border,#ddd)}'+
  '.supw-b small{display:block;font-size:10px;opacity:.65}.supw-n{display:flex;flex-direction:column;gap:6px;padding:10px 12px 0}'+
  '.supw input,.supw textarea{border:1px solid var(--border,#ddd);border-radius:10px;padding:8px 10px;font:inherit;font-size:14px;background:var(--surface,#fff);color:var(--ink,#111)}'+
  '.supw-f{display:flex;gap:6px;padding:10px 12px}.supw-f textarea{flex:1;resize:none;height:42px}.supw-f button{border:0;border-radius:10px;background:var(--primary);color:var(--on-primary,#fff);padding:0 14px;cursor:pointer;font:inherit}'+
  '.supw-e{color:#e5484d;font-size:12px;padding:0 12px}.supw-hint{text-align:center;color:var(--muted,#777);font-size:13px;margin:auto;padding:20px}';
  var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
  var btn=document.createElement('button');btn.className='supw-btn';btn.setAttribute('aria-label','الدعم الفني');
  btn.innerHTML='<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span class="supw-dot"></span>';
  var w=document.createElement('div');w.className='supw';w.setAttribute('role','dialog');w.setAttribute('aria-label','الدعم الفني');
  w.innerHTML='<div class="supw-h"><div><b>الدعم الفني</b><small>نرد عليك في أقرب وقت</small></div><button type="button" aria-label="إغلاق">×</button></div>'+
   '<div class="supw-m"><div class="supw-hint">أهلًا 👋 كيف نقدر نساعدك؟</div></div>'+
   '<div class="supw-n"'+(needName?'':' style="display:none"')+'><input class="supw-name" maxlength="80" placeholder="اسمك"><input class="supw-mail" type="email" maxlength="190" placeholder="بريدك (اختياري)"></div>'+
   '<div class="supw-e"></div><form class="supw-f"><textarea maxlength="2000" placeholder="اكتب رسالتك…"></textarea><button>إرسال</button></form>';
  document.body.appendChild(btn);document.body.appendChild(w);
  var box=w.querySelector('.supw-m'),ta=w.querySelector('textarea'),err=w.querySelector('.supw-e'),dot=btn.querySelector('.supw-dot'),nameBox=w.querySelector('.supw-n');
  function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML}
  function render(ms){if(ms.length&&!last)box.innerHTML='';ms.forEach(function(m){last=Math.max(last,+m.id);var el=document.createElement('div');el.className='supw-b '+m.sender;el.innerHTML=esc(m.body)+'<small>'+esc(m.created_at.slice(11,16))+'</small>';box.appendChild(el);if(!open&&m.sender==='admin')unread++});if(ms.length)box.scrollTop=box.scrollHeight;dot.style.display=unread?'grid':'none';dot.textContent=unread}
  function poll(){fetch(cfg.url+'?a=poll&after='+last,{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){if(!d.ok)return;needName=d.need_name;nameBox.style.display=needName?'flex':'none';render(d.messages)}).catch(function(){})}
  function schedule(){clearInterval(timer);timer=setInterval(poll,open?3000:15000)}
  btn.onclick=function(){open=!open;w.classList.toggle('open',open);if(open){unread=0;dot.style.display='none';poll();ta.focus()}schedule()};
  w.querySelector('.supw-h button').onclick=function(){btn.onclick()};
  w.querySelector('form').addEventListener('submit',function(e){e.preventDefault();var v=ta.value.trim();if(!v)return;err.textContent='';var fd=new FormData();fd.append('body',v);fd.append('csrf',cfg.csrf);
    if(needName){var n=w.querySelector('.supw-name').value.trim();if(!n){err.textContent='اكتب اسمك أولًا';return}fd.append('name',n);fd.append('email',w.querySelector('.supw-mail').value.trim())}
    fetch(cfg.url+'?a=send&after='+last,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){if(!d.ok){err.textContent=d.error||'تعذر الإرسال';return}ta.value='';needName=false;nameBox.style.display='none';render(d.messages)}).catch(function(){err.textContent='تعذر الاتصال'})});
  ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();w.querySelector('form').requestSubmit()}});
  poll();schedule();
})();
