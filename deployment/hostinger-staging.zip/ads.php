<?php require 'inc.php';
header('Content-Type: text/plain; charset=utf-8');
$p=ads_pub();
if($p==='') { http_response_code(404); exit; }
echo "google.com, pub-$p, DIRECT, f08c47fec0942fa0\n";
