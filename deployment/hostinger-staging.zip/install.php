<?php
$installed=file_exists(__DIR__.'/config.php');
$err=''; $done=false;
if (!$installed && $_SERVER['REQUEST_METHOD']==='POST') {
  try {
    $host=trim($_POST['host']??''); $db=trim($_POST['name']??''); $dbu=trim($_POST['user']??''); $dbp=(string)($_POST['pass']??'');
    $u=strtolower(trim($_POST['a_user']??'')); $an=trim($_POST['a_name']??''); $ae=strtolower(trim($_POST['a_email']??'')); $ap=(string)($_POST['a_pass']??'');
    if(!preg_match('/^[a-z0-9_]{3,30}$/',$u)) throw new Exception('اسم مستخدم المدير غير صالح (٣–٣٠ حرفًا إنجليزيًا أو رقمًا أو _)');
    if(mb_strlen($an)<2) throw new Exception('اكتب الاسم الظاهر للمدير');
    if(!filter_var($ae,FILTER_VALIDATE_EMAIL)) throw new Exception('بريد المدير غير صالح');
    if(strlen($ap)<8) throw new Exception('كلمة مرور المدير ٨ أحرف على الأقل');
    if(!is_writable(__DIR__)) throw new Exception('المجلد غير قابل للكتابة — اضبط صلاحيات المجلد على 755 ثم أعد المحاولة');
    $pdo=new PDO('mysql:host='.$host.';dbname='.$db.';charset=utf8mb4',$dbu,$dbp,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    foreach (array_filter(array_map('trim', explode(';', file_get_contents(__DIR__.'/schema.sql')))) as $q) $pdo->exec($q);
    $pdo->prepare('INSERT INTO users(username,display_name,email,password_hash,is_admin) VALUES(?,?,?,?,1)')->execute([$u,$an,$ae,password_hash($ap,PASSWORD_DEFAULT)]);
    $site=trim($_POST['site']??'') ?: 'أسرار';
    $cfg="<?php\ndefine('DB_HOST', ".var_export($host,true).");\ndefine('DB_NAME', ".var_export($db,true).");\ndefine('DB_USER', ".var_export($dbu,true).");\ndefine('DB_PASS', ".var_export($dbp,true).");\ndefine('SITE_NAME', ".var_export($site,true).");\n";
    if(!file_put_contents(__DIR__.'/config.php',$cfg)) throw new Exception('تعذر كتابة config.php — تأكد من صلاحيات المجلد');
    $done=true;
  } catch (PDOException $t) { $err='تعذر الاتصال بقاعدة البيانات: '.$t->getMessage(); }
    catch (Throwable $t) { $err=$t->getMessage(); }
}
function v($k,$d=''){return htmlspecialchars((string)($_POST[$k]??$d),ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>تثبيت أسرار</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap"><link rel="stylesheet" href="style.css?v=6"></head>
<body class="install-page"><main class="install">
  <div class="install-brand"><span class="brand-mark">أ</span><span class="brand-name">أسرار</span></div>
  <div class="install-card">
  <?php if($installed && !$done): ?>
    <h1>السكربت مثبت بالفعل</h1>
    <div class="alert err" role="alert"><span>لأمان موقعك احذف ملف <b>install.php</b> من الاستضافة الآن.</span></div>
    <a class="btn block" href="index.php">الذهاب للموقع</a>
  <?php elseif($done): ?>
    <div class="sent"><span class="sent-icon"><svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>
    <h1>تم التثبيت بنجاح</h1><p>تم إنشاء الجداول وحساب المدير. <b>احذف ملف install.php الآن</b> لحماية موقعك.</p>
    <a class="btn lg block" href="auth.php?m=login">تسجيل الدخول كمدير</a></div>
  <?php else: ?>
    <h1>تثبيت السكربت</h1>
    <p class="muted">أدخل بيانات قاعدة MySQL التي أنشأتها من لوحة الاستضافة، ثم بيانات حساب المدير.</p>
    <?php if($err): ?><div class="alert err" role="alert"><span><?=htmlspecialchars($err)?></span></div><?php endif; ?>
    <form method="post" class="form">
      <fieldset><legend><span class="step-dot">١</span> قاعدة البيانات</legend>
        <div class="grid-2">
          <div class="field"><label for="host">الخادم</label><input id="host" name="host" dir="ltr" value="<?=v('host','localhost')?>" required></div>
          <div class="field"><label for="name">اسم القاعدة</label><input id="name" name="name" dir="ltr" value="<?=v('name')?>" required></div>
          <div class="field"><label for="user">مستخدم القاعدة</label><input id="user" name="user" dir="ltr" value="<?=v('user')?>" required></div>
          <div class="field"><label for="pass">كلمة مرور القاعدة</label><input id="pass" name="pass" type="password" dir="ltr"></div>
        </div>
      </fieldset>
      <fieldset><legend><span class="step-dot">٢</span> الموقع وحساب المدير</legend>
        <div class="field"><label for="site">اسم الموقع</label><input id="site" name="site" value="<?=v('site','أسرار')?>"></div>
        <div class="grid-2">
          <div class="field"><label for="a_name">الاسم الظاهر</label><input id="a_name" name="a_name" value="<?=v('a_name')?>" required></div>
          <div class="field"><label for="a_user">اسم المستخدم (إنجليزي)</label><input id="a_user" name="a_user" dir="ltr" value="<?=v('a_user')?>" required></div>
          <div class="field"><label for="a_email">البريد الإلكتروني</label><input id="a_email" name="a_email" type="email" dir="ltr" value="<?=v('a_email')?>" required></div>
          <div class="field"><label for="a_pass">كلمة المرور</label><input id="a_pass" name="a_pass" type="password" dir="ltr" minlength="8" required></div>
        </div>
      </fieldset>
      <button class="btn lg block">تثبيت الآن</button>
    </form>
  <?php endif; ?>
  </div>
</main></body></html>
