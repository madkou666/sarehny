<?php require 'inc.php';
$k=(string)($_GET['set']??''); $p=theme_presets();
if($k!=='' && isset($p[$k])) setcookie('site_theme',$k,['expires'=>time()+31536000,'path'=>'/','samesite'=>'Lax','httponly'=>true]);
else setcookie('site_theme','',['expires'=>time()-3600,'path'=>'/']);
$r=(string)($_GET['r']??'index.php');
if($r==='' || !preg_match('#^/[^/\\\\]#',$r) && !preg_match('#^[a-z0-9_]+\.php#i',$r)) $r='index.php';
header('Location: '.$r); exit;
