<?php
if(($_SERVER['REQUEST_METHOD']??'')==='POST'&&(string)($_POST['action']??'')==='analyze'){
  if(is_file(__DIR__.'/ai_analyze.php')){require __DIR__.'/ai_analyze.php';exit;}
  http_response_code(500);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'message'=>'ملف ai_analyze.php غير موجود على الخادم. ارفعه ثم حاول مجددًا.'],JSON_UNESCAPED_UNICODE);exit;
}
require __DIR__.'/inc.php';
require_once __DIR__.'/ai_module.php';
$user=require_login();
ai_ensure_schema();
$limits=ai_limits();
$quota=ai_quota_snapshot((int)$user['id']);
$eligible=$pdo->prepare("SELECT COUNT(*) FROM messages WHERE recipient_id=? AND is_removed=0 AND (audio_path IS NULL OR audio_path='') AND TRIM(body)<>'' AND body<>'🎙️ رسالة صوتية'");
$eligible->execute([(int)$user['id']]);
$messageCount=(int)$eligible->fetchColumn();
$enabled=ai_api_enabled();
$apiReady=ai_service_ready();
$canStart=$enabled&&$apiReady&&$messageCount>0&&$quota['remaining']>0&&$quota['wait_seconds']===0;
[$previewMessages]=$messageCount>0?ai_get_eligible_messages((int)$user['id']):[[],[]];
$localStats=ai_local_stats($previewMessages);
$history=ai_user_history((int)$user['id'],6);
$latestSaved=null; foreach($history as $h){ if($h['result']){ $latestSaved=['result'=>$h['result'],'analyzed_at'=>$h['created_at']]; break; } }
$boot=['history'=>array_reverse(array_map(function($h){return ['score'=>$h['score'],'created_at'=>$h['created_at']];},$history)),'latest'=>$latestSaved,'stats'=>$localStats,'dimensions'=>ai_dimension_keys()];
head('تحليل شخصيتك ومدى محبتك لدى الآخرين','app dashboard-glass');
?>
<section class="page ai-page" id="main-content">
  <div class="wrap ai-wrap">
    <nav class="ai-breadcrumb" aria-label="مسار التنقل"><a href="dashboard.php">صندوق الرسائل</a><span aria-hidden="true">/</span><span aria-current="page">تحليل شخصيتك</span></nav>
    <section class="ai-hero" aria-labelledby="ai-title">
      <div class="ai-hero-orb" aria-hidden="true"></div>
      <div class="ai-hero-content">
        <span class="ai-eyebrow"><span class="ai-spark" aria-hidden="true">✦</span> قراءة لطيفة من رسائلك</span>
        <h1 id="ai-title">هل أنت شخص محبوب؟ <span aria-hidden="true">❤️</span></h1>
        <p>اكتشف الانطباع الذي تتركه رسائلك، وما يتكرر فيها من نقاط قوة وصفات إيجابية.</p>
        <div class="ai-hero-meta"><span><?=ar_num(min($messageCount,$limits['max_messages']))?> رسالة نصية مؤهلة</span><span aria-hidden="true">·</span><span>تحليل واحد لا يستغرق سوى لحظات</span></div>
      </div>
      <div class="ai-heart-art" aria-hidden="true"><span>♥</span><i></i><b></b></div>
    </section>

    <div class="ai-layout">
      <section class="ai-card ai-start-card" aria-labelledby="ai-start-title">
        <div class="ai-card-heading"><span class="ai-card-icon" aria-hidden="true">✧</span><div><h2 id="ai-start-title">تحليل شخصيتك ومدى محبتك لدى الآخرين</h2><p>تحليل مبني على رسائلك النصية الظاهرة في صندوقك.</p></div></div>
        <?php if(!$enabled): ?>
          <div class="ai-notice ai-notice-muted" role="status"><b>الميزة متوقفة مؤقتًا</b><span>سيظهر زر التحليل هنا عندما يعيد مدير الموقع تفعيلها.</span></div>
        <?php elseif(!$apiReady): ?>
          <div class="ai-notice ai-notice-muted" role="status"><b>الخدمة غير جاهزة بعد</b><span>لم يكتمل إعداد خدمة التحليل. يمكنك المحاولة لاحقًا.</span></div>
        <?php elseif($messageCount===0): ?>
          <div class="ai-notice ai-notice-muted" role="status"><b>نحتاج إلى رسائل نصية أولًا</b><span>عندما تصلك رسائل نصية ظاهرة في صندوقك، يمكنك العودة لبدء التحليل.</span></div>
        <?php elseif($quota['remaining']===0): ?>
          <div class="ai-notice ai-notice-muted" role="status"><b>انتهى رصيدك الحالي</b><span><?=e(ai_setting_value('limit_message',ai_default_settings()['limit_message']))?></span></div>
        <?php elseif($quota['wait_seconds']>0): ?>
          <div class="ai-notice ai-notice-muted" role="status"><b>تحليلك التالي يحتاج إلى انتظار</b><span>سيصبح التحليل متاحًا بعد انتهاء مدة الانتظار المحددة.</span></div>
        <?php endif; ?>
        <div class="ai-usage-row"><span><b>رصيدك الحالي</b><small>يتجدد كل <?=ar_num($quota['window_hours'])?> ساعة</small></span><strong><?=ar_num($quota['remaining'])?><small> / <?=ar_num($quota['limit'])?></small></strong></div>
        <form id="ai-analysis-form" class="ai-action-form" method="post" action="analysis.php">
          <?=csrf_field()?>
          <input type="hidden" name="action" value="analyze">
          <label class="ai-consent"><input id="ai-consent" name="consent" value="1" type="checkbox" required><span>أوافق على إرسال نصوص الرسائل المؤهلة بعد تنقيحها إلى مزود الذكاء الاصطناعي المحدد لإعداد هذا التحليل. لن يُرسل اسم حسابي أو بريدي أو بيانات تسجيل دخولي.</span></label>
          <button class="ai-submit" type="submit" <?=!$canStart?'disabled':''?>><span class="ai-submit-label">ابدأ تحليل شخصيتي <span aria-hidden="true">❤️</span></span><span class="ai-spinner" aria-hidden="true"></span></button>
          <p class="ai-feedback" id="ai-feedback" role="status" aria-live="polite"><?=!$enabled?'التحليل غير متاح الآن.':($messageCount===0?'لا توجد رسائل نصية مؤهلة للتحليل.':'')?></p>
        </form>
        <div class="ai-privacy"><span aria-hidden="true">◈</span><p><b>خصوصيتك أولًا</b> نحلّل الرسائل الظاهرة فقط، ونستبعد الرسائل المحذوفة والصوتية. تُزال عناوين البريد والروابط وأرقام الاتصال ومعرّفات الحسابات من النص قبل إرساله. لا نرسل اسمك أو بيانات حسابك، ولا نحفظ النتيجة إلا إذا فعّل مدير الموقع حفظ النتائج.</p></div>
      </section>

      <aside class="ai-card ai-includes-card" aria-labelledby="ai-includes-title">
        <div class="ai-card-heading"><span class="ai-card-icon ai-card-icon-rose" aria-hidden="true">♡</span><div><h2 id="ai-includes-title">ماذا ستعرف؟</h2><p>ملخص واضح ومتوازن، وليس حكمًا نهائيًا عليك.</p></div></div>
        <ul class="ai-includes">
          <li><span aria-hidden="true">♥</span><div><b>درجة المحبوبية</b><small>مؤشر تقريبي من ١٠٠</small></div></li>
          <li><span aria-hidden="true">✦</span><div><b>نقاط القوة</b><small>الصفات التي تظهر في رسائلك</small></div></li>
          <li><span aria-hidden="true">📊</span><div><b>ستة أبعاد للشخصية</b><small>الدفء، التقدير، الاحترام، الثقة، خفة الظل، الدعم</small></div></li>
          <li><span aria-hidden="true">🎭</span><div><b>نبرة الرسائل</b><small>نسبة الإيجابي والمحايد والسلبي</small></div></li>
          <li><span aria-hidden="true">↗</span><div><b>مساحة للنمو</b><small>اقتراحات ونصيحة عملية</small></div></li>
          <li><span aria-hidden="true">⤓</span><div><b>بطاقة قابلة للمشاركة</b><small>احفظ نتيجتك كصورة أنيقة</small></div></li>
        </ul>
        <p class="ai-disclaimer">النتيجة قراءة آلية لنصوص محدودة، وقد لا تمثّل شخصيتك كاملة. لا تُستخدم للتقييم النفسي أو لاتخاذ قرارات مهمة.</p>
      </aside>
    </div>

    <?php if($localStats): ?>
    <section class="ai-card ai-stats-card" aria-labelledby="ai-stats-title">
      <div class="ai-card-heading"><span class="ai-card-icon" aria-hidden="true">◔</span><div><h2 id="ai-stats-title">لمحة سريعة عن رسائلك</h2><p>أرقام محسوبة مباشرة على الخادم دون إرسال أي شيء لأي مزود.</p></div></div>
      <div class="ai-stats-grid">
        <div class="ai-stat"><strong><?=ar_num($localStats['messages'])?></strong><span>رسالة نصية</span></div>
        <div class="ai-stat"><strong><?=ar_num($localStats['positive_pct'])?>٪</strong><span>تحمل كلمات إيجابية</span></div>
        <div class="ai-stat"><strong><?=ar_num($localStats['hearts'])?></strong><span>قلوب وإيموجي محبة</span></div>
        <div class="ai-stat"><strong><?=ar_num($localStats['avg_length'])?></strong><span>متوسط طول الرسالة (حرف)</span></div>
        <div class="ai-stat"><strong><?=ar_num($localStats['questions_pct'])?>٪</strong><span>رسائل تحتوي أسئلة</span></div>
        <div class="ai-stat"><strong class="ai-stat-emoji"><?=$localStats['top_emoji']?e(implode(' ',$localStats['top_emoji'])):'—'?></strong><span>الإيموجي الأكثر تكرارًا</span></div>
      </div>
      <?php if(count($boot['history'])>0): ?>
      <div class="ai-history"><div class="ai-history-head"><b>تطوّر درجتك</b><small>آخر <?=ar_num(count($boot['history']))?> تحليلات</small></div><div class="ai-history-bars" id="ai-history-bars" role="img" aria-label="تطور درجة المحبوبية عبر التحليلات السابقة"></div></div>
      <?php endif; ?>
    </section>
    <?php endif; ?>

    <section class="ai-result" id="ai-result" hidden aria-labelledby="ai-result-title" aria-live="polite">
      <div class="ai-result-head"><div><span class="ai-eyebrow">صورتك من رسائلك</span><h2 id="ai-result-title">الانطباع الذي تتركه</h2><p class="ai-result-date" id="ai-result-date"></p></div>
        <div class="ai-result-actions"><button type="button" class="ai-chip-btn" id="ai-share-btn"><span aria-hidden="true">⤓</span> حفظ كصورة</button><button type="button" class="ai-chip-btn" id="ai-copy-btn"><span aria-hidden="true">⧉</span> نسخ الملخص</button></div></div>
      <div class="ai-result-grid">
        <article class="ai-score-card">
          <div class="ai-score-ring" id="ai-score-ring" role="img" aria-label="درجة المحبوبية"><div><strong id="ai-score">0</strong><span>من ١٠٠</span></div></div>
          <h3 id="ai-persona">درجة المحبوبية</h3>
          <p id="ai-score-level">مؤشر تقريبي مبني على أسلوب الرسائل المتاحة.</p>
          <span class="ai-delta" id="ai-delta" hidden></span>
        </article>
        <article class="ai-result-panel ai-result-wide"><h3><span aria-hidden="true">👥</span> الانطباع العام لدى الآخرين</h3><p id="ai-impression"></p><p class="ai-style" id="ai-style" hidden></p></article>
        <article class="ai-result-panel ai-result-wide" id="ai-dimensions-panel" hidden><h3><span aria-hidden="true">📊</span> أبعاد شخصيتك في عيون الآخرين</h3><div class="ai-dims" id="ai-dimensions"></div></article>
        <article class="ai-result-panel" id="ai-sentiment-panel" hidden><h3><span aria-hidden="true">🎭</span> نبرة الرسائل</h3><div class="ai-sentiment-bar" id="ai-sentiment-bar"></div><ul class="ai-sentiment-legend" id="ai-sentiment-legend"></ul></article>
        <article class="ai-result-panel" id="ai-themes-panel" hidden><h3><span aria-hidden="true">🏷️</span> أكثر ما يتكرر</h3><div class="ai-tags" id="ai-themes"></div></article>
        <article class="ai-result-panel"><h3><span aria-hidden="true">⭐</span> نقاط القوة</h3><ul id="ai-strengths"></ul></article>
        <article class="ai-result-panel"><h3><span aria-hidden="true">😊</span> الصفات الإيجابية المتكررة</h3><ul id="ai-traits"></ul></article>
        <article class="ai-result-panel ai-result-wide"><h3><span aria-hidden="true">💡</span> أشياء يمكن تحسينها</h3><ul id="ai-improvements"></ul></article>
        <article class="ai-result-panel ai-result-wide ai-advice" id="ai-advice-panel" hidden><h3><span aria-hidden="true">🌱</span> نصيحة لك</h3><p id="ai-advice"></p></article>
        <article class="ai-result-panel ai-result-wide ai-summary"><h3><span aria-hidden="true">📝</span> ملخص قصير</h3><p id="ai-summary"></p></article>
      </div>
      <p class="ai-result-footnote">تذكّر: هذه قراءة آلية لرسائلك المتاحة، وليست مقياسًا لقيمتك أو حكمًا على شخصيتك.</p>
    </section>
    <script type="application/json" id="ai-boot"><?=json_encode($boot,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?></script>
    <a class="ai-back-link" href="dashboard.php">العودة إلى صندوق الرسائل <span aria-hidden="true">←</span></a>
  </div>
</section>
<script src="ai-analysis.js?v=8" defer></script>
<?php foot(); ?>
