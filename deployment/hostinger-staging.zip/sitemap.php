<?php require 'inc.php';
header('Content-Type: application/xml; charset=utf-8');
$b=base_url();
echo '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
echo '<url><loc>'.e($b.'/').'</loc><changefreq>daily</changefreq><priority>1.0</priority></url>';
if(setting('seo_index','1')==='1'){
  foreach(['blog.php','about.php','contact.php'] as $page) echo '<url><loc>'.e($b.'/'.$page).'</loc><changefreq>monthly</changefreq><priority>0.7</priority></url>';
  foreach($pdo->query('SELECT id FROM blog_posts WHERE published=1 ORDER BY id DESC LIMIT 45000') as $post) echo '<url><loc>'.e($b.'/post.php?id='.(int)$post['id']).'</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>';
  try{
    $q=$pdo->query('SELECT username FROM users WHERE is_disabled=0 ORDER BY id DESC LIMIT 45000');
    foreach($q as $r) echo '<url><loc>'.e($b.'/u/'.rawurlencode($r['username'])).'</loc><changefreq>weekly</changefreq><priority>0.6</priority></url>';
  }catch(Throwable $x){}
}
echo '</urlset>';
