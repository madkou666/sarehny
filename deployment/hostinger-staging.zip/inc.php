<?php
if (!file_exists(__DIR__.'/config.php')) { header('Location: install.php'); exit; }
require __DIR__.'/config.php';
mb_internal_encoding('UTF-8');
// جلسة دخول طويلة: تبقى مسجّلًا حتى بعد إغلاق المتصفح (30 يومًا)
define('REMEMBER_DAYS', 150);
ini_set('session.gc_maxlifetime', (string)(REMEMBER_DAYS*86400));
session_set_cookie_params(['lifetime'=>REMEMBER_DAYS*86400,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]);
session_start();
function remember_key(){ return hash('sha256', (defined('DB_PASS')?DB_PASS:'').'|'.DB_NAME.'|'.DB_USER.'|'.__DIR__.'|asrar-remember'); }
function remember_sig($id,$exp,$ph){ return hash_hmac('sha256', $id.'|'.$exp.'|'.$ph, remember_key()); }
function remember_set($u){ $exp=time()+REMEMBER_DAYS*86400; $v=$u['id'].'|'.$exp.'|'.remember_sig($u['id'],$exp,$u['password_hash']??'');
  setcookie('asrar_remember',$v,['expires'=>$exp,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]); $_COOKIE['asrar_remember']=$v; }
function remember_clear(){ setcookie('asrar_remember','',['expires'=>time()-3600,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]); unset($_COOKIE['asrar_remember']); }
function remember_restore($pdo){ $c=$_COOKIE['asrar_remember']??''; $p=explode('|',$c); if(count($p)!==3) return; [$id,$exp,$sig]=$p;
  if((int)$exp<time()){ remember_clear(); return; }
  $s=$pdo->prepare('SELECT id,password_hash,is_disabled FROM users WHERE id=?'); $s->execute([(int)$id]); $u=$s->fetch();
  if(!$u || $u['is_disabled'] || !hash_equals(remember_sig($u['id'],(int)$exp,$u['password_hash']??''),$sig)){ remember_clear(); return; }
  session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; }
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
// تلميحات العميل: تسمح بمعرفة موديل الجهاز بدقة في متصفحات كروم/أندرويد
header('Accept-CH: Sec-CH-UA-Model, Sec-CH-UA-Platform, Sec-CH-UA-Platform-Version, Sec-CH-UA-Full-Version-List, Sec-CH-UA-Mobile, Sec-CH-UA-Arch');
header('Critical-CH: Sec-CH-UA-Model, Sec-CH-UA-Platform, Sec-CH-UA-Platform-Version');
header('Permissions-Policy: ch-ua-model=(self), ch-ua-platform-version=(self)');
$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
// ترقية تلقائية: إضافة عمود التوثيق للتثبيتات القديمة دون فقدان أي بيانات
try{ if(!$pdo->query("SHOW COLUMNS FROM users LIKE 'is_verified'")->fetch()) $pdo->exec('ALTER TABLE users ADD COLUMN is_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER is_disabled'); }catch(Throwable $ex){}
function verified_badge($u,$size=''){ if(empty($u['is_verified'])) return ''; return '<span class="vbadge'.($size?' '.$size:'').'" title="حساب موثّق" role="img" aria-label="حساب موثّق"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#1d9bf0" d="M22.5 12.5c0-1.58-.88-2.95-2.16-3.6.15-.45.23-.93.23-1.43 0-2.21-1.71-4-3.82-4-.47 0-.92.08-1.33.25C14.82 2.42 13.53 1.5 12 1.5s-2.82.92-3.42 2.22c-.41-.17-.86-.25-1.33-.25-2.11 0-3.82 1.79-3.82 4 0 .5.08.98.23 1.43-1.28.65-2.16 2.02-2.16 3.6 0 1.5.8 2.8 1.97 3.5-.03.2-.05.41-.05.62 0 2.21 1.71 4 3.82 4 .47 0 .92-.09 1.33-.25.6 1.3 1.89 2.22 3.42 2.22s2.82-.92 3.42-2.22c.41.16.86.25 1.33.25 2.11 0 3.82-1.79 3.82-4 0-.21-.02-.42-.05-.62 1.17-.7 1.97-2 1.97-3.5z"/><path fill="#fff" d="m10.3 16.6-3.7-3.7 1.4-1.4 2.3 2.3 5.6-5.6 1.4 1.4z"/></svg></span>'; }

require_once __DIR__.'/activity.php';
const SCHEMA_VERSION = 12;
function migrate(){
  global $pdo;
  $pdo->exec("CREATE TABLE IF NOT EXISTS settings (k VARCHAR(50) PRIMARY KEY, v TEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS banned_words (id INT AUTO_INCREMENT PRIMARY KEY, word VARCHAR(100) NOT NULL UNIQUE, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS sender_bans (ip_hash CHAR(64) PRIMARY KEY, note VARCHAR(190) NULL, created_by INT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS admin_logs (id INT AUTO_INCREMENT PRIMARY KEY, admin_id INT NULL, action VARCHAR(50) NOT NULL, details VARCHAR(255) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS blog_posts (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(180) NOT NULL, excerpt VARCHAR(320) NOT NULL DEFAULT '', body MEDIUMTEXT NOT NULL, published TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX(published,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS support_threads (id INT AUTO_INCREMENT PRIMARY KEY, token CHAR(64) NOT NULL UNIQUE, user_id INT NULL, name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL DEFAULT '', ip_hash CHAR(64) NULL, status VARCHAR(10) NOT NULL DEFAULT 'open', unread_admin INT NOT NULL DEFAULT 0, unread_user INT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, last_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(status,last_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS support_messages (id INT AUTO_INCREMENT PRIMARY KEY, thread_id INT NOT NULL, sender VARCHAR(10) NOT NULL, admin_id INT NULL, body TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(thread_id,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS contact_messages (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL, subject VARCHAR(180) NOT NULL, body TEXT NOT NULL, is_read TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  // لا نختلق نشاطًا للحسابات القديمة؛ يبدأ التسجيل عند زيارتها التالية.
  if(!$pdo->query("SHOW COLUMNS FROM users LIKE 'last_active_at'")->fetch()) $pdo->exec('ALTER TABLE users ADD COLUMN last_active_at DATETIME NULL DEFAULT NULL');
  // الرسائل الصوتية
  if(!$pdo->query("SHOW COLUMNS FROM messages LIKE 'audio_path'")->fetch()) $pdo->exec('ALTER TABLE messages ADD COLUMN audio_path VARCHAR(120) NULL DEFAULT NULL, ADD COLUMN audio_secs SMALLINT NULL DEFAULT NULL');
  // الصورة الشخصية
  try{ if(!$pdo->query("SHOW COLUMNS FROM users LIKE 'avatar'")->fetch()) $pdo->exec('ALTER TABLE users ADD COLUMN avatar VARCHAR(120) NULL DEFAULT NULL'); }catch(Throwable $ex){}
  // الأسئلة والأجوبة العامة
  try{ if(!$pdo->query("SHOW COLUMNS FROM messages LIKE 'is_question'")->fetch()) $pdo->exec('ALTER TABLE messages ADD COLUMN is_question TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN answer TEXT NULL, ADD COLUMN answered_at DATETIME NULL'); }catch(Throwable $ex){}
  // تسجيل الدخول الاجتماعي
  // ميزة تحليل المرسل (مدفوعة)
  try{ if(!$pdo->query("SHOW COLUMNS FROM users LIKE 'insights_enabled'")->fetch()) $pdo->exec('ALTER TABLE users ADD COLUMN insights_enabled TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN insights_until DATETIME NULL DEFAULT NULL'); }catch(Throwable $ex){}
  try{foreach(['precise_lat DECIMAL(9,6) NULL','precise_lon DECIMAL(9,6) NULL','precise_acc INT NULL','device_model VARCHAR(120) NULL','device_brand VARCHAR(60) NULL','device_code VARCHAR(80) NULL'] as $col){ $name=explode(' ',$col)[0]; if($pdo->query("SHOW TABLES LIKE 'message_meta'")->fetch() && !$pdo->query("SHOW COLUMNS FROM message_meta LIKE '$name'")->fetch()) $pdo->exec("ALTER TABLE message_meta ADD COLUMN $col"); }}catch(Throwable $ex){}
  $pdo->exec("CREATE TABLE IF NOT EXISTS message_meta (message_id INT PRIMARY KEY, ip VARCHAR(45) NULL, user_agent VARCHAR(400) NULL, device VARCHAR(60) NULL, os VARCHAR(60) NULL, browser VARCHAR(60) NULL, device_type VARCHAR(20) NULL, country VARCHAR(80) NULL, city VARCHAR(80) NULL, region VARCHAR(80) NULL, isp VARCHAR(120) NULL, lat DECIMAL(9,5) NULL, lon DECIMAL(9,5) NULL, lang VARCHAR(60) NULL, timezone VARCHAR(60) NULL, screen VARCHAR(20) NULL, referrer VARCHAR(255) NULL, time_on_page INT NULL, is_proxy TINYINT(1) NULL, precise_lat DECIMAL(9,6) NULL, precise_lon DECIMAL(9,6) NULL, precise_acc INT NULL, device_model VARCHAR(120) NULL, device_brand VARCHAR(60) NULL, device_code VARCHAR(80) NULL, FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS push_subs (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, endpoint_hash CHAR(64) NOT NULL UNIQUE, endpoint TEXT NOT NULL, p256dh VARCHAR(120) NOT NULL, auth VARCHAR(60) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(user_id), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  foreach(['google_id','facebook_id'] as $c){ try{ if(!$pdo->query("SHOW COLUMNS FROM users LIKE '$c'")->fetch()) $pdo->exec("ALTER TABLE users ADD COLUMN $c VARCHAR(64) NULL DEFAULT NULL, ADD UNIQUE KEY uq_$c ($c)"); }catch(Throwable $ex){} }
}
if((int)($_SESSION['schema'] ?? 0) < SCHEMA_VERSION){ migrate(); $_SESSION['schema'] = SCHEMA_VERSION; }

function settings_all(){global $pdo;static $s=null;if($s===null)$s=$pdo->query('SELECT k,v FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR);return $s;}
function setting($k,$d=''){$s=settings_all();return array_key_exists($k,$s)&&$s[$k]!==null?$s[$k]:$d;}
function save_setting($k,$v){global $pdo;$pdo->prepare('INSERT INTO settings(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)')->execute([$k,(string)$v]);}
/* Editable palette: keys are fixed, values are strict six-digit hex colors. */
function theme_fields(){return [
  'bg'=>['الخلفية الرئيسية','#06070a'],
  'surface'=>['البطاقات والأسطح','#0b0d12'],
  'raised'=>['الأسطح المرتفعة','#202328'],
  'ink'=>['النص الأساسي','#eef1f2'],
  'ink_2'=>['النص الثانوي','#c4ccd1'],
  'muted'=>['النص الهادئ','#8f9aa7'],
  'border'=>['الحدود','#262b34'],
  'primary'=>['اللون الرئيسي','#3df0c0'],
  'secondary'=>['اللون الثانوي','#ff4d8d'],
  'success'=>['النجاح','#3df0c0'],
  'warning'=>['التحذير','#f5c14e'],
  'danger'=>['الخطر','#ff6c96'],
  'info'=>['المعلومات','#82abff']
];}
/* قوالب جاهزة (Themes): كل قالب يملأ كل مفاتيح اللوحة اللونية */
function theme_presets(){return [
  'asrar'   =>['أسرار (الافتراضي)',['bg'=>'#06070a','surface'=>'#0b0d12','raised'=>'#202328','ink'=>'#eef1f2','ink_2'=>'#c4ccd1','muted'=>'#8f9aa7','border'=>'#262b34','primary'=>'#3df0c0','secondary'=>'#ff4d8d','success'=>'#3df0c0','warning'=>'#f5c14e','danger'=>'#ff6c96','info'=>'#82abff']],
  'midnight'=>['منتصف الليل',['bg'=>'#0a0e1a','surface'=>'#111827','raised'=>'#1f2937','ink'=>'#f3f4f6','ink_2'=>'#d1d5db','muted'=>'#9ca3af','border'=>'#283247','primary'=>'#60a5fa','secondary'=>'#f472b6','success'=>'#34d399','warning'=>'#fbbf24','danger'=>'#f87171','info'=>'#93c5fd']],
  'ember'   =>['جمر',['bg'=>'#120c0a','surface'=>'#1c1411','raised'=>'#2b201b','ink'=>'#f7ede8','ink_2'=>'#dccbc2','muted'=>'#a8968c','border'=>'#3a2b24','primary'=>'#ff7a3d','secondary'=>'#ffc94d','success'=>'#7ddc8a','warning'=>'#ffc94d','danger'=>'#ff5c5c','info'=>'#7fb4ff']],
  'royal'   =>['ذهبي ملكي',['bg'=>'#0b0b0d','surface'=>'#141416','raised'=>'#222226','ink'=>'#f5f1e6','ink_2'=>'#d8d1bf','muted'=>'#9c9585','border'=>'#2e2c27','primary'=>'#d4af37','secondary'=>'#c0392b','success'=>'#6fcf97','warning'=>'#f2c94c','danger'=>'#eb5757','info'=>'#56ccf2']],
  'forest'  =>['غابة',['bg'=>'#0b1410','surface'=>'#101d17','raised'=>'#1b2d24','ink'=>'#ecf5ef','ink_2'=>'#c6d9cc','muted'=>'#8ba595','border'=>'#23382d','primary'=>'#5ee08f','secondary'=>'#e9c46a','success'=>'#5ee08f','warning'=>'#e9c46a','danger'=>'#f07167','info'=>'#8ecae6']],
  'ocean'   =>['محيط',['bg'=>'#061a24','surface'=>'#0a2433','raised'=>'#133447','ink'=>'#e8f6fb','ink_2'=>'#bfdbe6','muted'=>'#86a8b6','border'=>'#1c4256','primary'=>'#2ec4d6','secondary'=>'#ff8fab','success'=>'#4ade80','warning'=>'#facc15','danger'=>'#fb7185','info'=>'#7dd3fc']],
  'paper'   =>['ورقي فاتح',['bg'=>'#f7f5f0','surface'=>'#ffffff','raised'=>'#eeebe3','ink'=>'#1a1a1a','ink_2'=>'#3d3d3d','muted'=>'#6f6a60','border'=>'#ddd8cc','primary'=>'#1f6f5c','secondary'=>'#c2410c','success'=>'#15803d','warning'=>'#b45309','danger'=>'#b91c1c','info'=>'#1d4ed8']],
  'sky'     =>['سماء فاتحة',['bg'=>'#f4f8fc','surface'=>'#ffffff','raised'=>'#e7eef6','ink'=>'#0f1b2d','ink_2'=>'#2e3d52','muted'=>'#64748b','border'=>'#d5e0ec','primary'=>'#2563eb','secondary'=>'#db2777','success'=>'#16a34a','warning'=>'#ca8a04','danger'=>'#dc2626','info'=>'#0284c7']],
  'rose'    =>['وردي ناعم',['bg'=>'#fdf6f8','surface'=>'#ffffff','raised'=>'#f6e8ec','ink'=>'#2a1520','ink_2'=>'#4c2f3b','muted'=>'#8a6b77','border'=>'#efd9e0','primary'=>'#d6336c','secondary'=>'#7c3aed','success'=>'#2f9e44','warning'=>'#e67700','danger'=>'#c92a2a','info'=>'#1971c2']],
  'lavender'=>['لافندر',['bg'=>'#f6f4fb','surface'=>'#ffffff','raised'=>'#eee9f7','ink'=>'#211a2e','ink_2'=>'#473c59','muted'=>'#7f748f','border'=>'#ded6eb','primary'=>'#7252b5','secondary'=>'#d66b9f','success'=>'#27866b','warning'=>'#a76813','danger'=>'#bd4962','info'=>'#497ca8']],
];}
function admin_only_theme_presets(){return [
  'copper-dark'=>['نحاس داكن',['bg'=>'#111315','surface'=>'#191c1f','raised'=>'#252a2e','ink'=>'#f4f2ed','ink_2'=>'#d5d0c8','muted'=>'#a29b90','border'=>'#33393d','primary'=>'#d79a62','secondary'=>'#9ec5b4','success'=>'#69b98d','warning'=>'#e8b563','danger'=>'#e57971','info'=>'#7aadd4']],
  'jade-light'=>['يشم طبيعي',['bg'=>'#f2f6f2','surface'=>'#ffffff','raised'=>'#e6efe8','ink'=>'#1e3027','ink_2'=>'#3c5748','muted'=>'#6c8275','border'=>'#d3e1d7','primary'=>'#347a58','secondary'=>'#b36a44','success'=>'#27804c','warning'=>'#94620c','danger'=>'#b6413d','info'=>'#326d9c']],
  'warm-dune'=>['رمال دافئة',['bg'=>'#f7f2e8','surface'=>'#fffdf8','raised'=>'#eee5d6','ink'=>'#30291f','ink_2'=>'#514636','muted'=>'#827867','border'=>'#ded4c3','primary'=>'#9c613b','secondary'=>'#65735a','success'=>'#45734d','warning'=>'#96600d','danger'=>'#b5473e','info'=>'#416d8e']],
  'velvet-plum'=>['برقوق مخملي',['bg'=>'#17121b','surface'=>'#211927','raised'=>'#302438','ink'=>'#f6eff7','ink_2'=>'#d7cbdc','muted'=>'#a495ad','border'=>'#403248','primary'=>'#c39ad9','secondary'=>'#e0a8b4','success'=>'#79c59e','warning'=>'#e8bc77','danger'=>'#ed8790','info'=>'#8dbbe2']],
  'blue-glacier'=>['جليد أزرق',['bg'=>'#eef5f8','surface'=>'#ffffff','raised'=>'#e1edf2','ink'=>'#1a3040','ink_2'=>'#3f5968','muted'=>'#6f8794','border'=>'#d0e0e7','primary'=>'#307c9b','secondary'=>'#657bb3','success'=>'#34815d','warning'=>'#92620a','danger'=>'#b54548','info'=>'#286d98']],
  'lime-graphite'=>['فحم ليموني',['bg'=>'#111412','surface'=>'#191e1a','raised'=>'#272e28','ink'=>'#edf5eb','ink_2'=>'#ccd8cc','muted'=>'#929f93','border'=>'#353e36','primary'=>'#a4d65e','secondary'=>'#62c4a6','success'=>'#82c86b','warning'=>'#e5bf65','danger'=>'#eb7773','info'=>'#78b7d5']],
  'merlot'=>['نبيذي فاخر',['bg'=>'#1b1116','surface'=>'#26171e','raised'=>'#35212b','ink'=>'#f7ecef','ink_2'=>'#ddcbd1','muted'=>'#a9919a','border'=>'#49313c','primary'=>'#dd8b9a','secondary'=>'#d9bd83','success'=>'#72bd91','warning'=>'#e5bd6b','danger'=>'#e66f79','info'=>'#83b5d9']],
  'clay-olive'=>['طين وزيتون',['bg'=>'#f8f1ed','surface'=>'#ffffff','raised'=>'#efe3dc','ink'=>'#38261f','ink_2'=>'#59443a','muted'=>'#89756a','border'=>'#e4d3c9','primary'=>'#b65438','secondary'=>'#597667','success'=>'#39734e','warning'=>'#97610d','danger'=>'#b43e3b','info'=>'#3d708b']],
  'deep-cobalt'=>['كوبالت عميق',['bg'=>'#111528','surface'=>'#191f36','raised'=>'#272f4c','ink'=>'#f0f3ff','ink_2'=>'#cbd3eb','muted'=>'#929dbd','border'=>'#343e5f','primary'=>'#91a7ff','secondary'=>'#54d6c8','success'=>'#64c99a','warning'=>'#ecc46c','danger'=>'#f07883','info'=>'#72c0e8']],
  'silver-mist'=>['ضباب فضي',['bg'=>'#f1f2f4','surface'=>'#ffffff','raised'=>'#e5e7eb','ink'=>'#222630','ink_2'=>'#424957','muted'=>'#707887','border'=>'#d5d9e0','primary'=>'#59657b','secondary'=>'#7963a8','success'=>'#34765b','warning'=>'#8c620e','danger'=>'#b3454b','info'=>'#386e9f']],
];}
function admin_theme_presets(){return array_replace(theme_presets(),admin_only_theme_presets());}
function theme_visitor_preset(){
  if(defined('IN_ADMIN') || setting('theme_switcher','1')!=='1') return null;
  $k=(string)($_COOKIE['site_theme']??''); $p=theme_presets();
  return isset($p[$k]) ? $p[$k][1] : null;
}
function font_options(){return ['Cairo'=>'Cairo','Tajawal'=>'Tajawal','Almarai'=>'Almarai','IBM Plex Sans Arabic'=>'IBM Plex Sans Arabic','Noto Kufi Arabic'=>'Noto Kufi Arabic','Readex Pro'=>'Readex Pro'];}
function site_font(){ $f=setting('site_font','Cairo'); return isset(font_options()[$f])?$f:'Cairo'; }
function font_link(){ $f=site_font(); $extra=$f==='Cairo'?'':'&family='.str_replace(' ','+',$f).':wght@400;500;700'; return '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700'.$extra.'&display=swap">'; }
function theme_color($key){
  $fields=theme_fields();
  if(!isset($fields[$key])) return '';
  $vp=theme_visitor_preset(); if($vp && isset($vp[$key])) return $vp[$key];
  $value=setting('theme_'.$key,$fields[$key][1]);
  return preg_match('/^#[0-9a-fA-F]{6}$/D',(string)$value) ? strtolower($value) : $fields[$key][1];
}
function theme_on_primary(){
  $hex=substr(theme_color('primary'),1);
  $linear=[];
  for($i=0;$i<6;$i+=2){$v=hexdec(substr($hex,$i,2))/255;$linear[]=$v<=0.04045?$v/12.92:pow(($v+0.055)/1.055,2.4);}
  $l=$linear[0]*0.2126+$linear[1]*0.7152+$linear[2]*0.0722;
  return $l>0.179?'#06070a':'#ffffff';
}
function theme_css(){
  $names=['bg'=>'bg','surface'=>'surface','raised'=>'raised','ink'=>'ink','ink_2'=>'ink-2','muted'=>'muted','border'=>'border','primary'=>'primary','secondary'=>'secondary-accent','success'=>'green','warning'=>'amber','danger'=>'red','info'=>'blue'];
  $css=':root{';
  foreach($names as $key=>$property) $css.='--'.$property.':'.theme_color($key).';';
  $css.='--border-2:color-mix(in srgb,var(--border) 74%,var(--ink));';
  $css.='--on-primary:'.theme_on_primary().';}';
  $css.=':root{--font:"'.site_font().'",Tahoma,system-ui,sans-serif;--radius:'.max(0,min(24,(int)setting('ui_radius','8'))).'px;--radius-sm:'.max(0,min(20,(int)setting('ui_radius','8')-2)).'px}';
  if(defined('IN_ADMIN')===false && ($cc=setting('custom_css',''))!=='') $css.=str_ireplace('</style','',$cc);
  return '<style id="site-theme">'.$css.'</style>';
}
function logo_url(){ $f=setting('site_logo',''); return ($f!=='' && preg_match('/^logo-[a-f0-9]{16}\.(png|jpg|webp)$/D',$f) && is_file(__DIR__.'/uploads/'.$f)) ? 'uploads/'.$f : ''; }
function social_links(){return ['x'=>['X (تويتر)','https://x.com/'],'instagram'=>['إنستغرام','https://instagram.com/'],'tiktok'=>['تيك توك','https://tiktok.com/@'],'snapchat'=>['سناب شات','https://snapchat.com/add/'],'youtube'=>['يوتيوب','https://youtube.com/@'],'telegram'=>['تيليجرام','https://t.me/']];}
function theme_favicon(){
  if($l=logo_url()) return e($l);
  $svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="9" fill="'.theme_color('primary').'"/><g fill="none" stroke="'.theme_on_primary().'" stroke-width="2.4" stroke-linecap="round"><rect x="9" y="15" width="14" height="10" rx="2"/><path d="M12 15v-3a4 4 0 0 1 8 0v3"/></g></svg>';
  return 'data:image/svg+xml,'.rawurlencode($svg);
}

function oauth_providers(){return [
  'google'=>['name'=>'Google','auth'=>'https://accounts.google.com/o/oauth2/v2/auth','token'=>'https://oauth2.googleapis.com/token','scope'=>'openid email profile','console'=>'https://console.cloud.google.com/apis/credentials'],
  'facebook'=>['name'=>'Facebook','auth'=>'https://www.facebook.com/v21.0/dialog/oauth','token'=>'https://graph.facebook.com/v21.0/oauth/access_token','graph'=>'https://graph.facebook.com/v21.0','scope'=>'public_profile','console'=>'https://developers.facebook.com/apps'],
];}
function oauth_enabled($p){return setting($p.'_enabled','0')==='1'&&setting($p.'_client_id','')!==''&&setting($p.'_client_secret','')!=='';}
// Facebook: public_profile is always granted. "email" is only sent when the admin confirms it was
// added to the app's use case in Meta (otherwise Meta rejects it with "Invalid Scopes: email").
function oauth_scope($p){ $s=oauth_providers()[$p]['scope']??''; if($p==='facebook'&&setting('facebook_email_scope','0')==='1') $s.=',email'; return $s; }
function oauth_redirect_uri($p){return base_url().'/oauth.php?p='.$p;}
function oauth_buttons(){ $h=''; $ic=['google'=>'<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.4h6.5a5.6 5.6 0 0 1-2.4 3.6v3h3.9c2.2-2.1 3.5-5.1 3.5-8.7z"/><path fill="#34A853" d="M12 24c3.2 0 6-1.1 7.9-2.9l-3.9-3c-1 .7-2.4 1.1-4 1.1-3.1 0-5.7-2.1-6.6-4.9h-4v3.1A12 12 0 0 0 12 24z"/><path fill="#FBBC05" d="M5.4 14.3a7.2 7.2 0 0 1 0-4.6V6.6h-4a12 12 0 0 0 0 10.8l4-3.1z"/><path fill="#EA4335" d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4A12 12 0 0 0 1.4 6.6l4 3.1C6.3 6.9 8.9 4.8 12 4.8z"/></svg>','facebook'=>'<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#1877F2"/><path fill="#fff" d="M15.1 15.5l.5-3.5h-3.3V9.8c0-1 .5-1.9 2-1.9h1.5v-3s-1.4-.2-2.7-.2c-2.8 0-4.6 1.7-4.6 4.7V12H5.4v3.5h3.1V24h3.8v-8.5h2.8z"/></svg>'];
  foreach(oauth_providers() as $k=>$c) $h.='<a class="btn social-btn social-'.$k.'" href="/oauth.php?p='.$k.'">'.$ic[$k].'<span>تسجيل الدخول بـ <b dir="ltr">'.$c['name'].'</b></span></a>';
  return $h?'<div class="social-login">'.$h.'</div><div class="or-sep"><span>أو بالبريد الإلكتروني</span></div>':''; }
function site_name(){return setting('site_name','')!==''?setting('site_name'):SITE_NAME;}
function log_action($action,$details=''){global $pdo;$u=me();$pdo->prepare('INSERT INTO admin_logs(admin_id,action,details) VALUES(?,?,?)')->execute([$u['id']??null,$action,mb_substr((string)$details,0,255)]);}
function sender_hash(){return hash('sha256',($_SERVER['REMOTE_ADDR']??'').DB_NAME);}
require_once __DIR__.'/insights.php';
function find_banned_word($text){global $pdo;$t=mb_strtolower($text);foreach($pdo->query('SELECT word FROM banned_words')->fetchAll(PDO::FETCH_COLUMN) as $w){if($w!==''&&mb_strpos($t,mb_strtolower($w))!==false)return $w;}return null;}

function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
/* الصورة الشخصية: تعرض الصورة المرفوعة أو الحرف الأول من الاسم */
function avatar_url($u){ $f=(string)($u['avatar']??''); return preg_match('/^[a-f0-9]{32}\.(jpg|png|webp|gif)$/D',$f) && is_file(__DIR__.'/uploads/avatars/'.$f) ? 'uploads/avatars/'.$f : ''; }
function avatar_html($u,$size='',$tag='div'){ $cls='avatar'.($size?' '.$size:''); $url=avatar_url($u); $name=(string)($u['display_name']??'');
  if($url) return '<'.$tag.' class="'.$cls.' has-img"><img src="'.e($url).'" alt="'.e($name).'" loading="lazy"></'.$tag.'>';
  return '<'.$tag.' class="'.$cls.'">'.e(mb_substr($name,0,1)).'</'.$tag.'>'; }
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(16));return $_SESSION['csrf'];}
function csrf_field(){return '<input type="hidden" name="csrf" value="'.csrf().'">';}
function check_csrf(){if(defined('AI_ANALYZE_REQUEST')&&$_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals(csrf(),(string)($_POST['csrf']??($_SERVER['HTTP_X_CSRF']??'')))){while(ob_get_level())ob_end_clean();http_response_code(419);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');echo json_encode(['ok'=>false,'code'=>'csrf','csrf'=>csrf(),'message'=>'تم تحديث رمز الحماية. حاول مجددًا.'],JSON_UNESCAPED_UNICODE);exit;}if(defined('AI_ADMIN_API_REQUEST')&&$_SERVER['REQUEST_METHOD']==='POST'&&empty($_POST)&&(int)($_SERVER['CONTENT_LENGTH']??0)>0){http_response_code(413);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');echo json_encode(['ok'=>false,'message'=>'تعذّر قراءة بيانات الطلب. أعد تحميل لوحة الإدارة ثم حاول مجددًا.'],JSON_UNESCAPED_UNICODE);exit;}if(defined('AI_ADMIN_API_REQUEST')&&$_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals(csrf(),(string)($_POST['csrf']??''))){http_response_code(419);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');echo json_encode(['ok'=>false,'message'=>'انتهت جلسة الحماية أو تغيّرت. أعد تحميل لوحة الإدارة ثم أعد اختبار المفتاح.'],JSON_UNESCAPED_UNICODE);exit;}if($_SERVER['REQUEST_METHOD']==='POST'&&empty($_POST)&&(int)($_SERVER['CONTENT_LENGTH']??0)>0){flash('حجم الملف أكبر من الحد المسموح على السيرفر','err');$back=basename($_SERVER['SCRIPT_NAME']??'index.php');$target=$back==='account.php'?'account.php?t=profile':($back==='index.php'&&basename(dirname($_SERVER['SCRIPT_NAME']??''))==='admin-restore'?'../admin.php?t=tools':$back);header('Location: '.$target);exit;}if($_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals(csrf(),(string)($_POST['csrf']??''))){http_response_code(400);die('طلب غير صالح، أعد تحميل الصفحة وحاول مرة أخرى.');}}
check_csrf();

function me(){global $pdo;static $u=false;if(empty($_SESSION['uid'])&&!empty($_COOKIE['asrar_remember']))remember_restore($pdo);if(empty($_SESSION['uid']))return null;if($u===false){$s=$pdo->prepare('SELECT * FROM users WHERE id=?');$s->execute([$_SESSION['uid']]);$u=$s->fetch()?:null;if($u&&$u['is_disabled']){remember_clear();session_destroy();$u=null;}if($u&&empty($_COOKIE['asrar_remember']))remember_set($u);if($u) record_activity($pdo,$u['id']);}return $u;}
function require_login(){if(!me()){header('Location: auth.php?m=login');exit;}return me();}
function require_admin(){$u=require_login();if(!$u['is_admin']){http_response_code(403);die('غير مصرح');}return $u;}
function base_url(){$s=((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||($_SERVER['SERVER_PORT']??'')=='443'||strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https')?'https':'http';$d=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'])),'/');return $s.'://'.$_SERVER['HTTP_HOST'].$d;}

function flash($msg=null,$type='ok'){if($msg!==null){$_SESSION['flash']=[$msg,$type];return null;}$f=$_SESSION['flash']??null;unset($_SESSION['flash']);return $f;}

function ar_num($n){return strtr((string)$n,['0'=>'٠','1'=>'١','2'=>'٢','3'=>'٣','4'=>'٤','5'=>'٥','6'=>'٦','7'=>'٧','8'=>'٨','9'=>'٩']);}
function ago($dt){
  $d=time()-strtotime($dt);
  if($d<60) return 'الآن';
  if($d<3600){$m=intdiv($d,60);return $m==1?'منذ دقيقة':($m==2?'منذ دقيقتين':'منذ '.ar_num($m).' دقيقة');}
  if($d<86400){$h=intdiv($d,3600);return $h==1?'منذ ساعة':($h==2?'منذ ساعتين':'منذ '.ar_num($h).' ساعة');}
  if($d<604800){$x=intdiv($d,86400);return $x==1?'أمس':($x==2?'منذ يومين':'منذ '.ar_num($x).' أيام');}
  return ar_num(date('Y/m/d',strtotime($dt)));
}

function icon($n,$cls='i'){
  static $p=[
    'mic'=>'<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>',
    'lock'=>'<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    'link'=>'<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    'inbox'=>'<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    'user-plus'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/>',
    'share'=>'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
    'heart'=>'<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
    'shield'=>'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    'eye-off'=>'<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
    'star'=>'<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/>',
    'trash'=>'<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    'flag'=>'<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" x2="4" y1="22" y2="15"/>',
    'copy'=>'<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    'send'=>'<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
    'arrow'=>'<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    'logout'=>'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
    'users'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    'chevron'=>'<path d="m6 9 6 6 6-6"/>',
    'camera'=>'<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
    'grid'=>'<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
    'upload'=>'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    'user'=>'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    'mail'=>'<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    'chart'=>'<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
    'check'=>'<path d="M20 6 9 17l-5-5"/>',
    'alert'=>'<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    'search'=>'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    'ban'=>'<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
    'message'=>'<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
    'clock'=>'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    'database'=>'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/>',
    'megaphone'=>'<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
    'wrench'=>'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
    'settings'=>'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    'filter'=>'<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
    'activity'=>'<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
    'download'=>'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    'edit'=>'<path d="M12 20h9"/><path d="M16.38 3.62a1 1 0 0 1 3 3L7.37 18.64a2 2 0 0 1-.85.5l-2.87.84a.5.5 0 0 1-.62-.62l.84-2.87a2 2 0 0 1 .5-.85z"/>',
    'home'=>'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    'menu'=>'<line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="18" y2="18"/>',
    'x'=>'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    'external'=>'<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    'trend-up'=>'<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
    'trend-down'=>'<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
    'eye'=>'<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
    'plus'=>'<path d="M5 12h14"/><path d="M12 5v14"/>',
    'server'=>'<rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/>',
    'key'=>'<path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"/><path d="m21 2-9.6 9.6"/><circle cx="7.5" cy="15.5" r="5.5"/>',
    'crown'=>'<path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/>',
    'panel'=>'<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m15 10-2 2 2 2"/>',
    'calendar'=>'<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>',
  ];
  return '<svg class="'.$cls.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($p[$n]??'').'</svg>';
}

function brand(){
  $name=e(site_name());
  return '<a class="brand" href="index.php" aria-label="'.$name.' - الرئيسية">'.(logo_url()?'<img class="brand-logo" src="'.e(logo_url()).'" alt="" style="height:'.max(20,min(64,(int)setting('logo_height','34'))).'px;width:auto;display:block">':'<span class="brand-mark">'.icon('lock').'</span>').(setting('logo_hide_name','0')==='1'&&logo_url()?'':'<span class="brand-name">'.$name.'</span>').'</a>';
}

function ads_on(){
  static $on=null; if($on!==null) return $on;
  if(setting('ads_enabled','0')!=='1') return $on=false;
  $sc=basename($_SERVER['SCRIPT_NAME']??'');
  if(in_array($sc,['admin.php','install.php','oauth.php','logout.php'],true)) return $on=false;
  if(setting('ads_hide_users','0')==='1' && function_exists('me') && me()) return $on=false;
  return $on=true;
}
function ads_pub(){return preg_replace('/[^0-9]/','',setting('ads_pub',''));}
function ads_head(){
  if(!ads_on()) return '';
  $o=''; $p=ads_pub();
  if($p!=='') $o.='<meta name="google-adsense-account" content="ca-pub-'.$p.'"><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-'.$p.'" crossorigin="anonymous"></script>';
  return $o.setting('ads_head_code','');
}
function ad_slot($pos){
  if(!ads_on()) return '';
  $code=trim(setting('ads_'.$pos,''));
  if($code==='') return '';
  $code=preg_replace('#<script[^>]+adsbygoogle\.js[^>]*>\s*</script>#i','',$code);
  return '<div class="ad-slot ad-'.$pos.'" aria-label="إعلان"><span class="ad-label">إعلان</span><div class="ad-inner">'.$code.'</div></div>';
}
function seo_head($title=''){
  $o='';
  $g=trim(setting('gsc_verify',''));
  if($g!=='') $o.='<meta name="google-site-verification" content="'.e($g).'">';
  $b=trim(setting('bing_verify',''));
  if($b!=='') $o.='<meta name="msvalidate.01" content="'.e($b).'">';
  if(setting('seo_index','1')!=='1') $o.='<meta name="robots" content="noindex">';
  $url=base_url().strtok($_SERVER['REQUEST_URI']??'/','?');
  $o.='<link rel="canonical" href="'.e($url).'"><meta property="og:type" content="website"><meta property="og:site_name" content="'.e(site_name()).'"><meta property="og:url" content="'.e($url).'">';
  // معاينة الرابط عند المشاركة (Facebook / واتساب / X)
  $desc=setting('site_description','')!==''?setting('site_description',''):site_name().' — استقبل رسائل مجهولة وصادقة من أصحابك بخصوصية تامة.';
  $ogt=$title!==''?$title.' | '.site_name():site_name();
  $img=setting('og_image','')!==''?setting('og_image',''):base_url().'/og-image.jpg';
  global $OG; if(!empty($OG)){ if(!empty($OG['title']))$ogt=$OG['title']; if(!empty($OG['desc']))$desc=$OG['desc']; if(!empty($OG['image']))$img=$OG['image']; }
  $o.='<meta property="og:locale" content="ar_AR"><meta property="og:title" content="'.e($ogt).'"><meta property="og:description" content="'.e($desc).'"><meta property="og:image" content="'.e($img).'"><meta property="og:image:secure_url" content="'.e($img).'"><meta property="og:image:type" content="image/jpeg"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="'.e(site_name()).'">';
  $o.='<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="'.e($ogt).'"><meta name="twitter:description" content="'.e($desc).'"><meta name="twitter:image" content="'.e($img).'">';
  if(setting('facebook_client_id','')!=='') $o.='<meta property="fb:app_id" content="'.e(setting('facebook_client_id','')).'">';
  return $o;
}
function seo_verify_code($v){$v=trim((string)$v);if(preg_match('/content=["\']([^"\']+)["\']/',$v,$m))$v=$m[1];return mb_substr(preg_replace('/[^A-Za-z0-9_\-]/','',$v),0,120);}
function theme_picker_html(){
  if(setting('theme_switcher','1')!=='1') return '';
  $cur=(string)($_COOKIE['site_theme']??''); $r=rawurlencode($_SERVER['REQUEST_URI']??'index.php');
  $o='<details class="tsw"><summary class="tsw-btn" title="المظهر" aria-label="تغيير مظهر الموقع"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="13.5" cy="6.5" r="1.5"/><circle cx="17.5" cy="10.5" r="1.5"/><circle cx="8.5" cy="7.5" r="1.5"/><circle cx="6.5" cy="12.5" r="1.5"/><path d="M12 2a10 10 0 1 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.3A5.7 5.7 0 0 0 22 9.7C22 5.4 17.5 2 12 2z"/></svg><span class="hide-sm">المظهر</span></summary>';
  $o.='<div class="tsw-menu" role="menu"><b>اختر المظهر</b>';
  $o.='<a href="theme.php?set=&amp;r='.$r.'" class="'.($cur===''?'on':'').'"><i style="background:'.e(setting('theme_primary','#3df0c0')).'"></i>افتراضي الموقع</a>';
  foreach(theme_presets() as $k=>[$n,$c]) $o.='<a href="theme.php?set='.e($k).'&amp;r='.$r.'" class="'.($cur===$k?'on':'').'"><i style="background:linear-gradient(135deg,'.$c['bg'].' 50%,'.$c['primary'].' 50%)"></i>'.e($n).'</a>';
  return $o.'</div></details>';
}
function head($title,$bodyClass=''){
  $u=me();
  $name=e(site_name()); $t=e($title);
  $fav=theme_favicon();
  echo '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="'.e(theme_color('bg')).'">';
  echo '<title>'.$t.' | '.$name.'</title><meta name="description" content="'.e(setting('site_description','')!==''?setting('site_description',''):site_name().' — استقبل رسائل مجهولة وصادقة من أصحابك بخصوصية تامة.').'"><link rel="manifest" href="manifest.php"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'.(logo_url()?'<link rel="apple-touch-icon" href="'.e(logo_url()).'">':'').'';
  echo '<link rel="icon" href="'.$fav.'"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'.font_link().'<link rel="stylesheet" href="style.css?v=21">'.theme_css().seo_head($title).ads_head().setting('custom_head','').(strpos($bodyClass,'dashboard-glass')!==false?'<link rel="stylesheet" href="dashboard-glass.css?v=1"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&amp;family=Noto+Kufi+Arabic:wght@400;500;600;700&amp;display=swap">':'').(basename($_SERVER['SCRIPT_NAME']??'')==='analysis.php'?'<link rel="stylesheet" href="ai-analysis.css?v=4">':'').(strpos($bodyClass,'social-lab')!==false?'<link rel="stylesheet" href="social-lab.css?v=8">':'').'<style>.ad-slot{max-width:1100px;margin:18px auto;padding:0 16px;text-align:center;overflow:hidden}.ad-label{display:block;font-size:11px;color:var(--muted);margin-bottom:4px;letter-spacing:.5px}.ad-inner{min-height:90px;display:flex;justify-content:center;align-items:center}.ad-inner ins{display:block;width:100%}@media(max-width:600px){.ad-inner{min-height:60px}}</style></head><body class="'.e($bodyClass).'">';
  echo '<header class="top"><div class="wrap top-in">'.brand();
  echo '<nav class="nav" aria-label="القائمة الرئيسية"><a href="index.php">الرئيسية</a><a href="index.php#how">كيف يعمل</a><a href="social-lab.php">المختبر الاجتماعي AI</a><a href="blog.php">المدونة</a><a href="about.php">حول أسرار</a><a href="contact.php">اتصل بنا</a></nav><div class="nav-actions">';
  if($u){
    echo '<a class="btn sm" href="dashboard.php">'.icon('inbox').'<span class="hide-sm">رسائلي</span></a>';
    echo '<details class="umenu"><summary class="umenu-btn" aria-label="قائمة حسابي">'.avatar_html($u,'sm','span').'<span class="umenu-name hide-sm">'.e($u['display_name']).'</span>'.icon('chevron','i umenu-chev').'</summary>';
    echo '<div class="umenu-pop" role="menu"><div class="umenu-head">'.avatar_html($u,'','span').'<div><b>'.e($u['display_name']).'</b><small dir="ltr">@'.e($u['username']).'</small></div></div>';
    echo '<a class="umenu-cta" href="account.php?t=profile">'.icon('edit').'<span>تعديل الملف الشخصي</span></a>';
    echo '<nav class="umenu-list"><a href="account.php">'.icon('grid').'<span>لوحة حسابي</span></a><a href="dashboard.php">'.icon('inbox').'<span>صندوق الرسائل</span></a><a href="social-lab.php">'.icon('activity').'<span>المختبر الاجتماعي AI</span></a><a href="account.php?t=security">'.icon('key').'<span>الأمان وكلمة المرور</span></a>';
    if($u['is_admin']) echo '<a href="admin.php">'.icon('shield').'<span>لوحة الإدارة</span></a>';
    echo '</nav><form method="post" action="logout.php" class="umenu-out">'.csrf_field().'<button>'.icon('logout').'<span>تسجيل الخروج</span></button></form></div></details>';
  } else {
    echo '<div class="auth-actions"><a class="btn sm ghost" href="auth.php?m=login">تسجيل الدخول</a><a class="btn sm" href="auth.php">إنشاء حساب</a></div>';
  }
  echo theme_picker_html().'</div></div></header>';
  echo announcement_bar();
  echo '<main id="main">'.ad_slot('top');
}

function announcement_bar(){
  if(setting('ann_active','0')!=='1' || trim(setting('ann_text',''))==='') return '';
  $type=in_array(setting('ann_type','info'),['info','success','warning'],true)?setting('ann_type','info'):'info';
  return '<div class="announce '.$type.'" role="status"><div class="wrap announce-in">'.icon($type==='warning'?'alert':($type==='success'?'check':'megaphone')).'<span>'.e(setting('ann_text')).'</span></div></div>';
}

function maintenance_guard(){
  if(setting('maintenance','0')!=='1') return;
  $script=basename($_SERVER['SCRIPT_NAME']??'');
  if(in_array($script,['auth.php','logout.php','admin.php','install.php'],true)) return;
  $u=me(); if($u && $u['is_admin']) return;
  http_response_code(503); header('Retry-After: 3600');
  head('الموقع تحت الصيانة');
  echo '<section class="page narrow center"><div class="empty big"><span class="empty-icon">'.icon('wrench').'</span><h1>الموقع تحت الصيانة</h1><p>'.e(setting('maintenance_msg','نعمل على تحسين الموقع، سنعود قريبًا.')).'</p></div></section>';
  foot(); exit;
}

function foot(){
  $name=e(site_name());
  echo ad_slot('bottom').'</main><footer class="footer"><div class="wrap footer-in"><div class="footer-brand">'.brand().'<p>مساحة آمنة للكلام الصادق. بدون أسماء، بدون أحكام.</p></div>';
  echo '<nav class="footer-links" aria-label="روابط التذييل"><a href="index.php#how">كيف يعمل</a><a href="blog.php">المدونة</a><a href="about.php">حول أسرار</a><a href="contact.php">اتصل بنا</a><a href="auth.php">إنشاء حساب</a></nav>';
  $soc=''; foreach(social_links() as $k=>[$l,$base]){ $v=trim(setting('social_'.$k,'')); if($v==='') continue; $href=preg_match('#^https://#',$v)?$v:$base.rawurlencode(ltrim($v,'@')); $soc.='<a href="'.e($href).'" target="_blank" rel="noopener">'.e($l).'</a>'; }
  if($soc) echo '<nav class="footer-links footer-social" aria-label="حساباتنا">'.$soc.'</nav>';
  echo '<div class="copyright">© '.ar_num(date('Y')).' '.$name.'. جميع الحقوق محفوظة.</div></div></footer>';
  echo '<script>document.addEventListener("click",function(e){var b=e.target.closest("[data-copy]");if(!b)return;var t=document.getElementById(b.dataset.copy);if(!t)return;navigator.clipboard.writeText(t.value||t.textContent).then(function(){var l=b.querySelector("span");if(!l)return;var o=l.textContent;l.textContent="تم النسخ";b.classList.add("done");setTimeout(function(){l.textContent=o;b.classList.remove("done")},1800)})});document.querySelectorAll("textarea[data-count]").forEach(function(t){var c=document.getElementById(t.dataset.count);var u=function(){c.textContent=t.value.length+" / "+t.maxLength};t.addEventListener("input",u);u()});</script>';
  echo '<script>document.addEventListener("click",function(e){document.querySelectorAll("details.umenu[open],details.tsw[open]").forEach(function(d){if(!d.contains(e.target))d.removeAttribute("open")})});document.addEventListener("keydown",function(e){if(e.key==="Escape")document.querySelectorAll("details.umenu[open],details.tsw[open]").forEach(function(d){d.removeAttribute("open")})});</script>';
  echo setting('custom_footer','');
  if(setting('support_enabled','1')==='1') echo '<script>window.SUP_CFG='.json_encode(['url'=>'support.php','csrf'=>csrf(),'guest'=>!me()]).';</script><script src="support-widget.js?v=1" defer></script>';
  echo '<script src="avatar-viewer.js?v=1" defer></script></body></html>';
}

function alert_box($msg,$type='err'){
  return '<div class="alert '.($type==='ok'?'ok':'err').'" role="'.($type==='ok'?'status':'alert').'">'.icon($type==='ok'?'check':'alert').'<span>'.e($msg).'</span></div>';
}

me(); // Record only the authenticated visitor, never the profile being viewed.
maintenance_guard();

// أدوات مشاركة الرابط: واتساب، X، تيليجرام، مشاركة الجهاز، ورمز QR قابل للتنزيل
function share_tools_html($link,$text='أرسل لي رسالة مجهولة بصدق: '){
  static $n=0; $n++; $id='qr'.$n;
  $h='<div class="share-row">';
  $h.='<a class="chip share-wa" target="_blank" rel="noopener noreferrer" href="https://wa.me/?text='.rawurlencode($text.$link).'">واتساب</a>';
  $h.='<a class="chip share-x" target="_blank" rel="noopener noreferrer" href="https://x.com/intent/post?text='.rawurlencode($text).'&url='.rawurlencode($link).'">X (تويتر)</a>';
  $h.='<a class="chip" target="_blank" rel="noopener noreferrer" href="https://t.me/share/url?url='.rawurlencode($link).'&text='.rawurlencode($text).'">تيليجرام</a>';
  $h.='<a class="chip share-facebook" target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/sharer/sharer.php?u='.rawurlencode($link).'">فيسبوك</a>';
  $h.='<button type="button" class="chip" data-qr-toggle="'.$id.'" aria-expanded="false">رمز QR</button>';
  $h.='<button type="button" class="chip" data-native-share data-url="'.e($link).'" data-text="'.e($text).'" hidden>مشاركة…</button>';
  $h.='<a class="chip" target="_blank" rel="noopener" href="'.e($link).'">معاينة صفحتك</a>';
  $h.='</div>';
  $h.='<div class="qr-box" id="'.$id.'" data-link="'.e($link).'" hidden><div class="qr-canvas" aria-label="رمز QR لرابطك"></div><div class="qr-side"><b>امسح الرمز للوصول لصفحتك</b><small>اطبعه أو ضعه في القصة ليصلك الكلام المجهول</small><button type="button" class="btn" data-qr-download="'.$id.'">تنزيل الصورة</button></div></div>';
  static $js=false;
  if(!$js){ $js=true; $h.='<script>(function(){
function load(cb){if(window.qrcode)return cb();var s=document.createElement("script");s.src="qrcode.js";s.onload=cb;document.head.appendChild(s);}
function draw(box){if(box.dataset.done)return;var q=qrcode(0,"M");q.addData(box.dataset.link);q.make();var n=q.getModuleCount(),sc=8,pad=4,sz=(n+pad*2)*sc,c=document.createElement("canvas");c.width=c.height=sz;var x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,sz,sz);x.fillStyle="#111";for(var r=0;r<n;r++)for(var k=0;k<n;k++)if(q.isDark(r,k))x.fillRect((k+pad)*sc,(r+pad)*sc,sc,sc);box.querySelector(".qr-canvas").appendChild(c);box.dataset.done=1;}
document.querySelectorAll("[data-native-share]").forEach(function(b){if(navigator.share)b.hidden=false;});
document.addEventListener("click",function(e){var t=e.target.closest("[data-qr-toggle]");if(t){var box=document.getElementById(t.dataset.qrToggle);var open=box.hidden;box.hidden=!open;t.setAttribute("aria-expanded",open);if(open)load(function(){draw(box)});return;}
var d=e.target.closest("[data-qr-download]");if(d){var c=document.querySelector("#"+d.dataset.qrDownload+" canvas");if(!c)return;var a=document.createElement("a");a.download="asrar-qr.png";a.href=c.toDataURL("image/png");a.click();return;}
var s=e.target.closest("[data-native-share]");if(s&&navigator.share){navigator.share({title:document.title,text:s.dataset.text,url:s.dataset.url}).catch(function(){});}});})();</script>'; }
  return $h;
}
