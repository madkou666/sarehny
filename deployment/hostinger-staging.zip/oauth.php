<?php require 'inc.php';
// تسجيل الدخول عبر Google و Facebook — الإعدادات من لوحة التحكم > الإعدادات
$p=$_GET['p'] ?? '';
$providers=oauth_providers();
if(!isset($providers[$p]) || !oauth_enabled($p)){ flash('الدخول عبر '.($providers[$p]['name']??'هذه الخدمة').' لم يُفعَّل بعد من لوحة الإدارة','err'); header('Location: auth.php?m=login'); exit; }
$cfg=$providers[$p]; $redirect=oauth_redirect_uri($p);
$cid=setting($p.'_client_id',''); $secret=setting($p.'_client_secret','');

function oauth_fail($m){ flash($m,'err'); header('Location: auth.php?m=login'); exit; }
function oauth_http($url,$post=null,$headers=[]){
  if(function_exists('curl_init')){
    $c=curl_init($url); curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>15,CURLOPT_HTTPHEADER=>array_merge(['Accept: application/json'],$headers)]);
    if($post!==null){ curl_setopt($c,CURLOPT_POST,true); curl_setopt($c,CURLOPT_POSTFIELDS,http_build_query($post)); }
    $r=curl_exec($c); curl_close($c);
  } else {
    $opt=['http'=>['method'=>$post!==null?'POST':'GET','timeout'=>15,'ignore_errors'=>true,'header'=>implode("\r\n",array_merge(['Accept: application/json','Content-Type: application/x-www-form-urlencoded'],$headers))]];
    if($post!==null) $opt['http']['content']=http_build_query($post);
    $r=@file_get_contents($url,false,stream_context_create($opt));
  }
  $j=json_decode((string)$r,true); return is_array($j)?$j:[];
}

// إكمال إنشاء حساب Facebook عند عدم مشاركة البريد (الصلاحية غير مطلوبة أو رفضها المستخدم)
if(!empty($_GET['complete'])){
  $pend=$_SESSION['oauth_pending'] ?? null;
  if(!$pend || $pend['p']!==$p || $pend['t']<time()-900){ unset($_SESSION['oauth_pending']); oauth_fail('انتهت صلاحية الطلب، حاول مرة أخرى'); }
  $err='';
  if($_SERVER['REQUEST_METHOD']==='POST'){
    check_csrf(); $email=strtolower(trim((string)($_POST['email']??'')));
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) $err='البريد الإلكتروني غير صالح';
    else { $s=$pdo->prepare('SELECT 1 FROM users WHERE email=?'); $s->execute([$email]);
      if($s->fetch()) $err='هذا البريد مسجّل بالفعل. سجّل الدخول بكلمة المرور ثم اربط Facebook من إعدادات الحساب.';
      else { unset($_SESSION['oauth_pending']); oauth_create_user($p,$pend['pid'],$email,$pend['name']); } }
  }
  head('إكمال إنشاء الحساب','auth-page'); ?>
<section class="auth"><div class="auth-card"><div class="auth-form" style="padding:24px">
  <h1>خطوة أخيرة</h1><p class="muted">لم يشارك Facebook بريدك الإلكتروني. أدخل بريدك لإكمال إنشاء الحساب.</p>
  <?=$err?alert_box($err):''?>
  <form method="post" class="form"><?=csrf_field()?><div class="field"><label for="em">البريد الإلكتروني</label><input id="em" name="email" type="email" dir="ltr" required autocomplete="email"></div>
  <button class="btn primary">إنشاء الحساب</button></form>
  <?php if(setting('facebook_email_scope','0')==='1'): ?><p class="muted sm"><a href="oauth.php?p=facebook&amp;rerequest=1">أو اسمح لـ Facebook بمشاركة بريدك</a></p><?php endif; ?>
</div></div></section>
<?php foot(); exit;
}

function oauth_create_user($p,$pid,$email,$name){ global $pdo; $col=$p.'_id';
  $base=preg_replace('/[^a-z0-9_]/','',strtolower(strstr($email,'@',true))); $base=substr($base?:'user',0,22); if(strlen($base)<3) $base.='_'.$p;
  $un=$base; $chk=$pdo->prepare('SELECT 1 FROM users WHERE username=?');
  for($i=0;$i<20;$i++){ $chk->execute([$un]); if(!$chk->fetch()) break; $un=$base.'_'.random_int(100,99999); }
  $name=mb_substr(trim($name)?:$un,0,80);
  $pdo->prepare("INSERT INTO users(username,display_name,email,password_hash,$col) VALUES(?,?,?,?,?)")->execute([$un,$name,$email,password_hash(bin2hex(random_bytes(24)),PASSWORD_DEFAULT),$pid]);
  session_regenerate_id(true); $_SESSION['uid']=(int)$pdo->lastInsertId();
  flash('أهلًا بك! تم إنشاء حسابك عبر '.oauth_providers()[$p]['name'].'. يمكنك تعديل اسم المستخدم من إعدادات الحساب.'); header('Location: dashboard.php'); exit;
}

if(isset($_GET['error'])) oauth_fail('تم إلغاء تسجيل الدخول');

if(empty($_GET['code'])){
  $_SESSION['oauth_state']=bin2hex(random_bytes(16));
  $q=['client_id'=>$cid,'redirect_uri'=>$redirect,'response_type'=>'code','state'=>$_SESSION['oauth_state'],'scope'=>oauth_scope($p)];
  if($p==='google') $q['prompt']='select_account';
  if($p==='facebook' && !empty($_GET['rerequest'])) $q['auth_type']='rerequest'; // re-ask for a declined email permission
  header('Location: '.$cfg['auth'].'?'.http_build_query($q)); exit;
}

if(empty($_SESSION['oauth_state']) || !hash_equals($_SESSION['oauth_state'],(string)($_GET['state']??''))) oauth_fail('انتهت صلاحية الطلب، حاول مرة أخرى');
unset($_SESSION['oauth_state']);

$tok=oauth_http($cfg['token'],['client_id'=>$cid,'client_secret'=>$secret,'redirect_uri'=>$redirect,'code'=>$_GET['code'],'grant_type'=>'authorization_code']);
$at=$tok['access_token'] ?? ''; if(!$at) oauth_fail('تعذّر التحقق من الحساب. راجع إعدادات '.$cfg['name'].' في لوحة التحكم.');

if($p==='google'){
  $info=oauth_http('https://openidconnect.googleapis.com/v1/userinfo',null,['Authorization: Bearer '.$at]);
  $pid=(string)($info['sub']??''); $email=strtolower((string)($info['email']??'')); $name=(string)($info['name']??'');
  if($email && empty($info['email_verified'])) $email='';
} else {
  $proof=hash_hmac('sha256',$at,$secret);
  $info=oauth_http($cfg['graph'].'/me?'.http_build_query(['fields'=>'id,name,email','access_token'=>$at,'appsecret_proof'=>$proof]));
  $pid=(string)($info['id']??''); $email=strtolower((string)($info['email']??'')); $name=(string)($info['name']??'');
}
if(!$pid) oauth_fail('تعذّر قراءة بيانات الحساب من '.$cfg['name']);
$col=$p.'_id';

$s=$pdo->prepare("SELECT * FROM users WHERE $col=?"); $s->execute([$pid]); $u=$s->fetch();
// ربط حساب للمستخدم المسجّل حاليًا
if(me() && !$u){ $pdo->prepare("UPDATE users SET $col=? WHERE id=?")->execute([$pid,me()['id']]); flash('تم ربط حساب '.$cfg['name'].' بحسابك'); header('Location: account.php'); exit; }
if(!$u && $email && filter_var($email,FILTER_VALIDATE_EMAIL)){
  $s=$pdo->prepare('SELECT * FROM users WHERE email=?'); $s->execute([$email]); $u=$s->fetch();
  if($u) $pdo->prepare("UPDATE users SET $col=? WHERE id=?")->execute([$pid,$u['id']]);
}
if(!$u){
  if(setting('allow_register','1')!=='1') oauth_fail('التسجيل مغلق حاليًا، حاول لاحقًا');
  if(!$email){ // لا بريد من المزوّد: نطلبه من المستخدم بدل الفشل
    $_SESSION['oauth_pending']=['p'=>$p,'pid'=>$pid,'name'=>$name,'t'=>time()];
    header('Location: oauth.php?p='.$p.'&complete=1'); exit; }
  oauth_create_user($p,$pid,$email,$name);
}
if($u['is_disabled']) oauth_fail('هذا الحساب معطّل. تواصل مع الإدارة.');
session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; header('Location: dashboard.php'); exit;
