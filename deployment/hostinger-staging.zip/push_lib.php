<?php
/* إشعارات الموبايل (Web Push) بدون مكتبات خارجية: VAPID + تشفير aes128gcm */
function b64u($s){return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
function b64u_dec($s){return base64_decode(strtr($s,'-_','+/').str_repeat('=',(4-strlen($s)%4)%4));}
function push_ec_raw($key){ $d=openssl_pkey_get_details($key)['ec']; return "\x04".str_pad($d['x'],32,"\0",STR_PAD_LEFT).str_pad($d['y'],32,"\0",STR_PAD_LEFT); }
function push_pub_from_raw($raw){ $der=hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').$raw;
  return openssl_pkey_get_public("-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($der),64,"\n")."-----END PUBLIC KEY-----\n"); }
function push_vapid(){
  $pem=setting('vapid_private','');
  if($pem===''){
    $k=openssl_pkey_new(['curve_name'=>'prime256v1','private_key_type'=>OPENSSL_KEYTYPE_EC]); if(!$k) return null;
    openssl_pkey_export($k,$pem); save_setting('vapid_private',$pem); save_setting('vapid_public',b64u(push_ec_raw($k)));
    return ['pem'=>$pem,'pub'=>b64u(push_ec_raw($k))];
  }
  return ['pem'=>$pem,'pub'=>setting('vapid_public','')];
}
function push_der_to_raw($der){
  $o=2; $len=ord($der[1]); if($len&0x80) $o=2+($len&0x7f);
  $rl=ord($der[$o+1]); $r=substr($der,$o+2,$rl); $o=$o+2+$rl; $sl=ord($der[$o+1]); $s=substr($der,$o+2,$sl);
  $fix=fn($x)=>str_pad(ltrim($x,"\0"),32,"\0",STR_PAD_LEFT);
  return $fix($r).$fix($s);
}
function push_jwt($aud,$vapid){
  $h=b64u(json_encode(['typ'=>'JWT','alg'=>'ES256'])); $c=b64u(json_encode(['aud'=>$aud,'exp'=>time()+43200,'sub'=>'mailto:admin@'.($_SERVER['HTTP_HOST']??'example.com')]));
  openssl_sign("$h.$c",$sig,$vapid['pem'],OPENSSL_ALGO_SHA256);
  return "$h.$c.".b64u(push_der_to_raw($sig));
}
function push_encrypt($payload,$p256dh,$auth){
  $uaPub=b64u_dec($p256dh); $authSecret=b64u_dec($auth);
  $as=openssl_pkey_new(['curve_name'=>'prime256v1','private_key_type'=>OPENSSL_KEYTYPE_EC]); $asPub=push_ec_raw($as);
  $shared=openssl_pkey_derive(push_pub_from_raw($uaPub),$as,32); if($shared===false) return null;
  $ikm=hash_hmac('sha256',"WebPush: info\0".$uaPub.$asPub."\x01",hash_hmac('sha256',$shared,$authSecret,true),true);
  $salt=random_bytes(16); $prk=hash_hmac('sha256',$ikm,$salt,true);
  $cek=substr(hash_hmac('sha256',"Content-Encoding: aes128gcm\0\x01",$prk,true),0,16);
  $nonce=substr(hash_hmac('sha256',"Content-Encoding: nonce\0\x01",$prk,true),0,12);
  $ct=openssl_encrypt($payload."\x02",'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag);
  return $salt.pack('N',4096).chr(65).$asPub.$ct.$tag;
}
function push_send_one($sub,$payload,$vapid){
  $u=parse_url($sub['endpoint']); if(empty($u['scheme'])||$u['scheme']!=='https') return 410;
  $body=push_encrypt($payload,$sub['p256dh'],$sub['auth']); if($body===null) return 0;
  $ch=curl_init($sub['endpoint']);
  curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>5,CURLOPT_HTTPHEADER=>[
    'Content-Type: application/octet-stream','Content-Encoding: aes128gcm','TTL: 86400','Urgency: high',
    'Authorization: vapid t='.push_jwt($u['scheme'].'://'.$u['host'],$vapid).', k='.$vapid['pub']]]);
  curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return $code;
}
/* يرسل إشعارًا لكل أجهزة المستخدم ويحذف الاشتراكات المنتهية */
function push_notify_user($uid,$title,$body,$url='dashboard.php'){
  global $pdo;
  if(!function_exists('curl_init') || !function_exists('openssl_pkey_derive')) return 0;
  $vapid=push_vapid(); if(!$vapid) return 0;
  $s=$pdo->prepare('SELECT id,endpoint,p256dh,auth FROM push_subs WHERE user_id=?'); $s->execute([$uid]); $ok=0;
  $base=(( !empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http').'://'.($_SERVER['HTTP_HOST']??'').rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/')),'/').'/';
  $icon=logo_url()?$base.logo_url():null;
  $payload=json_encode(['title'=>$title,'body'=>$body,'url'=>$url,'icon'=>$icon,'tag'=>'asrar-'.time().'-'.mt_rand(100,999)],JSON_UNESCAPED_UNICODE);
  foreach($s->fetchAll() as $sub){
    $code=push_send_one($sub,$payload,$vapid);
    if($code===404||$code===410) $pdo->prepare('DELETE FROM push_subs WHERE id=?')->execute([$sub['id']]);
    elseif($code>=200&&$code<300) $ok++;
  }
  return $ok;
}
