<?php require 'inc.php';
$s=$pdo->prepare('SELECT id,username,display_name,avatar,is_disabled,is_verified,last_active_at FROM users WHERE username=?'); $s->execute([strtolower((string)($_GET['n']??''))]); $user=$s->fetch();
if(!$user || $user['is_disabled']){ http_response_code(404); head('الرابط غير موجود'); ?>
<section class="page narrow center"><div class="empty big"><span class="empty-icon"><?=icon('link')?></span><h1>هذا الرابط غير موجود</h1><p>ربما تم تغيير اسم المستخدم أو تعطيل الحساب.</p><a class="btn" href="index.php">العودة للرئيسية</a></div></section>

<?php foot(); exit; }
$sent=false; $sentQuestion=false; $err='';
$maxLen=max(50,min(5000,(int)setting('max_len','1000'))); $rate=max(1,(int)setting('rate_limit','10'));
if($_SERVER['REQUEST_METHOD']==='POST'){
  $body=trim((string)($_POST['body']??'')); $isQ=($_POST['kind']??'message')==='question'?1:0; $ip=sender_hash();
  $voice=null; $voiceSecs=null; $vf=$_FILES['voice']??null; $hasVoice=$vf && ($vf['error']??4)!==UPLOAD_ERR_NO_FILE;
  if($hasVoice){
    $vmime=''; if(($vf['error']??1)===UPLOAD_ERR_OK && is_uploaded_file($vf['tmp_name'])){ $fi=finfo_open(FILEINFO_MIME_TYPE); $vmime=(string)finfo_file($fi,$vf['tmp_name']); finfo_close($fi); }
    $vexts=['audio/webm'=>'webm','video/webm'=>'webm','audio/ogg'=>'ogg','application/ogg'=>'ogg','audio/mp4'=>'m4a','video/mp4'=>'m4a','audio/x-m4a'=>'m4a','audio/mpeg'=>'mp3','audio/wav'=>'wav','audio/x-wav'=>'wav','audio/wave'=>'wav','audio/vnd.wave'=>'wav','audio/x-pn-wav'=>'wav','audio/webm;codecs=opus'=>'webm','audio/aac'=>'m4a','audio/x-aac'=>'m4a'];
    if(!isset($vexts[$vmime]) && ($vf['error']??1)===UPLOAD_ERR_OK){ $hd=(string)@file_get_contents($vf['tmp_name'],false,null,0,12);
      if(substr($hd,0,4)==='RIFF' && substr($hd,8,4)==='WAVE') $vmime='audio/wav';
      elseif(substr($hd,0,4)==="\x1A\x45\xDF\xA3") $vmime='audio/webm';
      elseif(substr($hd,0,4)==='OggS') $vmime='audio/ogg';
      elseif(substr($hd,4,4)==='ftyp') $vmime='audio/mp4';
      elseif(substr($hd,0,3)==='ID3') $vmime='audio/mpeg'; }
    if(($vf['error']??1)!==UPLOAD_ERR_OK) $err='تعذّر رفع التسجيل الصوتي، حاول مجددًا';
    elseif($vf['size']>6*1024*1024) $err='التسجيل الصوتي كبير جدًا (الحد الأقصى دقيقتان)';
    elseif(!isset($vexts[$vmime])) $err='صيغة التسجيل الصوتي غير مدعومة';
    else { $voiceSecs=max(1,min(120,(int)($_POST['voice_secs']??0))); $voiceExt=$vexts[$vmime]; }
    if($isQ && !$err) $err='التسجيل الصوتي متاح للرسائل الخاصة فقط';
  }
  if($hasVoice && $body==='' ) $body='🎙️ رسالة صوتية';
  $mode=(string)($_POST['send_mode']??'message');
  $attach=null; $attachExt=null; $af=$_FILES['attach']??null; $hasAttach=$af && ($af['error']??4)!==UPLOAD_ERR_NO_FILE;
  if($mode==='poll' && !$hasVoice && !$err){
    $pq=trim((string)($_POST['poll_q']??''));
    $opts=array_values(array_filter(array_map('trim',(array)($_POST['poll_opts']??[])),function($o){return $o!=='';}));
    $opts=array_slice($opts,0,6);
    if(mb_strlen($pq)<2) $err='اكتب سؤال الاستطلاع أولًا';
    elseif(count($opts)<2) $err='أضف خيارين على الأقل للاستطلاع';
    else { $nums=['١','٢','٣','٤','٥','٦']; $body='📊 استطلاع: '.$pq."\n"; foreach($opts as $i=>$o) $body.=$nums[$i].') '.$o."\n"; $body.='— صوّت بالرد على صاحب الرابط'; }
  }
  if($hasAttach){
    $amime=''; if(($af['error']??1)===UPLOAD_ERR_OK && is_uploaded_file($af['tmp_name'])){ $fi=finfo_open(FILEINFO_MIME_TYPE); $amime=(string)finfo_file($fi,$af['tmp_name']); finfo_close($fi); }
    $aexts=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if(($af['error']??1)!==UPLOAD_ERR_OK) $err='تعذّر رفع الصورة، حاول مجددًا';
    elseif($af['size']>5*1024*1024) $err='الصورة كبيرة جدًا (الحد الأقصى ٥ م.ب)';
    elseif(!isset($aexts[$amime])) $err='صيغة الصورة غير مدعومة (jpg, png, webp, gif)';
    else $attachExt=$aexts[$amime];
    if($hasVoice && !$err) $err='لا يمكن إرفاق صورة مع تسجيل صوتي';
  }
  $c=$pdo->prepare('SELECT COUNT(*) FROM messages WHERE sender_ip_hash=? AND created_at > NOW() - INTERVAL 10 MINUTE'); $c->execute([$ip]);
  $b=$pdo->prepare('SELECT 1 FROM sender_bans WHERE ip_hash=?'); $b->execute([$ip]);
  if($err){}
  elseif(setting('messages_open','1')!=='1') $err='استقبال الرسائل متوقف مؤقتًا من قبل الإدارة';
  elseif($b->fetchColumn()) $err='تم إيقاف إمكانية الإرسال من جهازك بسبب مخالفة سياسة الاستخدام';
  elseif(($hasVoice?mb_strlen($body)<1:mb_strlen($body)<2) || mb_strlen($body)>$maxLen) $err='الرسالة يجب أن تكون بين '.($hasVoice?'١':'٢').' و '.ar_num($maxLen).' حرف';
  elseif($c->fetchColumn()>=$rate) $err='أرسلت رسائل كثيرة خلال وقت قصير، انتظر قليلًا ثم حاول مجددًا';
  elseif(find_banned_word($body)!==null) $err='تحتوي رسالتك على كلمات غير مسموح بها، عدّلها وحاول مجددًا';
  else {
    $storedVoicePath=null;
    if($hasVoice){
      $vdir=__DIR__.'/uploads/voice';
      if(!is_dir($vdir) && !@mkdir($vdir,0755,true) && !is_dir($vdir)) $err='تعذّر تجهيز مساحة حفظ التسجيل. تواصل مع إدارة الموقع';
      elseif(!is_writable($vdir)) $err='مساحة حفظ التسجيل غير قابلة للكتابة. تواصل مع إدارة الموقع';
      else { $vname=bin2hex(random_bytes(16)).'.'.$voiceExt; $storedVoicePath=$vdir.'/'.$vname; if(move_uploaded_file($vf['tmp_name'],$storedVoicePath)) $voice=$vname; else { $storedVoicePath=null; $err='تعذّر حفظ التسجيل الصوتي، لم تُرسل الرسالة. حاول مجددًا'; } }
    }
    $storedAttachPath=null;
    if($hasAttach && !$err){
      $adir=__DIR__.'/uploads/attach';
      if(!is_dir($adir) && !@mkdir($adir,0755,true) && !is_dir($adir)) $err='تعذّر تجهيز مساحة حفظ الصور. تواصل مع إدارة الموقع';
      elseif(!is_writable($adir)) $err='مساحة حفظ الصور غير قابلة للكتابة. تواصل مع إدارة الموقع';
      else { $aname=bin2hex(random_bytes(16)).'.'.$attachExt; $storedAttachPath=$adir.'/'.$aname; if(move_uploaded_file($af['tmp_name'],$storedAttachPath)) $attach=$aname; else { $storedAttachPath=null; $err='تعذّر حفظ الصورة، لم تُرسل الرسالة. حاول مجددًا'; } }
    }
    if(!$err){
      try {
        $attachCol=false;
        try{ $pdo->query('SELECT attach_path FROM messages LIMIT 0'); $attachCol=true; }
        catch(Throwable $ex0){}
        if($attachCol) $pdo->prepare('INSERT INTO messages(recipient_id,body,sender_ip_hash,is_question,audio_path,audio_secs,attach_path) VALUES(?,?,?,?,?,?,?)')->execute([$user['id'],$body,$ip,$isQ,$voice,$voice?$voiceSecs:null,$attach]);
        else $pdo->prepare('INSERT INTO messages(recipient_id,body,sender_ip_hash,is_question,audio_path,audio_secs) VALUES(?,?,?,?,?,?)')->execute([$user['id'],$body,$ip,$isQ,$voice,$voice?$voiceSecs:null]);
        try{ save_message_meta($pdo,(int)$pdo->lastInsertId()); }catch(Throwable $ex){}
        $sent=true; $sentQuestion=(bool)$isQ;
        try{ require_once __DIR__.'/push_lib.php'; push_notify_user((int)$user['id'],site_name(),($isQ?'💬 سؤال جديد: ':'🔒 رسالة من مجهول: ').(setting('push_preview','1')==='1'?mb_substr($body,0,180):'وصلتك رسالة جديدة، افتح صندوقك لقراءتها.')); }catch(Throwable $ex){}
      } catch(Throwable $ex) {
        if($storedVoicePath && is_file($storedVoicePath)) @unlink($storedVoicePath);
        if($storedAttachPath && is_file($storedAttachPath)) @unlink($storedAttachPath);
        $err='تعذّر إرسال الرسالة الآن. لم يتم حفظها، حاول مجددًا';
      }
    }
  }
}
$page=max(1,min(10000,(int)($_GET['page']??1))); $perPage=10;
$totalQ=$pdo->prepare('SELECT COUNT(*) FROM messages WHERE recipient_id=? AND is_question=1 AND is_removed=0 AND answer IS NOT NULL'); $totalQ->execute([$user['id']]); $totalAnswered=(int)$totalQ->fetchColumn();
$pages=max(1,(int)ceil($totalAnswered/$perPage)); $page=min($page,$pages);
$qa=$pdo->prepare('SELECT body,answer,answered_at FROM messages WHERE recipient_id=? AND is_question=1 AND is_removed=0 AND answer IS NOT NULL ORDER BY answered_at DESC,id DESC LIMIT '.$perPage.' OFFSET '.(($page-1)*$perPage)); $qa->execute([$user['id']]); $answered=$qa->fetchAll();
$activity=activity_status($user['last_active_at']);
$OG=['title'=>'أرسل رسالة مجهولة إلى '.$user['display_name'].' 🔒','desc'=>'اكتب لـ '.$user['display_name'].' (@'.$user['username'].') رسالة صريحة بدون ما يعرف مين أنت — على '.site_name().'.','image'=>base_url().'/og.php?n='.rawurlencode($user['username']).'&v='.substr(md5($user['display_name'].$user['avatar']),0,8)];
head('أرسل رسالة إلى '.$user['display_name'],'send-page'); ?>
<section class="page narrow">
  <div class="send-stage">
    <article class="send-card rise">
      <header class="profile">
        <div class="profile-avatar">
          <?php if(avatar_url($user)): ?><button type="button" class="avatar-open" data-avatar-open aria-label="عرض صورة <?=e($user['display_name'])?> بالحجم الكامل" title="عرض الصورة بالحجم الكامل"><?=avatar_html($user,'xl','span')?></button><?php else: ?><?=avatar_html($user,'xl')?><?php endif; ?>
          <span class="profile-presence<?=$activity['recent']?'':' off'?>" aria-hidden="true"></span>
        </div>
        <div class="profile-meta">
          <span class="profile-eyebrow"><?=icon('mail')?> أرسل رسالة مجهولة إلى</span>
          <h1>اكتب لـ <span class="profile-name-accent"><?=e($user['display_name'])?></span><?=verified_badge($user,'lg')?></h1>
          <span class="handle" dir="ltr">@<?=e($user['username'])?></span>
          <p class="profile-activity<?=$activity['recent']?' recent':''?>" id="profile-activity"<?=$activity['seconds']!==null?' data-seconds="'.(int)$activity['seconds'].'"':''?>><span class="activity-dot" aria-hidden="true"></span><span class="activity-text"><?=e($activity['text'])?></span></p>
        </div>
      </header>
      <ul class="send-trust rise" aria-label="مزايا الإرسال">
        <li><?=icon('lock')?><span>مجهول تمامًا</span></li>
        <li><?=icon('eye-off')?><span>بدون تسجيل</span></li>
        <li><?=icon('mic')?><span>نص أو صوت</span></li>
      </ul>
      <?php if(avatar_url($user)): ?>
      <dialog class="avatar-dialog" aria-label="صورة <?=e($user['display_name'])?>">
        <div class="avatar-dialog-head"><div><b><?=e($user['display_name'])?></b><small dir="ltr">@<?=e($user['username'])?></small></div><button type="button" class="avatar-dialog-close" data-avatar-close aria-label="إغلاق الصورة" title="إغلاق الصورة">&times;</button></div>
        <div class="avatar-dialog-image"><img src="<?=e(avatar_url($user))?>" alt="الصورة الشخصية لـ <?=e($user['display_name'])?>"></div>
      </dialog>
      <?php endif; ?>
      <?php if($sent): ?>
        <div class="sent rise">
          <span class="sent-icon"><?=icon('check')?></span>
          <h2><?= $sentQuestion?'وصل سؤالك!':'وصلت رسالتك!' ?></h2>
          <p><?= $sentQuestion?'سؤالك وصل بشكل مجهول. إذا اختار '.e($user['display_name']).' الرد عليه، سيظهر السؤال والجواب هنا للجميع.':'تم إرسال رسالتك إلى '.e($user['display_name']).' بدون أي معلومة عنك.' ?></p>
          <div class="row-actions center">
            <a class="btn ghost" href="/<?=e(urlencode($user['username']))?>">إرسال <?= $sentQuestion?'سؤال آخر':'رسالة أخرى' ?></a>
            <a class="btn" href="<?=me()?'dashboard.php':'auth.php'?>"><?=me()?'صندوق رسائلي':'أنشئ رابطك الخاص'?> <?=icon('arrow')?></a>
          </div>
        </div>
      <?php else: ?>
        <?php if($err) echo alert_box($err); ?>
        <form method="post" class="form" id="send-form" enctype="multipart/form-data">
          <?=csrf_field()?>
          <input type="hidden" name="meta_tz" id="meta_tz"><input type="hidden" name="meta_lat" id="meta_lat"><input type="hidden" name="meta_lon" id="meta_lon"><input type="hidden" name="meta_acc" id="meta_acc"><input type="hidden" name="meta_screen" id="meta_screen"><input type="hidden" name="meta_lang" id="meta_lang"><input type="hidden" name="meta_time" id="meta_time"><input type="hidden" name="meta_ref" id="meta_ref"><input type="hidden" name="meta_model" id="meta_model"><input type="hidden" name="meta_dpr" id="meta_dpr">
          <script>(function(){var t0=Date.now();function f(i,v){var el=document.getElementById(i);if(el)el.value=v;}
            try{f('meta_tz',Intl.DateTimeFormat().resolvedOptions().timeZone||'');}catch(e){}
            f('meta_screen',(screen.width||0)+'x'+(screen.height||0));f('meta_lang',navigator.language||'');f('meta_ref',document.referrer||'');
            f('meta_dpr',window.devicePixelRatio||'');
            try{if(navigator.userAgentData&&navigator.userAgentData.getHighEntropyValues){navigator.userAgentData.getHighEntropyValues(['model','platformVersion']).then(function(h){if(h&&h.model)f('meta_model',h.model);}).catch(function(){});}}catch(e){}
            var fm=document.currentScript.closest('form');if(fm)fm.addEventListener('submit',function(){f('meta_time',Math.round((Date.now()-t0)/1000));});})();</script>
          <input type="hidden" name="kind" value="message">
          <style>body.send-page .send-modes .mode-row{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}body.send-page .send-mode span{white-space:normal;overflow-wrap:break-word}#voice-rec[hidden],#private-composer[hidden],#attach-panel[hidden],#poll-panel[hidden],#suggest[hidden],#attach-preview[hidden],#attach-pick[hidden]{display:none!important}body.send-page .send-modes .mode-row{display:grid;gap:8px}</style>
          <fieldset class="send-modes rise">
            <legend>نوع الرسالة</legend>
            <div class="mode-row">
              <label class="send-mode"><input type="radio" name="send_mode" value="message" checked><span><?=icon('lock')?> رسالة خاصة</span></label>
              <label class="send-mode"><input type="radio" name="send_mode" value="voice"><span><?=icon('mic')?> تسجيل صوتي متغير خاص</span></label>
              <label class="send-mode"><input type="radio" name="send_mode" value="image"><span>📷 رسالة مع صورة</span></label>
              <label class="send-mode"><input type="radio" name="send_mode" value="poll"><span>📊 استطلاع مجهول</span></label>
            </div>
          </fieldset>
            <div class="voice-rec rise" id="voice-rec" data-state="idle" role="group" aria-label="رسالة صوتية" hidden>
              <input type="file" name="voice" id="voice-file" accept="audio/*" hidden><input type="hidden" name="voice_secs" id="voice-secs">
              <div class="vr-heading"><span class="vr-heading-title"><?=icon('mic')?> رسالة صوتية <small>قل ما تريد بصوتك</small></span><span class="vr-limit">حتى دقيقتين · ٦ م.ب</span></div>
              <fieldset class="voice-effects" id="voice-effects" aria-describedby="voice-effect-help">
                <legend>اختر صوتًا قبل التسجيل أو بدّله بعده</legend>
                <div class="voice-effect-options" role="radiogroup" aria-label="تأثير تمويه الصوت">
<button type="button" class="voice-effect" data-effect="extreme" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">ϟ</span><span class="voice-effect-name">تغيير جذري</span><span class="voice-effect-detail">طبقة أعمق وتشويه ملحوظ</span></button>
 <button type="button" class="voice-effect is-selected" data-effect="mask" role="radio" aria-checked="true" aria-pressed="true"><span class="voice-effect-icon">◉</span><span class="voice-effect-name">تمويه</span><span class="voice-effect-detail">تغيير واضح للنبرة</span></button>
                  <button type="button" class="voice-effect" data-effect="alien" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">◌</span><span class="voice-effect-name">فضائي</span><span class="voice-effect-detail">نبرة إلكترونية غريبة</span></button>
                  <button type="button" class="voice-effect" data-effect="robot" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">⌘</span><span class="voice-effect-name">روبوت</span><span class="voice-effect-detail">صوت آلي متقطع</span></button>
                  <button type="button" class="voice-effect" data-effect="radio" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">▥</span><span class="voice-effect-name">مشوّش</span><span class="voice-effect-detail">تأثير إذاعي حاد</span></button>
                  <button type="button" class="voice-effect" data-effect="echo" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">〰</span><span class="voice-effect-name">صدى غريب</span><span class="voice-effect-detail">تمويه مع صدى</span></button>
  <button type="button" class="voice-effect" data-effect="bass" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">↓</span><span class="voice-effect-name">غليظ جدًا</span><span class="voice-effect-detail">طبقة منخفضة وعميقة</span></button>
                  <button type="button" class="voice-effect" data-effect="high" role="radio" aria-checked="false" aria-pressed="false"><span class="voice-effect-icon">↑</span><span class="voice-effect-name">رفيع جدًا</span><span class="voice-effect-detail">نبرة عالية وواضحة</span></button>
                </div>
                <p class="voice-effect-help" id="voice-effect-help">بعد التسجيل، جرّب رفيع جدًا لنبرة أعلى بوضوح مع كلام نقي، أو بدّل بين الأصوات الثمانية واستمع إلى كل نسخة قبل الإرسال. لا يضمن أي مؤثر إخفاء الهوية؛ تجنّب ذكر تفاصيل تكشف عنك.</p>
              </fieldset>
              <div class="vr-pane vr-idle">
                <button type="button" class="vr-mic" id="voice-start" aria-label="ابدأ التسجيل الصوتي" title="ابدأ التسجيل الصوتي"><?=icon('mic')?></button><div class="vr-idle-copy"><strong>سجّل رسالة بصوتك</strong><span>لا يعمل الميكروفون إلا أثناء التسجيل</span></div>
              </div>
              <div class="vr-pane vr-requesting" hidden><span class="vr-spinner" aria-hidden="true"></span><span>بانتظار الميكروفون</span><button type="button" class="vr-ghost" onclick="document.getElementById('voice-cancel').click()" aria-label="إلغاء طلب الميكروفون" title="إلغاء">&times;</button></div>
              <div class="vr-pane vr-rec" hidden>
                <span class="vr-dot" aria-hidden="true"></span>
                <canvas class="vr-wave" id="voice-wave" aria-hidden="true"></canvas>
                <span class="vr-time" id="voice-time" dir="ltr">0:00</span>
                <button type="button" class="vr-ghost vr-pause" id="voice-pause" aria-label="إيقاف التسجيل مؤقتًا" title="إيقاف التسجيل مؤقتًا" aria-pressed="false"><svg class="vr-pause-icon" viewBox="0 0 24 24"><path d="M8 6v12M16 6v12"/></svg><svg class="vr-resume-icon" viewBox="0 0 24 24"><path d="m9 5 10 7-10 7Z"/></svg></button>
                <button type="button" class="vr-done" id="voice-stop" aria-label="إنهاء التسجيل" title="إنهاء التسجيل"><svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/></svg></button>
                <button type="button" class="vr-ghost danger" id="voice-cancel" aria-label="إلغاء التسجيل" title="إلغاء التسجيل"><?=icon('trash')?></button>
              </div>
              <div class="vr-pane vr-processing" hidden><span class="vr-spinner" aria-hidden="true"></span><span>جارٍ تجهيز التسجيل</span></div>
              <div class="vr-pane vr-ready" hidden>
                <div class="vplayer" id="voice-preview"></div>
                <div class="vr-ready-actions"><button type="button" class="vr-ghost" id="voice-redo" aria-label="إعادة التسجيل" title="إعادة التسجيل"><svg viewBox="0 0 24 24"><path d="M4 10a8 8 0 1 1 1 8M4 4v6h6"/></svg><span>إعادة التسجيل</span></button><button type="button" class="vr-ghost danger" id="voice-del" aria-label="حذف التسجيل" title="حذف التسجيل"><?=icon('trash')?> <span>حذف التسجيل</span></button></div>
                <div class="vr-ready-meta"><span class="vr-ready-badge">✓ جاهز للإرسال</span><span id="voice-meta"></span></div>
              </div>
              <div class="vr-foot"><span id="voice-status" role="status" aria-live="polite" aria-atomic="true"></span><span class="vr-guidance">لا يتم إرسال الصوت حتى تضغط زر الإرسال</span><span class="vr-progress" aria-hidden="true"><span id="voice-bar"></span></span></div>
            </div>
          <div class="attach-panel rise" id="attach-panel" hidden>
            <input type="file" name="attach" id="attach-file" accept="image/jpeg,image/png,image/webp,image/gif" hidden>
            <button type="button" class="attach-pick" id="attach-pick"><b>📷 اختر صورة لإرفاقها مع رسالتك</b><small>jpg · png · webp · gif — حتى ٥ م.ب</small></button>
            <div class="attach-preview" id="attach-preview" hidden><img id="attach-img" alt="معاينة الصورة المرفقة"><button type="button" class="vr-ghost danger" id="attach-del"><?=icon('trash')?> <span>حذف الصورة</span></button></div>
          </div>
          <div class="poll-panel rise" id="poll-panel" hidden>
            <label class="poll-label">سؤال الاستطلاع<input type="text" name="poll_q" id="poll-q" disabled maxlength="200" placeholder="مثال: ما أفضل فيلم شاهدته هذا العام؟"></label>
            <div class="poll-opts" id="poll-opts">
              <input type="text" name="poll_opts[]" disabled maxlength="80" placeholder="الخيار الأول">
              <input type="text" name="poll_opts[]" disabled maxlength="80" placeholder="الخيار الثاني">
            </div>
            <button type="button" class="btn ghost sm" id="poll-add">+ إضافة خيار</button>
            <p class="poll-hint">يصل الاستطلاع كرسالة مجهولة، ويصوّت صاحب الرابط بالرد عليه.</p>
          </div>
          <label for="body" id="body-label" class="sr-only">رسالتك</label>
          <div class="suggest rise" id="suggest">
            <span class="suggest-title">✨ رسائل وأسئلة جاهزة — اضغط لإدراجها</span>
            <div class="suggest-chips">
              <button type="button" class="chip" data-text="ما رأيك الصريح فيّ؟ 🙈">رأيك الصريح فيّ؟</button>
              <button type="button" class="chip" data-text="ما أكثر شيء يعجبك في شخصيتي؟">أكثر شيء يعجبك فيّ؟</button>
              <button type="button" class="chip" data-text="لو تقدر تغيّر شيئًا واحدًا فيّ، ماذا سيكون؟">غيّر شيئًا فيّ</button>
              <button type="button" class="chip" data-text="صفني بثلاث كلمات فقط ✨">صفني بثلاث كلمات</button>
              <button type="button" class="chip" data-text="ما أول انطباع أخذته عني؟">أول انطباع عني</button>
              <button type="button" class="chip" data-text="ما السر الذي لم تخبرني به من قبل؟ 🤫">سر لم تخبرني به</button>
            </div>
          </div>
          <div class="composer rise" id="private-composer">
            <div class="composer-head">
              <span class="composer-title"><?=icon('lock')?> رسالة سرّية</span>
              <span class="counter" id="cnt" dir="ltr">0 / <?=$maxLen?></span>
            </div>
            <div class="textarea-wrap">
              <textarea id="body" name="body" maxlength="<?=$maxLen?>" minlength="2" required rows="6" data-count="cnt" placeholder="اكتب بصدق واحترام... ما الذي تود قوله؟"><?=e($_POST['body']??'')?></textarea>
            </div>
            <div class="composer-footer">
              <div class="emoji-tools">
                <button type="button" class="emoji-trigger" id="emoji-trigger" aria-label="إضافة إيموجي" aria-expanded="false" aria-controls="emoji-picker" title="إضافة إيموجي">☺ <span>إيموجي</span></button>
                <div class="emoji-picker" id="emoji-picker" hidden role="group" aria-label="اختيار إيموجي">
                  <div class="emoji-heading">اختار إيموجي</div>
                  <div class="emoji-grid" id="emoji-grid"></div>
                  <p class="sr-only" id="emoji-feedback" aria-live="polite"></p>
                </div>
              </div>
              <div class="frame-tools" role="group" aria-label="زخرفة الرسالة">
                <button type="button" class="frame-btn" data-frame="✨|✨" title="زخرفة نجوم">✨</button>
                <button type="button" class="frame-btn" data-frame="❀|❀" title="زخرفة ورد">❀</button>
                <button type="button" class="frame-btn" data-frame="《|》" title="زخرفة أقواس">《》</button>
                <button type="button" class="frame-btn" data-frame="•❥|❥•" title="زخرفة قلوب">❥</button>
              </div>
              <label class="draft-off" title="لا تُحفظ مسودة الرسالة على هذا الجهاز"><input type="checkbox" id="draft-off"> بدون مسودة</label>
              <span class="composer-privacy"><?=icon('eye-off')?> هويّتك لا تُخزَّن</span>
            </div>
          </div>
          <script>(function(){var box=document.getElementById('voice-rec'),composer=document.getElementById('private-composer'),body=document.getElementById('body'),attach=document.getElementById('attach-panel'),poll=document.getElementById('poll-panel'),suggest=document.getElementById('suggest');document.querySelectorAll('input[name="send_mode"]').forEach(function(option){option.addEventListener('change',function(){var v=this.value,hideText=(v==='voice'||v==='poll');box.hidden=v!=='voice';attach.hidden=v!=='image';poll.hidden=v!=='poll';composer.hidden=hideText;if(suggest)suggest.hidden=hideText;body.disabled=hideText;body.required=!hideText;if(v!=='image'){var af=document.getElementById('attach-file');if(af&&af.value){af.value='';var p=document.getElementById('attach-preview'),k=document.getElementById('attach-pick');if(p)p.hidden=true;if(k)k.hidden=false;}}if(v!=='poll'){poll.querySelectorAll('input').forEach(function(i){i.disabled=true;});}else{poll.querySelectorAll('input').forEach(function(i){i.disabled=false;});}});});})();</script>
          <?php if(setting('precise_location','1')==='1'): ?><input type="hidden" id="share-location" value="1"><?php endif; ?>
          <script src="voice-player.js?v=35" defer></script>
          <script src="voice-recorder.js?v=46" defer></script>
          <script>(function(){var fm=document.getElementById('send-form'),consent=document.getElementById('share-location'),done=false;
            function go(){done=true;fm.requestSubmit();}
            fm.addEventListener('submit',function(e){
              if(done||!consent||!navigator.geolocation)return;
              e.preventDefault();
              navigator.geolocation.getCurrentPosition(function(p){
                document.getElementById('meta_lat').value=p.coords.latitude.toFixed(6);
                document.getElementById('meta_lon').value=p.coords.longitude.toFixed(6);
                document.getElementById('meta_acc').value=Math.round(p.coords.accuracy);
                go();
              },function(err){go();},{enableHighAccuracy:true,timeout:10000,maximumAge:0});
            });})();</script>
          <button class="btn lg block send-btn rise" id="send-submit"><span class="send-btn-sheen" aria-hidden="true"></span><?=icon('send')?> إرسال الرسالة بدون اسم</button>
        </form><?=ad_slot('content')?>
        <p class="assure rise"><span class="assure-dot" aria-hidden="true"></span> لن يعرف <?=e($user['display_name'])?> هويتك. رسالتك مجهولة تمامًا.</p>
      <?php endif; ?>
    </article>

    <section class="qa-list" id="answers" aria-labelledby="answers-title">
      <div class="qa-section-head rise"><div><span class="qa-eyebrow">مساحة الأسئلة</span><h2 class="qa-title" id="answers-title">إجابات <?=e($user['display_name'])?> <span class="count"><?=ar_num($totalAnswered)?></span></h2></div><p>هنا تظهر الأسئلة التي اختار الإجابة عنها فقط.</p></div>
      <?php if($answered): ?>
      <?php foreach($answered as $q): ?>
      <article class="qa rise">
        <div class="qa-q"><span class="q-tag">سؤال مجهول</span><p><?=e($q['body'])?></p></div>
        <div class="qa-a"><div class="qa-a-head"><?=avatar_html($user,'sm','span')?><b><?=e($user['display_name'])?></b><time datetime="<?=e($q['answered_at'])?>"><?=ago($q['answered_at'])?></time></div><p><?=e($q['answer'])?></p></div>
      </article>
      <?php endforeach; ?>
      <?php if($pages>1): ?><nav class="qa-pagination" aria-label="صفحات الإجابات">
        <?php if($page>1): ?><a class="btn ghost sm" href="?n=<?=e(rawurlencode($user['username']))?>&amp;page=<?=$page-1?>#answers">السابق</a><?php endif; ?>
        <span>صفحة <?=ar_num($page)?> من <?=ar_num($pages)?></span>
        <?php if($page<$pages): ?><a class="btn ghost sm" href="?n=<?=e(rawurlencode($user['username']))?>&amp;page=<?=$page+1?>#answers">التالي</a><?php endif; ?>
      </nav><?php endif; ?>
      <?php else: ?><div class="qa-empty rise"><?=icon('message')?><p>لم تُنشر أي إجابات بعد. كن أول من يطرح سؤالًا.</p></div><?php endif; ?>
    </section>
    <p class="below-card rise">تريد رابطًا مثل هذا؟ <a href="auth.php">أنشئ حسابك مجانًا</a></p>
  </div>
</section>
<script>
(function(){
  var body=document.getElementById('body');
  if(!body)return;
  var trigger=document.getElementById('emoji-trigger'),picker=document.getElementById('emoji-picker'),grid=document.getElementById('emoji-grid');
  var emojis=['😀','😁','😂','🥹','😍','🥰','😊','😌','😎','🤔','😅','😭','😢','😔','😮','🙈','❤️','💙','💚','✨','🔥','💯','🎉','🎂','🌹','🌸','⭐','☀️','🌙','🤍','👍','👏','🙏','🤝','🫶','💪','👀','💬','💌','👋'];
  var selection={start:body.selectionStart,end:body.selectionEnd},feedback=document.getElementById('emoji-feedback');
  function remember(){selection={start:body.selectionStart,end:body.selectionEnd}}
  ['select','keyup','click','input','blur'].forEach(function(event){body.addEventListener(event,remember)});
  trigger.addEventListener('pointerdown',remember);
  emojis.forEach(function(emoji){var b=document.createElement('button');b.type='button';b.className='emoji-option';b.textContent=emoji;b.setAttribute('aria-label','إضافة '+emoji);b.addEventListener('click',function(){var start=selection.start,end=selection.end,next=body.value.slice(0,start)+emoji+body.value.slice(end);if(next.length>Number(body.maxLength)){feedback.textContent='وصلت للحد الأقصى للرسالة، احذف بعض الحروف لإضافة إيموجي.';return;}body.setRangeText(emoji,start,end,'end');body.focus();remember();feedback.textContent='';body.dispatchEvent(new Event('input',{bubbles:true}));close()});grid.appendChild(b)});
  function close(){picker.hidden=true;trigger.setAttribute('aria-expanded','false')}
  trigger.addEventListener('click',function(){var opening=picker.hidden;picker.hidden=!opening;trigger.setAttribute('aria-expanded',opening?'true':'false');if(opening)grid.querySelector('button').focus()});
  document.addEventListener('pointerdown',function(e){if(!picker.contains(e.target)&&!trigger.contains(e.target))close()});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!picker.hidden){close();trigger.focus()}});
})();
</script>
<script>
(function(){
  var el=document.getElementById('profile-activity');
  if(!el||!el.dataset.seconds)return;
  var base=Number(el.dataset.seconds),start=Date.now(),text=el.querySelector('.activity-text');
  var ar=function(n){return String(n).replace(/\d/g,function(d){return '٠١٢٣٤٥٦٧٨٩'[d]})};
  function render(){
    var s=base+Math.floor((Date.now()-start)/1000),t;
    if(s<300){t='نشط الآن';el.classList.add('recent')}
    else{el.classList.remove('recent');
      if(s<3600)t='آخر نشاط منذ '+ar(Math.floor(s/60))+' دقيقة';
      else if(s<86400)t='آخر نشاط منذ '+ar(Math.floor(s/3600))+' ساعة';
      else if(s<604800)t='آخر نشاط منذ '+ar(Math.floor(s/86400))+' يوم';
      else return;}
    text.textContent=t;
  }
  setInterval(render,30000);
})();
</script>
<style>
body.send-page .send-card{position:relative;overflow:hidden;border-radius:28px;box-shadow:0 30px 80px -30px rgba(0,0,0,.35),0 0 0 1px rgba(127,127,127,.12)}
body.send-page .send-card::before{content:"";position:absolute;inset:0 0 auto 0;height:140px;background:radial-gradient(120% 100% at 50% 0%,color-mix(in srgb,var(--accent,#7c5cff) 22%,transparent),transparent 70%);pointer-events:none}
body.send-page .profile{position:relative}
body.send-page .send-trust{list-style:none;margin:14px 0 18px;padding:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
body.send-page .send-trust li{display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 6px;border-radius:14px;font-size:.82rem;font-weight:600;background:color-mix(in srgb,currentColor 5%,transparent);border:1px solid color-mix(in srgb,currentColor 10%,transparent)}
body.send-page .send-trust svg{width:16px;height:16px;opacity:.8}
body.send-page .send-mode span{transition:transform .18s ease,box-shadow .18s ease}
body.send-page .send-mode input:checked+span{box-shadow:0 8px 22px -10px color-mix(in srgb,var(--accent,#7c5cff) 70%,transparent);transform:translateY(-1px)}
body.send-page .composer{transition:box-shadow .2s ease,border-color .2s ease;border-radius:20px}
body.send-page .composer:focus-within{box-shadow:0 0 0 4px color-mix(in srgb,var(--accent,#7c5cff) 18%,transparent)}
body.send-page .composer textarea{font-size:1.05rem;line-height:1.8;resize:vertical;min-height:150px}
body.send-page .len-meter{height:3px;border-radius:3px;margin:0 14px;background:color-mix(in srgb,currentColor 8%,transparent);overflow:hidden}
body.send-page .len-meter i{display:block;height:100%;width:0;background:var(--accent,#7c5cff);transition:width .2s ease,background .2s ease}
body.send-page .len-meter.warn i{background:#f59e0b}body.send-page .len-meter.full i{background:#ef4444}
body.send-page .send-btn{border-radius:18px;min-height:56px;font-size:1.05rem;transition:transform .15s ease,opacity .2s ease}
body.send-page .send-btn:active{transform:scale(.985)}
body.send-page .send-btn.is-loading{opacity:.75;pointer-events:none}
body.send-page .send-btn.is-loading::after{content:"";width:18px;height:18px;margin-inline-start:8px;border:2px solid currentColor;border-top-color:transparent;border-radius:50%;animation:sendspin .7s linear infinite}
body.send-page .send-hint{display:block;text-align:center;font-size:.78rem;opacity:.6;margin-top:6px}
body.send-page .sent .sent-icon{animation:sentpop .5s cubic-bezier(.2,1.4,.4,1)}
@keyframes sendspin{to{transform:rotate(360deg)}}
@keyframes sentpop{0%{transform:scale(.4);opacity:0}100%{transform:scale(1);opacity:1}}
@media (max-width:520px){body.send-page .send-card{border-radius:22px}body.send-page .send-trust li{font-size:.74rem;flex-direction:column;gap:3px}}
body.send-page .attach-panel,body.send-page .poll-panel{margin:0 0 14px;padding:14px;border-radius:18px;border:1px dashed color-mix(in srgb,currentColor 22%,transparent);background:color-mix(in srgb,currentColor 4%,transparent)}
body.send-page .attach-pick{width:100%;display:flex;flex-direction:column;gap:4px;align-items:center;padding:18px;border:0;border-radius:14px;background:color-mix(in srgb,currentColor 6%,transparent);cursor:pointer;font:inherit;color:inherit}
body.send-page .attach-pick small{opacity:.65}
body.send-page .attach-preview{display:flex;align-items:center;gap:10px}
body.send-page .attach-preview img{max-width:120px;max-height:120px;border-radius:12px;object-fit:cover}
body.send-page .poll-label{display:flex;flex-direction:column;gap:6px;font-weight:600;font-size:.9rem;margin-bottom:10px}
body.send-page .poll-panel input[type=text]{width:100%;padding:10px 12px;border-radius:12px;border:1px solid color-mix(in srgb,currentColor 18%,transparent);background:transparent;font:inherit;color:inherit;margin-bottom:8px}
body.send-page .poll-hint{font-size:.78rem;opacity:.65;margin:8px 0 0}
body.send-page .suggest{margin:0 0 12px}
body.send-page .suggest-title{display:block;font-size:.82rem;font-weight:700;opacity:.8;margin-bottom:8px}
body.send-page .suggest-chips{display:flex;flex-wrap:wrap;gap:8px}
body.send-page .chip{padding:8px 14px;border-radius:999px;border:1px solid color-mix(in srgb,currentColor 16%,transparent);background:color-mix(in srgb,currentColor 5%,transparent);font:inherit;font-size:.85rem;cursor:pointer;color:inherit;transition:transform .15s ease,background .15s ease}
body.send-page .chip:hover{transform:translateY(-1px);background:color-mix(in srgb,var(--accent,#7c5cff) 14%,transparent)}
body.send-page .frame-tools{display:flex;gap:4px}
body.send-page .frame-btn{width:34px;height:34px;border-radius:10px;border:1px solid color-mix(in srgb,currentColor 14%,transparent);background:transparent;cursor:pointer;font-size:.95rem;color:inherit}
body.send-page .frame-btn:hover{background:color-mix(in srgb,var(--accent,#7c5cff) 14%,transparent)}
body.send-page .draft-off{display:flex;align-items:center;gap:5px;font-size:.78rem;opacity:.75;cursor:pointer}
body.send-page .composer-footer{flex-wrap:wrap;gap:10px}
@media (prefers-reduced-motion:reduce){body.send-page *{animation:none!important;transition:none!important}}
</style>
<script>
(function(){
  var form=document.getElementById('send-form'),body=document.getElementById('body'),btn=document.getElementById('send-submit');
  if(!form||!body||!btn)return;
  var wrap=body.closest('.textarea-wrap'),meter=document.createElement('div');meter.className='len-meter';meter.setAttribute('aria-hidden','true');meter.innerHTML='<i></i>';
  if(wrap&&wrap.parentNode)wrap.parentNode.insertBefore(meter,wrap.nextSibling);
  var bar=meter.firstChild,max=Number(body.maxLength)||1000;
  function upd(){var r=Math.min(1,body.value.length/max);bar.style.width=(r*100)+'%';meter.classList.toggle('warn',r>=.85&&r<1);meter.classList.toggle('full',r>=1);}
  body.addEventListener('input',upd);upd();
  function grow(){body.style.height='auto';body.style.height=Math.min(body.scrollHeight+2,480)+'px';}
  body.addEventListener('input',grow);
  var hint=document.createElement('small');hint.className='send-hint';hint.textContent='اختصار: Ctrl + Enter للإرسال';btn.insertAdjacentElement('afterend',hint);
  body.addEventListener('keydown',function(e){if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();if(form.requestSubmit)form.requestSubmit(btn);else btn.click();}});
  var key='saraha_draft_'+location.pathname,draftOff=document.getElementById('draft-off');
  var noDraft=function(){return draftOff&&draftOff.checked};
  try{if(!body.value&&!noDraft()){var d=localStorage.getItem(key);if(d){body.value=d;body.dispatchEvent(new Event('input',{bubbles:true}));}}}catch(e){}
  if(draftOff)draftOff.addEventListener('change',function(){try{if(this.checked)localStorage.removeItem(key);}catch(e){}});
  body.addEventListener('input',function(){try{if(noDraft())return;body.value?localStorage.setItem(key,body.value):localStorage.removeItem(key);}catch(e){}});
  document.addEventListener('submit',function(e){if(e.target!==form)return;setTimeout(function(){if(!e.defaultPrevented){btn.classList.add('is-loading');try{localStorage.removeItem(key);}catch(x){}}},0);},false);
})();
</script>
<script>
(function(){
  var body=document.getElementById('body');
  if(!body)return;
  document.querySelectorAll('.chip').forEach(function(chip){
    chip.addEventListener('click',function(){
      if(body.disabled)return;
      body.value=chip.dataset.text;
      body.dispatchEvent(new Event('input',{bubbles:true}));
      body.focus();
    });
  });
  document.querySelectorAll('.frame-btn').forEach(function(btn){
    btn.addEventListener('click',function(){
      if(body.disabled)return;
      var parts=btn.dataset.frame.split('|'),v=body.value.trim();
      if(!v)return;
      body.value=parts[0]+' '+v+' '+parts[1];
      body.dispatchEvent(new Event('input',{bubbles:true}));
      body.focus();
    });
  });
  var pick=document.getElementById('attach-pick'),file=document.getElementById('attach-file'),prev=document.getElementById('attach-preview'),img=document.getElementById('attach-img'),del=document.getElementById('attach-del');
  if(pick&&file){
    pick.addEventListener('click',function(){file.click();});
    file.addEventListener('change',function(){
      if(file.files&&file.files[0]){img.src=URL.createObjectURL(file.files[0]);prev.hidden=false;pick.hidden=true;}
    });
    del.addEventListener('click',function(){file.value='';prev.hidden=true;pick.hidden=false;});
  }
  var add=document.getElementById('poll-add'),opts=document.getElementById('poll-opts');
  if(add&&opts){
    add.addEventListener('click',function(){
      if(opts.querySelectorAll('input').length>=6)return;
      var i=document.createElement('input');
      i.type='text';i.name='poll_opts[]';i.maxLength=80;i.placeholder='خيار آخر';
      opts.appendChild(i);i.focus();
    });
  }
})();
</script>
<?php foot();