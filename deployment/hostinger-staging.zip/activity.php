<?php
// Activity timestamps use UTC independently of the host's PHP/MySQL timezone.
function record_activity($connection, $userId){
  $connection->prepare('UPDATE users SET last_active_at=UTC_TIMESTAMP() WHERE id=? AND is_disabled=0 AND (last_active_at IS NULL OR last_active_at < UTC_TIMESTAMP() - INTERVAL 1 MINUTE)')->execute([(int)$userId]);
}
function activity_status($value, $now=null){
  if(!$value) return ['recent'=>false,'seconds'=>null,'text'=>'آخر نشاط غير متاح بعد'];
  $date=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',(string)$value,new DateTimeZone('UTC'));
  if(!$date || $date->format('Y-m-d H:i:s')!==$value) return ['recent'=>false,'seconds'=>null,'text'=>'آخر نشاط غير متاح بعد'];
  $seconds=max(0,($now===null?time():$now)-$date->getTimestamp());
  if($seconds<300) return ['recent'=>true,'seconds'=>$seconds,'text'=>'نشط الآن'];
  if($seconds<3600) return ['recent'=>false,'seconds'=>$seconds,'text'=>'آخر نشاط منذ '.ar_num(intdiv($seconds,60)).' دقيقة'];
  if($seconds<86400) return ['recent'=>false,'seconds'=>$seconds,'text'=>'آخر نشاط منذ '.ar_num(intdiv($seconds,3600)).' ساعة'];
  if($seconds<604800) return ['recent'=>false,'seconds'=>$seconds,'text'=>'آخر نشاط منذ '.ar_num(intdiv($seconds,86400)).' يوم'];
  return ['recent'=>false,'seconds'=>$seconds,'text'=>'آخر نشاط بتاريخ '.ar_num($date->format('Y/m/d'))];
}
