<?php require 'inc.php';
if($_SERVER['REQUEST_METHOD']==='POST'){ $_SESSION=[]; session_destroy(); remember_clear(); }
header('Location: index.php'); exit;
