<?php require 'inc.php';
$id=max(0,(int)($_GET['id']??0));$s=$pdo->prepare('SELECT * FROM blog_posts WHERE id=? AND published=1');$s->execute([$id]);$post=$s->fetch();
if(!$post){http_response_code(404);head('المقال غير موجود','content-page');echo '<section class="content-section"><div class="wrap content-empty"><h1>المقال غير موجود</h1><p>ربما حُذف أو لم يُنشر بعد.</p><a class="btn" href="blog.php">العودة للمدونة</a></div></section>';foot();exit;}
head($post['title'],'content-page'); ?>
<article><header class="content-intro"><div class="wrap"><a class="content-kicker" href="blog.php">المدونة / العودة للمقالات</a><h1><?=e($post['title'])?></h1><p><?=e($post['excerpt'])?></p><time datetime="<?=e(date('Y-m-d',strtotime($post['created_at'])))?>"><?=e(date('Y/m/d',strtotime($post['created_at'])))?></time></div></header>
<div class="content-section"><div class="wrap reading-width content-prose"><?php foreach(preg_split('/\R\s*\R/u',trim($post['body'])) as $paragraph):if(trim($paragraph)==='')continue; ?><p><?=nl2br(e(trim($paragraph)))?></p><?php endforeach; ?><a class="text-link" href="blog.php">العودة إلى المدونة <?=icon('arrow')?></a></div></div></article>
<?php foot(); ?>
