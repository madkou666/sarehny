<?php require 'inc.php';
$errors=[];$values=['name'=>'','email'=>'','subject'=>'','body'=>''];
if($_SERVER['REQUEST_METHOD']==='POST'){
 foreach($values as $key=>$_)$values[$key]=trim((string)($_POST[$key]??''));
 if(!empty($_POST['website'])){$errors[]='تعذر إرسال الرسالة، حاول مرة أخرى.';}
 if(mb_strlen($values['name'])<2||mb_strlen($values['name'])>100)$errors[]='الاسم يجب أن يكون بين حرفين و١٠٠ حرف.';
 if(mb_strlen($values['email'])>190||!filter_var($values['email'],FILTER_VALIDATE_EMAIL))$errors[]='أدخل بريدًا إلكترونيًا صحيحًا.';
 if(mb_strlen($values['subject'])<3||mb_strlen($values['subject'])>180)$errors[]='الموضوع يجب أن يكون بين ٣ و١٨٠ حرفًا.';
 if(mb_strlen($values['body'])<10||mb_strlen($values['body'])>5000)$errors[]='الرسالة يجب أن تكون بين ١٠ و٥٠٠٠ حرف.';
 if(!$errors){
  // Limit repeat submissions from the same browser session.
  if(time()-(int)($_SESSION['last_contact_at']??0)<60)$errors[]='انتظر دقيقة قبل إرسال رسالة أخرى.';
  else{$pdo->prepare('INSERT INTO contact_messages(name,email,subject,body) VALUES(?,?,?,?)')->execute(array_values($values));$_SESSION['last_contact_at']=time();flash('وصلت رسالتك بنجاح. شكرًا لتواصلك معنا.');header('Location: contact.php?sent=1');exit;}
 }
}
$notice=flash();head('اتصل بنا','content-page'); ?>
<section class="content-intro"><div class="wrap"><span class="content-kicker">تواصل / أسرار</span><h1>خلّينا نسمعك.</h1><p>لديك فكرة أو سؤال أو ملاحظة؟ اكتب لنا وسنقرأ رسالتك.</p></div></section>
<section class="content-section"><div class="wrap contact-layout"><div><span class="content-kicker">رسالتك تهمنا</span><h2>احكِ لنا ما في بالك.</h2><p>استخدم النموذج لإرسال استفسارك إلى فريق الموقع. لا ترسل كلمة مرورك أو معلومات شخصية حساسة.</p></div><div class="contact-form-wrap">
<?php if($notice): ?><div class="alert <?=e($notice[1])?>" role="status"><?=e($notice[0])?></div><?php endif; ?>
<?php foreach($errors as $error): ?><div class="alert err" role="alert"><?=e($error)?></div><?php endforeach; ?>
<form method="post" class="contact-form"><?=csrf_field()?><div class="contact-honey" aria-hidden="true"><label for="website">اترك هذا الحقل فارغًا</label><input id="website" name="website" tabindex="-1" autocomplete="off"></div>
<div class="contact-fields"><div class="field"><label for="contact-name">الاسم</label><input id="contact-name" name="name" value="<?=e($values['name'])?>" maxlength="100" autocomplete="name" required></div><div class="field"><label for="contact-email">البريد الإلكتروني</label><input id="contact-email" name="email" type="email" dir="ltr" value="<?=e($values['email'])?>" maxlength="190" autocomplete="email" required></div></div>
<div class="field"><label for="contact-subject">الموضوع</label><input id="contact-subject" name="subject" value="<?=e($values['subject'])?>" maxlength="180" required></div>
<div class="field"><label for="contact-body">رسالتك</label><textarea id="contact-body" name="body" rows="7" minlength="10" maxlength="5000" required><?=e($values['body'])?></textarea></div>
<button class="btn" type="submit">أرسل الرسالة <?=icon('arrow')?></button></form></div></div></section>
<?php foot(); ?>
