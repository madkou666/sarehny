<?php
if($_SERVER['REQUEST_METHOD']==='POST'&&in_array((string)($_POST['action']??''),['test','save'],true)) define('AI_ADMIN_API_REQUEST',true);
function ai_admin_reply($status,array $data){http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
require_once __DIR__.'/inc.php';
require_once __DIR__.'/ai_module.php';
if(defined('AI_ADMIN_API_REQUEST')){
  $admin=me();
  if(!$admin) ai_admin_reply(401,['ok'=>false,'message'=>'انتهت جلسة تسجيل الدخول. سجّل الدخول مجددًا ثم أعد المحاولة.']);
  if(empty($admin['is_admin'])) ai_admin_reply(403,['ok'=>false,'message'=>'ليس لديك صلاحية لإدارة مزودي الذكاء الاصطناعي.']);
}else $admin=require_admin();
header('Cache-Control: no-store, private');
$action=(string)($_POST['action']??'');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);header('Allow: POST');exit;}
try{ai_ensure_schema();}catch(Throwable $error){
  if($action!=='save') ai_admin_reply(503,['ok'=>false,'message'=>'تعذّر الوصول إلى جداول التحليل. تحقق من صلاحيات قاعدة البيانات.']);
  flash('تعذّر الوصول إلى جداول التحليل. تحقق من صلاحيات قاعدة البيانات.','err');header('Location: admin.php?t=ai');exit;
}
if($action==='save'){
  try{
    $defaults=ai_default_settings(); $providers=ai_provider_definitions();
    $primary=(string)($_POST['primary_provider']??'gemini');
    if(!ai_valid_provider($primary)) throw new InvalidArgumentException('اختر مزودًا أساسيًا صالحًا.');
    $fallbacks=[];
    foreach((array)($_POST['fallback_providers']??[]) as $provider){$provider=(string)$provider;if(ai_valid_provider($provider)&&$provider!==$primary&&!in_array($provider,$fallbacks,true))$fallbacks[]=$provider;}
    $prompt=trim((string)($_POST['prompt']??''));
    if($prompt===''||mb_strlen($prompt,'UTF-8')>8000) throw new InvalidArgumentException('اكتب Prompt من 1 إلى ٨٠٠٠ حرف.');
    $limitCount=max(1,min(100,(int)($_POST['limit_count']??1)));
    $windowHours=max(1,min(720,(int)($_POST['window_hours']??24)));
    $maxMessages=max(1,min(50,(int)($_POST['max_messages']??30)));
    $maxChars=max(100,min(5000,(int)($_POST['max_chars']??1000)));
    $maxInputChars=max(500,min(100000,(int)($_POST['max_input_chars']??50000)));
    $maxResultChars=max(300,min(12000,(int)($_POST['max_result_chars']??5000)));
    $timeoutSeconds=max(5,min(120,(int)($_POST['timeout_seconds']??45)));
    $cooldownHours=max(0,min(720,(int)($_POST['cooldown_hours']??24)));
    $limitMessage=trim((string)($_POST['limit_message']??$defaults['limit_message']));
    if($limitMessage==='') $limitMessage=$defaults['limit_message'];
    $limitMessage=mb_substr($limitMessage,0,500,'UTF-8');
    $models=[]; $previousModels=[]; $secrets=[]; $autoEnable=false;
    foreach($providers as $id=>$provider){
      $previousModels[$id]=ai_model_id($id);
      $model=trim((string)($_POST['provider_model'][$id]??$previousModels[$id]));
      if(!ai_valid_model_id($model,$id)) throw new InvalidArgumentException('معرّف النموذج غير صالح لمزود '.$provider['label'].'.');
      $models[$id]=$model;
      $secret=trim((string)($_POST['provider_api_key'][$id]??''));
      if(strlen($secret)>512) throw new InvalidArgumentException('مفتاح API أطول من الحد المسموح لمزود '.$provider['label'].'.');
      $secrets[$id]=null;
      if(empty($_POST['clear_provider_key'][$id])&&$secret!==''){$secrets[$id]=ai_encrypt_secret($secret);if(!isset($_POST['provider_enabled'][$id])||!empty($_POST['provider_enabled'][$id]))$autoEnable=true;}
    }
    $enabled=!empty($_POST['enabled'])||($autoEnable&&ai_setting_value('enabled','0')!=='1'&&empty($_POST['enabled_touched']));
    $pdo->beginTransaction();
    try{
      save_setting('ai_enabled',$enabled?'1':'0');
      save_setting('ai_primary_provider',$primary);
      save_setting('ai_fallback_providers',implode(',',$fallbacks));
      save_setting('ai_limit_count',(string)$limitCount);
      save_setting('ai_window_hours',(string)$windowHours);
      save_setting('ai_max_messages',(string)$maxMessages);
      save_setting('ai_max_chars',(string)$maxChars);
      save_setting('ai_max_input_chars',(string)$maxInputChars);
      save_setting('ai_max_result_chars',(string)$maxResultChars);
      save_setting('ai_timeout_seconds',(string)$timeoutSeconds);
      save_setting('ai_cooldown_hours',(string)$cooldownHours);
      save_setting('ai_limit_message',$limitMessage);
      save_setting('ai_save_results',!empty($_POST['save_results'])?'1':'0');
      save_setting('ai_prompt',$prompt);
      save_setting('ai_model',$models['gemini']);
      foreach($providers as $id=>$provider){
        $checked=!empty($_POST['provider_enabled'][$id]);
        if($secrets[$id]!==null&&!isset($_POST['provider_enabled'][$id])) $checked=true;
        save_setting('ai_provider_'.$id.'_enabled',$checked?'1':'0');
        save_setting('ai_provider_'.$id.'_model',$models[$id]);
        if(!empty($_POST['clear_provider_key'][$id])){save_setting('ai_provider_'.$id.'_api_key','');if($id==='gemini')save_setting('ai_api_key','');}
        elseif($secrets[$id]!==null){save_setting('ai_provider_'.$id.'_api_key',$secrets[$id]);if($id==='gemini')save_setting('ai_api_key','');}
        if($models[$id]!==$previousModels[$id]||$secrets[$id]!==null||!empty($_POST['clear_provider_key'][$id])){save_setting('ai_provider_'.$id.'_last_test_status','not_tested');save_setting('ai_provider_'.$id.'_last_test_at','');}
      }
      log_action('ai.settings.save','تحديث إعدادات مزودي الذكاء الاصطناعي');
      $pdo->commit();
    }catch(Throwable $saveError){if($pdo->inTransaction())$pdo->rollBack();throw $saveError;}
    flash('تم حفظ إعدادات مزودي الذكاء الاصطناعي.','ok');
  }catch(Throwable $error){
    flash($error instanceof InvalidArgumentException?$error->getMessage():'تعذّر حفظ الإعدادات. تأكد من تفعيل OpenSSL على الخادم.','err');
  }
  header('Location: admin.php?t=ai');exit;
}
if($action==='test'){
  $providers=ai_provider_definitions(); $provider=(string)($_POST['provider']??'');
  if(!ai_valid_provider($provider)) ai_admin_reply(400,['ok'=>false,'message'=>'اختر مزودًا صالحًا للاختبار.']);
  $apiKey=trim((string)($_POST['provider_api_key'][$provider]??''));
  $usesStoredKey=$apiKey==='';
  if($usesStoredKey) $apiKey=ai_api_key($provider);
  if($apiKey==='') ai_admin_reply(400,['ok'=>false,'message'=>'أدخل مفتاح API لهذا المزود أو أضفه إلى بيئة الخادم.']);
  if(strlen($apiKey)>512) ai_admin_reply(400,['ok'=>false,'message'=>'مفتاح API أطول من الحد المسموح.']);
  $models=ai_provider_available_models($provider,$apiKey);
  if(!$models['ok']){
    $status=(int)$models['status']; save_setting('ai_provider_'.$provider.'_last_test_status',$usesStoredKey?'failed':'not_tested'); save_setting('ai_provider_'.$provider.'_last_test_at',$usesStoredKey?date('Y-m-d H:i:s'):'');
    if($status===429) ai_admin_reply(429,['ok'=>false,'message'=>'تجاوز المفتاح حد الطلبات لدى '.$providers[$provider]['label'].' (429). انتظر قليلًا ثم أعد الاختبار.']);
    if($status===401||$status===403) ai_admin_reply(400,['ok'=>false,'message'=>'لم يقبل '.$providers[$provider]['label'].' المفتاح أو لا يملك صلاحية الوصول. تحقق من المفتاح والخطة.']);
    ai_admin_reply(502,['ok'=>false,'message'=>'تعذّر الاتصال بـ '.$providers[$provider]['label'].' (HTTP '.$status.'). تحقق من اتصال الخادم ثم أعد المحاولة.']);
  }
  $model=trim((string)($_POST['provider_model'][$provider]??ai_model_id($provider)));
  if(!ai_valid_model_id($model,$provider)) ai_admin_reply(400,['ok'=>false,'models'=>$models['models'],'message'=>'أدخل اسم نموذج صالحًا لهذا المزود.']);
  $ids=array_column($models['models'],'id');
  $probe=ai_provider_test_generation($provider,$apiKey,$model); $status=(int)$probe['status'];
  if($status===404&&$ids&&!in_array($model,$ids,true)){
    $suggested=$ids[0]??null;
    save_setting('ai_provider_'.$provider.'_last_test_status',$usesStoredKey?'failed':'not_tested'); save_setting('ai_provider_'.$provider.'_last_test_at',$usesStoredKey?date('Y-m-d H:i:s'):'');
    ai_admin_reply(200,['ok'=>false,'models'=>$models['models'],'suggested'=>$suggested,'message'=>'المفتاح صحيح، لكن المزود رفض النموذج «'.$model.'». اختر نموذجًا متاحًا أو أدخل معرّفًا صالحًا.']);
  }
  save_setting('ai_provider_'.$provider.'_last_test_status',$usesStoredKey?(($status>=200&&$status<300&&!$probe['transport_error']&&trim((string)$probe['text'])!=='')?'connected':'failed'):'not_tested');
  save_setting('ai_provider_'.$provider.'_last_test_at',$usesStoredKey?date('Y-m-d H:i:s'):'');
  if($probe['transport_error']) ai_admin_reply(502,['ok'=>false,'models'=>$models['models'],'message'=>'تعذّر الاتصال بخدمة '.$providers[$provider]['label'].'. تحقق من cURL واتصال الاستضافة بالإنترنت.']);
  if($status===429) ai_admin_reply(200,['ok'=>false,'models'=>$models['models'],'message'=>'المفتاح صحيح لكن حصة '.$providers[$provider]['label'].' تجاوزت الحد حاليًا (429).']);
  if(ai_transient_status($status)&&$ids){
    $prefer=$provider==='gemini'?['gemini-flash-latest','gemini-flash-lite-latest','gemini-2.5-flash','gemini-2.5-flash-lite','gemini-2.0-flash']:[];
    $alts=array_values(array_filter(array_unique(array_merge(array_values(array_intersect($prefer,$ids)),array_values(array_filter($ids,function($id){return stripos($id,'flash')!==false||stripos($id,'mini')!==false||stripos($id,'small')!==false;})))),function($id)use($model){return $id!==$model;}));
    foreach(array_slice($alts,0,3) as $alt){ $try=ai_provider_test_generation($provider,$apiKey,$alt);
      if((int)$try['status']>=200&&(int)$try['status']<300&&!$try['transport_error']&&trim((string)$try['text'])!==''){
        ai_admin_reply(200,['ok'=>false,'models'=>$models['models'],'suggested'=>$alt,'message'=>'النموذج «'.$model.'» مشغول حاليًا لدى '.$providers[$provider]['label'].' (HTTP '.$status.')، لكن المفتاح يعمل والنموذج «'.$alt.'» استجاب بنجاح. اختره ثم احفظ.']);
      } }
  }
  if($status<200||$status>=300||trim((string)$probe['text'])===''){
    $diagnostic=(array)($probe['diagnostic']??[]); $hint=(string)($diagnostic['hint']??'request');
    if(ai_transient_status($status)) $hint='overloaded'; elseif($status===401||$status===403) $hint='auth'; elseif($status===402) $hint='credits'; elseif($status>=200&&$status<300) $hint='empty'; elseif($status===404) $hint='invalid_model';
    if(!empty($diagnostic['message'])) $diagnostic['code']=trim(($diagnostic['code']??'').' — '.$diagnostic['message'],' —'); $providerCode=(string)($diagnostic['code']??''); $providerParam=(string)($diagnostic['param']??'');
    $message='لم يُكمل '.$providers[$provider]['label'].' تجربة النموذج (HTTP '.$status.'). '.ai_provider_hint_text($hint);
    if($providerCode!=='') $message.=' كود المزود: '.$providerCode.'.';
    if($providerParam!=='') $message.=' المعامل المرفوض: '.$providerParam.'.';
    ai_admin_reply(200,['ok'=>false,'models'=>$models['models'],'message'=>$message]);
  }
  ai_admin_reply(200,['ok'=>true,'models'=>$models['models'],'message'=>'نجح الاتصال: '.$providers[$provider]['label'].' والنموذج «'.$model.'» يعمل. احفظ التغييرات لتفعيل الإعداد.']);
}
http_response_code(400);
if($action!=='') ai_admin_reply(400,['ok'=>false,'message'=>'إجراء غير معروف.']);
?>
