<?php
@ini_set('display_errors','0');
ob_start();
register_shutdown_function(function(){
  $e=error_get_last();
  if($e && in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR],true)){
    while(ob_get_level()) ob_end_clean();
    error_log('[Asrar AI] Fatal: '.$e['message'].' @ '.$e['file'].':'.$e['line']);
    if(!headers_sent()){http_response_code(500);header('Content-Type: application/json; charset=utf-8');}
    echo json_encode(['ok'=>false,'message'=>'حدث خطأ داخلي في الخادم أثناء التحليل. حاول لاحقًا.'],JSON_UNESCAPED_UNICODE);
  }
});
define('AI_ANALYZE_REQUEST',true);
require __DIR__.'/inc.php';
require_once __DIR__.'/ai_module.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
@set_time_limit(180); @ignore_user_abort(true);
function ai_json_reply($status,array $data){if(empty($data['ok'])&&!empty($GLOBALS['AI_ERR_EXTRA'])){$x=$GLOBALS['AI_ERR_EXTRA'];try{$x['quota']=ai_quota_snapshot((int)($GLOBALS['AI_UID']??0));}catch(Throwable $e){}$data+=$x;}while(ob_get_level()) ob_end_clean();http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if($_SERVER['REQUEST_METHOD']!=='POST') ai_json_reply(405,['ok'=>false,'message'=>'طريقة الطلب غير مدعومة.']);
if((int)($_SERVER['CONTENT_LENGTH']??0)>2048) ai_json_reply(413,['ok'=>false,'message'=>'الطلب أكبر من الحد المسموح.']);
$user=me(); if(!$user) ai_json_reply(401,['ok'=>false,'message'=>'انتهت جلستك. سجّل الدخول مجددًا ثم حاول مرة أخرى.']);
if((string)($_POST['action']??'')!=='analyze') ai_json_reply(400,['ok'=>false,'message'=>'تعذّر فهم الطلب.']);
if((string)($_POST['consent']??'')!=='1') ai_json_reply(400,['ok'=>false,'message'=>'وافق على سياسة إرسال النصوص المنقّحة قبل بدء التحليل.']);
try{
  ai_ensure_schema();
  if(!ai_api_enabled()) ai_json_reply(503,['ok'=>false,'message'=>'تحليل الذكاء الاصطناعي غير مفعّل حاليًا.']);
  if(!ai_service_ready()) ai_json_reply(503,['ok'=>false,'message'=>'لا يوجد مزود ذكاء اصطناعي مفعّل ومهيأ حاليًا.']);
  ai_expire_stale_pending();
  [$messages,$messageIds]=ai_get_eligible_messages((int)$user['id']);
  if(!$messages) ai_json_reply(422,['ok'=>false,'message'=>'لا توجد رسائل نصية ظاهرة ومسموح بتحليلها في صندوقك حتى الآن.']);
  $fingerprintKey=(defined('DB_PASS')?(string)DB_PASS:'').(defined('DB_NAME')?(string)DB_NAME:'asrar');
  $fingerprint=hash_hmac('sha256',json_encode([$messageIds,$messages],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$fingerprintKey);
  $GLOBALS['AI_UID']=(int)$user['id']; $ipHash=ai_ip_hash(); $limits=ai_limits(); $userId=(int)$user['id'];
  $clientRid=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_POST['request_id']??''));
  $clientRid=substr($clientRid,0,64);
  $GLOBALS['AI_REQ_ID']=($clientRid!==''?$clientRid:'srv-'.bin2hex(random_bytes(6)));
  // Fingerprint identifies THIS click (client request id), not the message set, so a new analysis is never treated as a duplicate.
  $fingerprint=hash_hmac('sha256',$userId.'|'.$GLOBALS['AI_REQ_ID'],$fingerprintKey);
  ai_log('received user='.$userId.' messages='.count($messages));
  $pdo->beginTransaction();
  $lock=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_disabled=0 FOR UPDATE');
  $lock->execute([$userId]);
  if(!$lock->fetchColumn()){$pdo->rollBack();ai_json_reply(401,['ok'=>false,'message'=>'الحساب غير متاح.']);}
  // Duplicate protection: only the SAME click (same request_id) or a request still in progress is rejected.
  $duplicate=$pdo->prepare("SELECT id FROM ai_analysis_usage WHERE user_id=? AND request_hash=? LIMIT 1");
  $duplicate->execute([$userId,$fingerprint]);
  if($duplicate->fetchColumn()){$pdo->rollBack();ai_log('rejected_by=site reason=duplicate_same_request');ai_json_reply(409,['ok'=>false,'source'=>'site','code'=>'duplicate','message'=>'هذا الطلب قيد المعالجة بالفعل.']);}
  $inflight=$pdo->prepare("SELECT id FROM ai_analysis_usage WHERE user_id=? AND status='pending' AND created_at>=DATE_SUB(NOW(),INTERVAL 3 MINUTE) LIMIT 1");
  $inflight->execute([$userId]);
  if($inflight->fetchColumn()){$pdo->rollBack();ai_log('rejected_by=site reason=in_progress');ai_json_reply(409,['ok'=>false,'source'=>'site','code'=>'in_progress','message'=>'يوجد تحليل قيد التنفيذ الآن. انتظر حتى ينتهي ثم حاول مجددًا.']);}
  $periodCount=$pdo->prepare("SELECT COUNT(*) FROM ai_analysis_usage WHERE user_id=? AND status='success' AND created_at>=DATE_SUB(NOW(), INTERVAL {$limits['window_hours']} HOUR)");
  $periodCount->execute([$userId]);
  if((int)$periodCount->fetchColumn()>=$limits['count']){
    $pdo->rollBack();
    ai_log('rejected_by=site reason=quota_exhausted');
    ai_json_reply(429,['ok'=>false,'source'=>'site','code'=>'quota','message'=>(string)ai_setting_value('limit_message',ai_default_settings()['limit_message']),'quota'=>ai_quota_snapshot($userId)]);
  }
  $provider=ai_primary_provider_id(); $model=ai_model_id($provider);
  $insert=$pdo->prepare("INSERT INTO ai_analysis_usage(user_id,request_hash,ip_hash,provider,model,status) VALUES(?,?,?,?,?,'pending')");
  $insert->execute([$userId,$fingerprint,$ipHash,$provider,$model]); $usageId=(int)$pdo->lastInsertId();
  $pdo->commit();
  ai_log('reserved usage_id='.$usageId.' (pending, not deducted) primary_provider='.$provider);
}catch(Throwable $error){
  if($pdo->inTransaction()) $pdo->rollBack();
  error_log('[Asrar AI] Failed to reserve an analysis request.');
  ai_json_reply(503,['ok'=>false,'message'=>'تعذّر بدء التحليل الآن. حاول مرة أخرى لاحقًا.']);
}
try{$generated=ai_generate_analysis($messages);}catch(Throwable $error){
  ai_log('analysis_exception deducted=no type='.get_class($error));
  $fallbackProvider=ai_primary_provider_id();
  try{$pdo->prepare("UPDATE ai_analysis_usage SET status='failed',error_code='provider_error',provider=?,model=? WHERE id=? AND user_id=?")->execute([$fallbackProvider,ai_model_id($fallbackProvider),$usageId,$userId]);}catch(Throwable $logError){error_log('[Asrar AI] Failed to record an unexpected provider failure.');}
  $GLOBALS['AI_ERR_EXTRA']=['source'=>'provider','code'=>'provider_error','provider'=>$fallbackProvider,'provider_status'=>null,'deducted'=>false,'quota'=>null];
  ai_json_reply(502,['ok'=>false,'message'=>'لم نتمكن من إكمال التحليل. لم يُخصم أي تحليل من رصيدك؛ حاول لاحقًا.']);
}
if(!$generated['ok']){
  $provider=(string)($generated['provider']??ai_primary_provider_id());
  $model=(string)($generated['model']??ai_model_id($provider));
  $status=(int)($generated['provider_status']??0);
  $errorCode=(string)($generated['error']??'provider_error');
  $codes=['rate_limit'=>'provider_429','missing_key'=>'missing_key','invalid_result'=>'invalid_result','auth_error'=>'provider_auth','invalid_model'=>'invalid_model','invalid_request'=>'invalid_request','provider_error'=>'provider_error','transport'=>'transport','blocked'=>'blocked'];
  $code=$codes[$errorCode]??'provider_error';
  $source=$errorCode==='missing_key'?'site':'provider';
  ai_log('failed provider='.$provider.' model='.$model.' status='.$status.' error='.$errorCode.' deducted=no');
  $GLOBALS['AI_ERR_EXTRA']=['source'=>$source,'code'=>$errorCode,'provider'=>$provider,'provider_status'=>$status?:null,'deducted'=>false,'quota'=>null];
  try{$pdo->prepare("UPDATE ai_analysis_usage SET status='failed',error_code=?,provider=?,model=?,provider_status=? WHERE id=? AND user_id=?")->execute([$code,$provider,$model,$status?:null,$usageId,$userId]);}catch(Throwable $error){error_log('[Asrar AI] Failed to record a provider failure.');}
  $msg='تعذّر إكمال التحليل عبر مزودي الذكاء الاصطناعي المتاحين. لم يُخصم أي تحليل من رصيدك؛ حاول لاحقًا.';
  if($errorCode==='missing_key') $msg='لم يكتمل إعداد أي مزود ذكاء اصطناعي صالح. لم يُخصم أي تحليل من رصيدك.';
  if($errorCode==='auth_error') $msg='لم يقبل مزود الذكاء الاصطناعي المفتاح أو صلاحياته. لم يُخصم أي تحليل من رصيدك.';
  if($errorCode==='invalid_model') $msg='النموذج المحدد غير متاح لدى المزود. لم يُخصم أي تحليل من رصيدك.';
  if($errorCode==='invalid_request') $msg='رفض المزود إعدادات طلب التحليل. لم يُخصم أي تحليل من رصيدك.';
  if($errorCode==='blocked') ai_json_reply(422,['ok'=>false,'message'=>'رفضت خدمة التحليل محتوى هذه الرسائل وفق سياسة الاستخدام.']);
  if($errorCode==='invalid_result') $msg='أعاد المزود نتيجة غير مكتملة. لم يُخصم أي تحليل من رصيدك؛ حاول مجددًا بعد قليل.';
  if(!empty($user['is_admin'])){
    $hint=(string)($generated['provider_hint']??'request'); $providerCode=(string)($generated['provider_code']??''); $providerParam=(string)($generated['provider_param']??'');
    $msg.=' [للمدير: '.$provider.' | '.$model.' | '.$errorCode.' | HTTP '.$status.' | '.ai_provider_hint_text($hint).($providerCode!==''?' (كود المزود: '.$providerCode.')':'').($providerParam!==''?' (المعامل: '.$providerParam.')':'').']';
  }
  ai_json_reply($errorCode==='rate_limit'?429:502,['ok'=>false,'message'=>$msg]);
}
try{
  $resultJson=json_encode($generated['result'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $save=ai_setting_value('save_results','0')==='1';
  $provider=(string)($generated['provider']??ai_primary_provider_id());
  $providerStatus=(int)($generated['provider_status']??0);
  $cost=$generated['cost_usd']??null; $cost=is_numeric($cost)&&$cost>=0?(float)$cost:null;
  $update=$pdo->prepare("UPDATE ai_analysis_usage SET status='success',provider=?,model=?,provider_status=?,cost_usd=?,score=?,messages_count=?,result_json=? WHERE id=? AND user_id=?");
  $update->execute([$provider,$generated['model'],$providerStatus?:null,$cost,(int)$generated['result']['score'],min(65535,count($messages)),$save?$resultJson:null,$usageId,$userId]);
  ai_log('success usage_id='.$usageId.' provider='.$provider.' model='.$generated['model'].' status='.$providerStatus.' deducted=yes');
}catch(Throwable $error){
  ai_log('failed to mark success usage_id='.$usageId);
  ai_json_reply(503,['ok'=>false,'message'=>'تعذّر حفظ حالة الطلب. يرجى المحاولة لاحقًا.']);
}
$quota=ai_quota_snapshot($userId);
ai_log('quota_after remaining='.$quota['remaining'].'/'.$quota['limit']);
$history=[]; foreach(ai_user_history($userId,6) as $h) $history[]=['score'=>$h['score'],'created_at'=>$h['created_at']];
$previous=isset($history[1]['score'])?$history[1]['score']:null;
ai_json_reply(200,['ok'=>true,'result'=>$generated['result'],'stats'=>ai_local_stats($messages),'previous_score'=>$previous,'history'=>array_reverse($history),'saved'=>$save,'analyzed_at'=>date('c'),'quota'=>$quota]);

