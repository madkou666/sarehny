<?php require 'inc.php'; $u=require_login();
$tab=in_array($_GET['t']??'',['overview','profile','security','danger'],true)?$_GET['t']:'overview';
const AVATAR_MAX_MB = 10;
$dir=__DIR__.'/uploads/avatars';
function remove_avatar_file($f){ global $dir; if($f && preg_match('/^[a-f0-9]{32}\.(jpg|png|webp|gif)$/D',$f) && is_file($dir.'/'.$f)) @unlink($dir.'/'.$f); }
function ini_bytes($v){ $v=trim((string)$v); if($v==='') return 0; $n=(float)$v; switch(strtolower(substr($v,-1))){case 'g':$n*=1024;case 'm':$n*=1024;case 'k':$n*=1024;} return (int)$n; }
$serverMax=min(array_filter([ini_bytes(ini_get('upload_max_filesize')),ini_bytes(ini_get('post_max_size'))]) ?: [AVATAR_MAX_MB*1048576]);
$maxBytes=min(AVATAR_MAX_MB*1048576,$serverMax);
$maxMb=max(1,floor($maxBytes/1048576));

if($_SERVER['REQUEST_METHOD']==='POST'){
  $a=$_POST['action']??'';
  if($a==='profile'){
    $n=trim((string)($_POST['name']??''));
    if(mb_strlen($n)<2 || mb_strlen($n)>80) flash('اكتب اسمًا ظاهرًا من ٢ إلى ٨٠ حرفًا','err');
    elseif(find_banned_word($n)!==null) flash('الاسم يحتوي على كلمات غير مسموح بها','err');
    else { $pdo->prepare('UPDATE users SET display_name=? WHERE id=?')->execute([$n,$u['id']]); flash('تم حفظ اسمك'); }
  }
  if($a==='username'){
    $nu=strtolower(trim((string)($_POST['username']??'')));
    if(!preg_match('/^[a-z0-9_]{3,30}$/D',$nu)) flash('اسم المستخدم: من ٣ إلى ٣٠ حرفًا إنجليزيًا صغيرًا أو أرقامًا أو _ فقط','err');
    elseif($nu===$u['username']) flash('هذا هو اسم المستخدم الحالي بالفعل','err');
    elseif(in_array($nu,array_filter(array_map('trim',explode("\n",strtolower(setting('reserved_usernames','admin\nadministrator\nroot\nsupport\nasrar'))))),true)) flash('اسم المستخدم هذا محجوز، اختر اسمًا آخر','err');
    else { $s=$pdo->prepare('SELECT id FROM users WHERE username=? AND id<>?'); $s->execute([$nu,$u['id']]);
      if($s->fetch()) flash('اسم المستخدم هذا مستخدم بالفعل','err');
      else { $pdo->prepare('UPDATE users SET username=? WHERE id=?')->execute([$nu,$u['id']]); flash('تم تغيير اسم المستخدم، رابطك الجديد: '.base_url().'/'.$nu); } }
  }
  if($a==='avatar'){
    $f=$_FILES['avatar']??null; $errc=$f['error']??UPLOAD_ERR_NO_FILE;
    if($errc===UPLOAD_ERR_INI_SIZE || $errc===UPLOAD_ERR_FORM_SIZE || ($f && $f['size']>$maxBytes)) flash('حجم الصورة أكبر من المسموح ('.ar_num($maxMb).' ميجابايت)','err');
    elseif($errc!==UPLOAD_ERR_OK) flash('اختر صورة لرفعها','err');
    else {
      $info=@getimagesize($f['tmp_name']);
      $types=[IMAGETYPE_JPEG=>'jpg',IMAGETYPE_PNG=>'png',IMAGETYPE_WEBP=>'webp',IMAGETYPE_GIF=>'gif'];
      if(!$info || !isset($types[$info[2]])) flash('الصيغ المسموحة: JPG أو PNG أو WEBP أو GIF','err');
      else {
        if(!is_dir($dir)) @mkdir($dir,0755,true);
        $name=bin2hex(random_bytes(16)).'.'.$types[$info[2]];
        if(@move_uploaded_file($f['tmp_name'],$dir.'/'.$name)){
          remove_avatar_file($u['avatar']??'');
          $pdo->prepare('UPDATE users SET avatar=? WHERE id=?')->execute([$name,$u['id']]);
          flash('تم تحديث صورتك الشخصية');
        } else flash('تعذر حفظ الصورة، تأكد أن مجلد uploads قابل للكتابة','err');
      }
    }
  }
  if($a==='avatar_remove'){ remove_avatar_file($u['avatar']??''); $pdo->prepare('UPDATE users SET avatar=NULL WHERE id=?')->execute([$u['id']]); flash('تم حذف الصورة'); }
  if($a==='email'){
    $email=strtolower(trim((string)($_POST['email']??'')));
    if(!password_verify((string)($_POST['current']??''),$u['password_hash'])) flash('كلمة المرور الحالية غير صحيحة','err');
    elseif(!filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($email)>190) flash('البريد الإلكتروني غير صالح','err');
    else { $s=$pdo->prepare('SELECT id FROM users WHERE email=? AND id<>?'); $s->execute([$email,$u['id']]);
      if($s->fetch()) flash('هذا البريد مستخدم بالفعل','err');
      else { $pdo->prepare('UPDATE users SET email=? WHERE id=?')->execute([$email,$u['id']]); flash('تم تحديث البريد الإلكتروني'); } }
  }
  if($a==='password'){
    $new=(string)($_POST['new']??'');
    if(!password_verify((string)($_POST['current']??''),$u['password_hash'])) flash('كلمة المرور الحالية غير صحيحة','err');
    elseif(strlen($new)<8) flash('كلمة المرور الجديدة ٨ أحرف على الأقل','err');
    elseif($new!==(string)($_POST['confirm']??'')) flash('تأكيد كلمة المرور غير مطابق','err');
    else { $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$u['id']]); session_regenerate_id(true); flash('تم تغيير كلمة المرور'); }
  }
  if($a==='delete'){
    if(!password_verify((string)($_POST['current']??''),$u['password_hash'])) flash('كلمة المرور غير صحيحة','err');
    elseif(($_POST['confirm_text']??'')!==$u['username']) flash('اكتب اسم المستخدم بالضبط لتأكيد الحذف','err');
    else { remove_avatar_file($u['avatar']??''); $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$u['id']]); remember_clear(); session_destroy(); header('Location: index.php'); exit; }
  }
  header('Location: account.php'.($tab!=='overview'?'?t='.$tab:'')); exit;
}

$cnt=$pdo->prepare('SELECT COUNT(*) total, COALESCE(SUM(is_question=1 AND answer IS NOT NULL),0) published, COALESCE(SUM(is_question=1 AND answer IS NULL),0) pending, COALESCE(SUM(is_favorite),0) fav, COALESCE(SUM(created_at>NOW()-INTERVAL 7 DAY),0) week FROM messages WHERE recipient_id=? AND is_removed=0'); $cnt->execute([$u['id']]); $c=$cnt->fetch();
$link=base_url().'/'.rawurlencode($u['username']);
$hasImg=avatar_url($u)!=='';
$checks=[['صورة شخصية',$hasImg],['اسم ظاهر',mb_strlen($u['display_name'])>=2],['أول رسالة',$c['total']>0],['أول إجابة منشورة',$c['published']>0]];
$done=count(array_filter(array_column($checks,1))); $pct=(int)round($done/count($checks)*100);
$flash=flash();
$tabs=['overview'=>['grid','نظرة عامة'],'profile'=>['user','الملف الشخصي'],'security'=>['key','الأمان'],'danger'=>['trash','حذف الحساب']];
head('لوحة حسابي','app'); ?>
<section class="page acc-page">
  <div class="wrap acc">
    <div class="acc-cover">
      <div class="acc-cover-in">
        <div class="acc-ava-wrap">
          <?php if($hasImg): ?><button type="button" class="avatar-open" data-avatar-open aria-label="عرض صورتك الشخصية بالحجم الكامل" title="عرض الصورة بالحجم الكامل"><?=avatar_html($u,'xxl','span')?></button><?php else: ?><?=avatar_html($u,'xxl','span')?><?php endif; ?>
          <label class="acc-ava-cam" for="avaQuickInput" aria-label="تغيير الصورة الشخصية" title="تغيير الصورة" style="cursor:pointer"><?=icon('camera')?></label>
        </div>
        <div class="grow">
          <h1><?=e($u['display_name'])?><?=verified_badge($u,'lg')?></h1>
          <div class="acc-meta"><span dir="ltr">@<?=e($u['username'])?></span><span>•</span><span>عضو منذ <?=ar_num(date('Y/m',strtotime($u['created_at'])))?></span></div>
        </div>
        <div class="acc-cover-actions">
          <a class="btn" href="account.php?t=profile"><?=icon('edit')?><span>تعديل الملف</span></a>
          <a class="btn ghost" href="<?=e($link)?>" target="_blank" rel="noopener"><?=icon('share')?><span>صفحتي</span></a>
        </div>
      </div>
    </div>

    <?php if($hasImg): ?>
    <dialog class="avatar-dialog" aria-label="صورتك الشخصية">
      <div class="avatar-dialog-head"><div><b><?=e($u['display_name'])?></b><small dir="ltr">@<?=e($u['username'])?></small></div><button type="button" class="avatar-dialog-close" data-avatar-close aria-label="إغلاق الصورة" title="إغلاق الصورة">&times;</button></div>
      <div class="avatar-dialog-image"><img src="<?=e(avatar_url($u))?>" alt="صورتك الشخصية"></div>
      <div class="avatar-dialog-actions"><a href="account.php?t=profile"><?=icon('camera')?> تغيير الصورة</a></div>
    </dialog>
    <?php endif; ?>
    <div class="acc-layout">
      <aside class="acc-side" aria-label="أقسام الحساب">
        <nav>
          <?php foreach($tabs as $k=>$t): ?>
          <a href="account.php<?= $k!=='overview'?'?t='.$k:'' ?>" class="<?= $tab===$k?'active':'' ?><?= $k==='danger'?' is-danger':'' ?>" <?= $tab===$k?'aria-current="page"':'' ?>><?=icon($t[0])?><span><?=$t[1]?></span></a>
          <?php endforeach; ?>
          <hr><a href="dashboard.php"><?=icon('inbox')?><span>صندوق الرسائل</span></a>
        </nav>
      </aside>

      <div class="acc-main">
        <?php if($flash) echo alert_box($flash[0],$flash[1]); ?>

        <?php if($tab==='overview'): ?>
          <div class="acc-shortcuts" aria-label="اختصارات الحساب">
  <a href="dashboard.php"><?=icon('inbox')?><span>صندوق الرسائل</span><?=icon('arrow')?></a>
  <a href="social-lab.php"><?=icon('activity')?><span>المختبر الاجتماعي AI</span><?=icon('arrow')?></a>
  <a href="account.php?t=profile"><?=icon('edit')?><span>تعديل الملف</span><?=icon('arrow')?></a>
            <a href="account.php?t=security"><?=icon('key')?><span>أمان الحساب</span><?=icon('arrow')?></a>
          </div>
          <div class="acc-stats">
            <div class="acc-stat"><span class="stat-icon violet"><?=icon('inbox')?></span><div><b><?=ar_num($c['total'])?></b><small>كل الرسائل</small></div></div>
            <div class="acc-stat"><span class="stat-icon blue"><?=icon('send')?></span><div><b><?=ar_num($c['week'])?></b><small>هذا الأسبوع</small></div></div>
            <div class="acc-stat"><span class="stat-icon green"><?=icon('message')?></span><div><b><?=ar_num($c['published'])?></b><small>إجابات منشورة</small></div></div>
            <div class="acc-stat"><span class="stat-icon amber"><?=icon('star')?></span><div><b><?=ar_num($c['fav'])?></b><small>المفضلة</small></div></div>
          </div>
          <div class="acc-card">
            <div class="acc-card-head"><div><h2>اكتمال الملف الشخصي</h2><p class="muted sm">الملف المكتمل يشجع أصحابك على المراسلة</p></div><b class="acc-pct"><?=ar_num($pct)?>٪</b></div>
            <div class="acc-bar"><span style="width:<?=$pct?>%"></span></div>
            <ul class="acc-checks"><?php foreach($checks as $ch): ?><li class="<?=$ch[1]?'ok':''?>"><?=icon($ch[1]?'check':'alert')?><span><?=$ch[0]?></span></li><?php endforeach; ?></ul>
          </div>
          <div class="acc-card">
            <div class="acc-card-head"><div><h2>رابطك الخاص</h2><p class="muted sm">شاركه ليصلك الكلام المجهول</p></div></div>
            <div class="link-row"><input id="mylink" class="link-input" readonly dir="ltr" value="<?=e($link)?>" onclick="this.select()"><button type="button" class="btn" data-copy="mylink"><?=icon('copy')?><span>نسخ</span></button></div>
            <?=share_tools_html($link)?>
          </div>
          <?php if($c['pending']>0): ?><a class="acc-notice" href="dashboard.php?f=pending"><?=icon('message')?><span>لديك <?=ar_num($c['pending'])?> سؤال بانتظار إجابتك</span><?=icon('arrow')?></a><?php endif; ?>

        <?php elseif($tab==='profile'): ?>
          <div class="acc-card">
            <div class="acc-card-head"><div><h2>الصورة الشخصية</h2><p class="muted sm">تظهر في صفحتك العامة وبجانب إجاباتك</p></div></div>
            <form method="post" enctype="multipart/form-data" id="avaForm">
              <?=csrf_field()?><input type="hidden" name="action" value="avatar">
              <label class="drop" id="drop">
                <input type="file" name="avatar" id="avaInput" accept="image/jpeg,image/png,image/webp,image/gif" required hidden>
                <span class="drop-preview" id="avaPreview"><?=avatar_html($u,'xxl','span')?></span>
                <span class="drop-text"><b><?=icon('upload')?> اسحب الصورة هنا أو اضغط للاختيار</b><small>JPG أو PNG أو WEBP أو GIF — حتى <?=ar_num($maxMb)?> ميجابايت</small><small class="drop-err" id="avaErr" hidden></small></span>
              </label>
              <div class="acc-actions">
                <button class="btn" id="avaSave" disabled><?=icon('check')?><span>حفظ الصورة</span></button>
                <?php if($hasImg): ?><button class="btn danger-soft" form="avaRemove"><?=icon('trash')?><span>حذف الصورة الحالية</span></button><?php endif; ?>
              </div>
            </form>
            <?php if($hasImg): ?><form method="post" id="avaRemove" onsubmit="return confirm('حذف صورتك الشخصية؟')"><?=csrf_field()?><input type="hidden" name="action" value="avatar_remove"></form><?php endif; ?>
          </div>
          <div class="acc-card">
            <div class="acc-card-head"><div><h2>المعلومات الأساسية</h2><p class="muted sm">الاسم الذي يراه زوار صفحتك</p></div></div>
            <form method="post" class="form">
              <?=csrf_field()?><input type="hidden" name="action" value="profile">
              <div class="grid-2">
                <div class="field"><label for="name">الاسم الظاهر</label><input id="name" name="name" required maxlength="80" value="<?=e($u['display_name'])?>"></div>
                <div class="field"><label>اسم المستخدم</label><input value="@<?=e($u['username'])?>" dir="ltr" disabled><small class="hint">يمكنك تغييره من النموذج بالأسفل</small></div>
              </div>
              <div class="acc-actions"><button class="btn"><?=icon('check')?><span>حفظ التغييرات</span></button></div>
            </form>
          </div>

          <div class="acc-card">
            <div class="acc-card-head"><div><h2>تغيير اسم المستخدم</h2><p class="muted sm">اسم المستخدم هو جزء من رابطك — سيتغير رابطك فور الحفظ</p></div></div>
            <form method="post" class="form">
              <?=csrf_field()?><input type="hidden" name="action" value="username">
              <div class="grid-2">
                <div class="field"><label for="new_username">اسم المستخدم الجديد</label>
                  <div class="input-prefix" dir="ltr"><span>@</span><input id="new_username" name="username" dir="ltr" required pattern="[a-z0-9_]{3,30}" maxlength="30" placeholder="sara_99"></div>
                  <small class="hint">من ٣ إلى ٣٠ حرفًا إنجليزيًا صغيرًا أو أرقامًا أو _ فقط</small>
                </div>
              </div>
              <div class="acc-actions"><button class="btn"><?=icon('check')?><span>تغيير اسم المستخدم</span></button></div>
            </form>
          </div>
          <script>(function(){var inp=document.getElementById('avaInput'),pv=document.getElementById('avaPreview'),err=document.getElementById('avaErr'),save=document.getElementById('avaSave'),drop=document.getElementById('drop'),max=<?=(int)$maxBytes?>;
          function pick(f){err.hidden=true;save.disabled=true;if(!f)return;if(!/^image\/(jpeg|png|webp|gif)$/.test(f.type)){err.textContent='صيغة غير مدعومة';err.hidden=false;return}if(f.size>max){err.textContent='الحجم أكبر من <?=$maxMb?> ميجابايت';err.hidden=false;return}var r=new FileReader();r.onload=function(){pv.innerHTML='<span class="avatar xxl has-img"><img alt="" src="'+r.result+'"></span>'};r.readAsDataURL(f);save.disabled=false}
          inp.addEventListener('change',function(){pick(inp.files[0])});
          ['dragenter','dragover'].forEach(function(t){drop.addEventListener(t,function(e){e.preventDefault();drop.classList.add('over')})});
          ['dragleave','drop'].forEach(function(t){drop.addEventListener(t,function(e){e.preventDefault();drop.classList.remove('over')})});
          drop.addEventListener('drop',function(e){if(e.dataTransfer.files[0]){inp.files=e.dataTransfer.files;pick(inp.files[0])}});
          document.getElementById('avaForm').addEventListener('submit',function(){save.disabled=true;save.querySelector('span').textContent='جارٍ الرفع...'});})();</script>

        <?php elseif($tab==='security'): ?>
          <div class="acc-card">
            <div class="acc-card-head"><div><h2>البريد الإلكتروني</h2><p class="muted sm">يُستخدم لتسجيل الدخول فقط ولا يظهر لأحد</p></div></div>
            <form method="post" class="form">
              <?=csrf_field()?><input type="hidden" name="action" value="email">
              <div class="grid-2">
                <div class="field"><label for="email">البريد</label><input id="email" name="email" type="email" dir="ltr" required value="<?=e($u['email'])?>"></div>
                <div class="field"><label for="c1">كلمة المرور الحالية</label><input id="c1" name="current" type="password" dir="ltr" required autocomplete="current-password"></div>
              </div>
              <div class="acc-actions"><button class="btn"><?=icon('check')?><span>حفظ البريد</span></button></div>
            </form>
          </div>
          <div class="acc-card">
            <div class="acc-card-head"><div><h2>كلمة المرور</h2><p class="muted sm">استخدم ٨ أحرف على الأقل</p></div></div>
            <form method="post" class="form">
              <?=csrf_field()?><input type="hidden" name="action" value="password">
              <div class="field"><label for="c2">كلمة المرور الحالية</label><input id="c2" name="current" type="password" dir="ltr" required autocomplete="current-password"></div>
              <div class="grid-2">
                <div class="field"><label for="n1">الجديدة</label><input id="n1" name="new" type="password" dir="ltr" minlength="8" required autocomplete="new-password"></div>
                <div class="field"><label for="n2">تأكيد الجديدة</label><input id="n2" name="confirm" type="password" dir="ltr" minlength="8" required autocomplete="new-password"></div>
              </div>
              <div class="acc-actions"><button class="btn"><?=icon('lock')?><span>تغيير كلمة المرور</span></button></div>
            </form>
          </div>

        <?php else: ?>
          <div class="acc-card danger-card">
            <div class="acc-card-head"><div><h2>حذف الحساب نهائيًا</h2><p class="muted sm">سيتم حذف حسابك وكل رسائلك وإجاباتك وصورتك، ولا يمكن التراجع.</p></div></div>
            <form method="post" class="form" onsubmit="return confirm('متأكد من حذف حسابك نهائيًا؟')">
              <?=csrf_field()?><input type="hidden" name="action" value="delete">
              <div class="grid-2">
                <div class="field"><label for="ct">اكتب <b dir="ltr"><?=e($u['username'])?></b> للتأكيد</label><input id="ct" name="confirm_text" dir="ltr" required></div>
                <div class="field"><label for="c3">كلمة المرور</label><input id="c3" name="current" type="password" dir="ltr" required></div>
              </div>
              <div class="acc-actions"><button class="btn danger"><?=icon('trash')?><span>حذف حسابي</span></button></div>
            </form>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<form method="post" enctype="multipart/form-data" id="avaQuick" hidden>
  <?=csrf_field()?><input type="hidden" name="action" value="avatar">
  <input type="file" name="avatar" id="avaQuickInput" accept="image/jpeg,image/png,image/webp,image/gif">
</form>

<script>
(function(){
  var maxBytes=<?=$maxBytes?>;
  var types=['image/jpeg','image/png','image/webp','image/gif'];
  function valid(f){ return f && types.indexOf(f.type)!==-1 && f.size<=maxBytes; }

  // زرار الكاميرا فوق الصورة: اختيار ورفع فوري
  var quick=document.getElementById('avaQuickInput');
  if(quick) quick.addEventListener('change',function(){
    if(!quick.files.length) return;
    if(!valid(quick.files[0])){ alert('الصيغ المسموحة: JPG أو PNG أو WEBP أو GIF — وحتى '+Math.round(maxBytes/1048576)+' ميجابايت'); quick.value=''; return; }
    document.getElementById('avaQuick').submit();
  });

  // منطقة الرفع في تبويب الملف الشخصي: معاينة + سحب وإفلات
  var input=document.getElementById('avaInput'), drop=document.getElementById('drop'),
      preview=document.getElementById('avaPreview'), save=document.getElementById('avaSave'),
      err=document.getElementById('avaErr');
  if(!input||!drop) return;
  function show(f){
    if(!valid(f)){ if(err){ err.textContent='صيغة غير مدعومة أو الحجم أكبر من المسموح'; err.hidden=false; } input.value=''; save.disabled=true; return; }
    if(err) err.hidden=true;
    var r=new FileReader();
    r.onload=function(e){ preview.innerHTML='<img src="'+e.target.result+'" alt="معاينة الصورة" style="width:100%;height:100%;object-fit:cover;border-radius:50%">'; };
    r.readAsDataURL(f);
    save.disabled=false;
  }
  input.addEventListener('change',function(){ if(input.files.length) show(input.files[0]); });
  ['dragover','dragenter'].forEach(function(ev){ drop.addEventListener(ev,function(e){ e.preventDefault(); drop.classList.add('over'); }); });
  ['dragleave','drop'].forEach(function(ev){ drop.addEventListener(ev,function(e){ e.preventDefault(); drop.classList.remove('over'); }); });
  drop.addEventListener('drop',function(e){ if(e.dataTransfer.files.length){ input.files=e.dataTransfer.files; show(e.dataTransfer.files[0]); } });
})();
</script>
<?php foot();
