<?php

final class AdminBackupValidationException extends RuntimeException {}

function admin_backup_table_names(){
  return ['users','messages','reports','message_meta','push_subs'];
}

function admin_backup_limit_bytes(){return 134217728;}

function admin_backup_max_bytes(){
  $parse=function($value){
    $value=trim((string)$value);
    if($value===''||$value==='-1')return 0;
    $unit=strtolower(substr($value,-1));
    $number=(float)$value;
    if($unit==='g')$number*=1024;
    if($unit==='g'||$unit==='m')$number*=1024;
    if($unit==='g'||$unit==='m'||$unit==='k')$number*=1024;
    return $number>0?(int)$number:0;
  };
  $limits=array_filter([$parse(ini_get('upload_max_filesize')),$parse(ini_get('post_max_size'))]);
  $maximum=admin_backup_limit_bytes();
  return min($maximum,$limits?min($limits):$maximum);
}

function admin_backup_format_bytes($bytes){
  $units=['B','KB','MB','GB'];$i=0;$bytes=max(0,(float)$bytes);
  while($bytes>=1024&&$i<count($units)-1){$bytes/=1024;$i++;}
  return number_format($bytes,$i?1:0).' '.$units[$i];
}

function admin_backup_write_all($handle,$data){
  $length=strlen($data);$offset=0;
  while($offset<$length){$written=fwrite($handle,substr($data,$offset));if($written===false||$written===0)return false;$offset+=$written;}
  return true;
}

function admin_backup_columns(PDO $pdo){
  $columns=[];
  foreach(admin_backup_table_names() as $table){
    $rows=$pdo->query('SHOW COLUMNS FROM `'.$table.'`')->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $row){
      $name=(string)$row['Field'];
      $columns[$table][$name]=['generated'=>stripos((string)($row['Extra']??''),'GENERATED')!==false];
    }
  }
  return $columns;
}

function admin_backup_assets(PDO $pdo){
  $assets=[];
  $collect=function($query,$prefix,$pattern)use($pdo,&$assets){
    foreach($pdo->query($query,PDO::FETCH_COLUMN) as $filename){
      $filename=(string)$filename;
      if($filename==='')continue;
      if(!preg_match($pattern,$filename))throw new AdminBackupValidationException('تعذّر إنشاء النسخة لوجود مسار ملف غير صالح في بيانات المستخدمين.');
      $relative=$prefix.'/'.$filename;
      $path=__DIR__.'/'.$relative;
      if(is_link($path)||!is_file($path)||!is_readable($path))throw new AdminBackupValidationException('تعذّر إنشاء النسخة: يوجد تسجيل صوتي أو صورة شخصية مفقودة على الخادم.');
      $assets[$relative]=$path;
    }
  };
  $collect("SELECT avatar FROM users WHERE avatar IS NOT NULL AND avatar<>''",'uploads/avatars','/^[a-f0-9]{32}\\.(jpg|png|webp|gif)$/D');
  $collect("SELECT audio_path FROM messages WHERE audio_path IS NOT NULL AND audio_path<>''",'uploads/voice','/^[a-f0-9]{32}\\.(webm|ogg|m4a|mp3|wav)$/D');
  ksort($assets,SORT_STRING);
  return $assets;
}

function send_user_backup(PDO $pdo){
  @set_time_limit(600);
  if(!class_exists('ZipArchive'))throw new RuntimeException('ميزة ZIP غير متاحة على الخادم. فعّل إضافة ZIP في PHP ثم أعد المحاولة.');
  $workspace=sys_get_temp_dir().'/asrar-backup-'.bin2hex(random_bytes(12));
  $archivePath=$workspace.'.zip';
  if(!@mkdir($workspace,0700))throw new RuntimeException('تعذّر تجهيز ملف النسخة الاحتياطية.');
  $zip=null;$inTransaction=false;
  try{
    $pdo->beginTransaction();$inTransaction=true;
    $columns=admin_backup_columns($pdo);
    $assets=admin_backup_assets($pdo);
    $tables=[];
    foreach(admin_backup_table_names() as $table){
      $path=$workspace.'/'.$table.'.jsonl';
      $out=@fopen($path,'xb');
      if(!$out)throw new RuntimeException('تعذّر تجهيز بيانات النسخة الاحتياطية.');
      $count=0;
      try{
        $stmt=$pdo->query('SELECT * FROM `'.$table.'`');
        while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
          $line=json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR);
          if(!admin_backup_write_all($out,$line."\n"))throw new RuntimeException('تعذّر حفظ كامل بيانات النسخة الاحتياطية.');
          $count++;
        }
      }finally{fclose($out);}
      $tables[$table]=['file'=>'database/'.$table.'.jsonl','rows'=>$count,'size'=>filesize($path),'sha256'=>hash_file('sha256',$path)];
    }
    $manifestAssets=[];
    foreach($assets as $relative=>$path){
      $archiveName='media/'.substr($relative,strlen('uploads/'));
      $manifestAssets[$relative]=['file'=>$archiveName,'size'=>filesize($path),'sha256'=>hash_file('sha256',$path)];
    }
    $manifest=['format'=>'asrar-user-data-backup','version'=>1,'created_at'=>gmdate('c'),'tables'=>$tables,'assets'=>$manifestAssets];
    $manifestJson=json_encode($manifest,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR);
    $zip=new ZipArchive();
    if($zip->open($archivePath,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('تعذّر إنشاء أرشيف النسخة الاحتياطية.');
    foreach($tables as $table=>$entry){
      if(!$zip->addFile($workspace.'/'.$table.'.jsonl',$entry['file']))throw new RuntimeException('تعذّر إضافة بيانات المستخدمين إلى النسخة.');
    }
    foreach($assets as $relative=>$path){
      $archiveName=$manifestAssets[$relative]['file'];
      if(!$zip->addFile($path,$archiveName))throw new RuntimeException('تعذّر إضافة الصور والتسجيلات إلى النسخة.');
    }
    if(!$zip->addFromString('manifest.json',$manifestJson)||!$zip->close())throw new RuntimeException('تعذّر إكمال أرشيف النسخة الاحتياطية.');
    $zip=null;
    $size=filesize($archivePath);
    if($size>admin_backup_limit_bytes())throw new AdminBackupValidationException('حجم النسخة أكبر من الحد الآمن للاستيراد (128 ميجابايت).');
    $pdo->commit();$inTransaction=false;
    $safeName=preg_replace('/[^A-Za-z0-9_-]/','_',defined('DB_NAME')?DB_NAME:'site');
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="asrar-user-backup-'.$safeName.'-'.date('Y-m-d-His').'.zip"');
    header('Content-Length: '.$size);
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    readfile($archivePath);
    foreach(admin_backup_table_names() as $table)@unlink($workspace.'/'.$table.'.jsonl');
    @rmdir($workspace);@unlink($archivePath);exit;
  }catch(Throwable $ex){
    if($zip instanceof ZipArchive)@$zip->close();
    if($inTransaction&&$pdo->inTransaction())try{$pdo->rollBack();}catch(Throwable $ignored){}
    foreach(admin_backup_table_names() as $table)@unlink($workspace.'/'.$table.'.jsonl');
    @rmdir($workspace);@unlink($archivePath);
    throw $ex;
  }
}

function admin_backup_read_table_stream(ZipArchive $zip,$entry,$columns,$assets,&$totalBytes,$expectedHash,$expectedRows,$validateOnly,$pdo=null,$table=''){
  $stream=$zip->getStream($entry);
  if(!$stream)throw new AdminBackupValidationException('ملف بيانات داخل النسخة غير قابل للقراءة.');
  $hash=hash_init('sha256');$count=0;$insertStatements=[];$insertable=[];
  if(!$validateOnly){
    foreach($columns[$table] as $name=>$info)if(!$info['generated'])$insertable[$name]=true;
  }
  try{
    while(($line=fgets($stream,16777218))!==false){
      $length=strlen($line);$totalBytes+=$length;
      if($totalBytes>2147483648||$length>16777216)throw new AdminBackupValidationException('حجم البيانات المضغوطة يتجاوز الحد الآمن للاستيراد.');
      hash_update($hash,$line);
      if($line===''||substr($line,-1)!=="\n")throw new AdminBackupValidationException('ملف بيانات داخل النسخة غير مكتمل.');
      try{$row=json_decode(substr($line,0,-1),false,512,JSON_THROW_ON_ERROR);}catch(Throwable $ex){throw new AdminBackupValidationException('تعذّر قراءة سجل من النسخة الاحتياطية.');}
      if(!$row instanceof stdClass)throw new AdminBackupValidationException('تنسيق سجلات النسخة الاحتياطية غير صالح.');
      $values=get_object_vars($row);
      foreach($values as $column=>$value){
        if(!isset($columns[$table][$column])||(!is_null($value)&&!is_scalar($value)))throw new AdminBackupValidationException('تحتوي النسخة على حقل أو قيمة غير متوافقة.');
      }
      if($table==='users'&&!empty($values['avatar'])&&!isset($assets['uploads/avatars/'.$values['avatar']]))throw new AdminBackupValidationException('النسخة لا تحتوي على صورة شخصية مرتبطة بأحد الحسابات.');
      if($table==='messages'&&!empty($values['audio_path'])&&!isset($assets['uploads/voice/'.$values['audio_path']]))throw new AdminBackupValidationException('النسخة لا تحتوي على تسجيل صوتي مرتبط بإحدى الرسائل.');
      if(!$validateOnly){
        $names=[];foreach($values as $name=>$value)if(isset($insertable[$name]))$names[]=$name;
        $cacheKey=implode("\0",$names);
        if(!isset($insertStatements[$cacheKey])){
          $quoted=array_map(fn($name)=>'`'.$name.'`',$names);
          $sql=$names?'INSERT INTO `'.$table.'` ('.implode(',',$quoted).') VALUES ('.implode(',',array_fill(0,count($names),'?')).')':'INSERT INTO `'.$table.'` () VALUES ()';
          $insertStatements[$cacheKey]=$pdo->prepare($sql);
        }
        $insertStatements[$cacheKey]->execute(array_map(fn($name)=>$values[$name],$names));
      }
      $count++;
    }
  }finally{fclose($stream);}
  if(!hash_equals($expectedHash,hash_final($hash))||$count!==(int)$expectedRows)throw new AdminBackupValidationException('فشل التحقق من سلامة بيانات النسخة الاحتياطية.');
  return $count;
}

function restore_user_backup(PDO $pdo,array $upload){
  @set_time_limit(600);
  if(!class_exists('ZipArchive'))throw new AdminBackupValidationException('ميزة ZIP غير متاحة على الخادم. فعّل إضافة ZIP في PHP ثم أعد المحاولة.');
  $error=(int)($upload['error']??UPLOAD_ERR_NO_FILE);
  if($error===UPLOAD_ERR_INI_SIZE||$error===UPLOAD_ERR_FORM_SIZE)throw new AdminBackupValidationException('حجم الملف أكبر من حد الرفع على الخادم.');
  if($error!==UPLOAD_ERR_OK||empty($upload['tmp_name'])||!is_uploaded_file($upload['tmp_name']))throw new AdminBackupValidationException('اختر ملف النسخة الاحتياطية بصيغة ZIP صالحًا.');
  $limit=admin_backup_max_bytes();$fileSize=(int)($upload['size']??0);
  if($fileSize<1||$fileSize>$limit||$fileSize>admin_backup_limit_bytes())throw new AdminBackupValidationException('حجم الملف يتجاوز حد الرفع المتاح ('.admin_backup_format_bytes(min($limit,admin_backup_limit_bytes())).').');
  if(!is_readable($upload['tmp_name']))throw new AdminBackupValidationException('تعذّر قراءة ملف النسخة الاحتياطية.');
  $zip=new ZipArchive();$opened=$zip->open($upload['tmp_name']);
  if($opened!==true)throw new AdminBackupValidationException('الملف المحدد ليس أرشيف ZIP صالحًا.');
  $stageFiles=[];$movedFiles=[];$totalBytes=0;$inTransaction=false;$foreignChecksDisabled=false;
  try{
    if($zip->numFiles<2||$zip->numFiles>10000)throw new AdminBackupValidationException('عدد الملفات داخل النسخة غير صالح.');
    $entryNames=[];$expanded=0;
    for($i=0;$i<$zip->numFiles;$i++){
      $name=$zip->getNameIndex($i);
      if(!is_string($name)||$name===''||substr($name,-1)==='/'||isset($entryNames[$name]))throw new AdminBackupValidationException('يحتوي الأرشيف على أسماء ملفات مكررة أو غير صالحة.');
      $entryNames[$name]=true;$stat=$zip->statIndex($i);
      if(!$stat||!isset($stat['size'])||$stat['size']<0)throw new AdminBackupValidationException('تعذّر قراءة بنية الأرشيف.');
      $expanded+=(int)$stat['size'];
      if($expanded>2147483648)throw new AdminBackupValidationException('حجم الملفات بعد فك الضغط يتجاوز الحد الآمن للاستيراد.');
    }
    $manifestRaw=$zip->getFromName('manifest.json');
    if(!is_string($manifestRaw)||strlen($manifestRaw)>2097152)throw new AdminBackupValidationException('ملف تعريف النسخة مفقود أو غير صالح.');
    try{$manifest=json_decode($manifestRaw,true,32,JSON_THROW_ON_ERROR);}catch(Throwable $ex){throw new AdminBackupValidationException('ملف تعريف النسخة غير صالح.');}
    if(!is_array($manifest)||($manifest['format']??'')!=='asrar-user-data-backup'||($manifest['version']??null)!==1||!is_array($manifest['tables']??null)||!is_array($manifest['assets']??null))throw new AdminBackupValidationException('صيغة النسخة غير مدعومة أو غير مكتملة.');
    $tables=admin_backup_table_names();$columns=admin_backup_columns($pdo);
    $manifestTableNames=array_keys($manifest['tables']);$sortedManifest=$manifestTableNames;$sortedExpected=$tables;sort($sortedManifest,SORT_STRING);sort($sortedExpected,SORT_STRING);
    if($sortedManifest!==$sortedExpected)throw new AdminBackupValidationException('النسخة لا تطابق بيانات المستخدمين المطلوبة في هذا الموقع.');
    $expectedNames=['manifest.json'=>true];$assetEntries=[];
    foreach($tables as $table){
      $entry=$manifest['tables'][$table];$expectedFile='database/'.$table.'.jsonl';
      if(!is_array($entry)||($entry['file']??'')!==$expectedFile||!is_int($entry['rows']??null)||$entry['rows']<0||!preg_match('/^[a-f0-9]{64}$/D',(string)($entry['sha256']??'')))throw new AdminBackupValidationException('بيانات أحد الجداول داخل النسخة غير صالحة.');
      $expectedNames[$expectedFile]=true;
    }
    foreach($manifest['assets'] as $relative=>$asset){
      if(!is_string($relative)||!is_array($asset))throw new AdminBackupValidationException('قائمة الصور والتسجيلات داخل النسخة غير صالحة.');
      if(preg_match('#^uploads/avatars/([a-f0-9]{32}\\.(?:jpg|png|webp|gif))$#D',$relative,$match)){$expectedFile='media/avatars/'.$match[1];$maxAsset=10485760;}
      elseif(preg_match('#^uploads/voice/([a-f0-9]{32}\\.(?:webm|ogg|m4a|mp3|wav))$#D',$relative,$match)){$expectedFile='media/voice/'.$match[1];$maxAsset=6291456;}
      else throw new AdminBackupValidationException('تحتوي النسخة على مسار ملف غير مسموح.');
      if(($asset['file']??'')!==$expectedFile||!is_int($asset['size']??null)||$asset['size']<0||$asset['size']>$maxAsset||!preg_match('/^[a-f0-9]{64}$/D',(string)($asset['sha256']??'')))throw new AdminBackupValidationException('بيانات صورة أو تسجيل داخل النسخة غير صالحة.');
      $expectedNames[$expectedFile]=true;$assetEntries[$relative]=['file'=>$expectedFile,'size'=>$asset['size'],'sha256'=>$asset['sha256']];
    }
    if(array_diff_key($entryNames,$expectedNames)||array_diff_key($expectedNames,$entryNames))throw new AdminBackupValidationException('الأرشيف يحتوي على ملفات غير متوقعة أو ملفات ناقصة.');
    foreach($tables as $table){
      $entry=$manifest['tables'][$table];
      admin_backup_read_table_stream($zip,$entry['file'],$columns,$assetEntries,$totalBytes,$entry['sha256'],$entry['rows'],true,null,$table);
    }
    if(!is_dir(__DIR__.'/uploads')&&!@mkdir(__DIR__.'/uploads',0755,true)&&!is_dir(__DIR__.'/uploads'))throw new AdminBackupValidationException('تعذّر تجهيز مجلد حفظ الصور والتسجيلات.');
    if(is_link(__DIR__.'/uploads'))throw new AdminBackupValidationException('مجلد uploads غير آمن للاستيراد.');
    $token=bin2hex(random_bytes(10));
    foreach($assetEntries as $relative=>$asset){
      $destination=__DIR__.'/'.$relative;$directory=dirname($destination);
      if(!is_dir($directory)&&!@mkdir($directory,0755,true)&&!is_dir($directory))throw new AdminBackupValidationException('تعذّر تجهيز مجلد حفظ الصور والتسجيلات.');
      if(is_link($directory)||!is_writable($directory))throw new AdminBackupValidationException('مجلد الصور أو التسجيلات غير قابل للكتابة.');
      if(file_exists($destination)){
        if(is_link($destination)||!is_file($destination)||filesize($destination)!==$asset['size']||!hash_equals($asset['sha256'],(string)hash_file('sha256',$destination)))throw new AdminBackupValidationException('يتعذّر الاستيراد بأمان بسبب تعارض اسم ملف وسائط موجود. لم يتم استبدال البيانات.');
        continue;
      }
      $source=$zip->getStream($asset['file']);$temporary=$destination.'.restore-'.$token;
      if(!$source)throw new AdminBackupValidationException('تعذّر قراءة ملف وسائط من النسخة.');
      $target=@fopen($temporary,'xb');
      if(!$target){fclose($source);throw new AdminBackupValidationException('تعذّر تجهيز ملفات الوسائط للاستيراد.');}
      $stageFiles[]=['temporary'=>$temporary,'destination'=>$destination];
      $hash=hash_init('sha256');$size=0;
      try{
        while(!feof($source)){
          $chunk=fread($source,65536);
          if($chunk===false)throw new AdminBackupValidationException('تعذّر قراءة ملف وسائط من النسخة.');
          if($chunk===''){if(feof($source))break;throw new AdminBackupValidationException('تعذّر قراءة ملف وسائط من النسخة.');}
          $size+=strlen($chunk);$totalBytes+=strlen($chunk);
          if($size>$asset['size']||$totalBytes>2147483648)throw new AdminBackupValidationException('حجم ملفات الوسائط داخل النسخة غير مطابق.');
          hash_update($hash,$chunk);
          if(fwrite($target,$chunk)!==strlen($chunk))throw new AdminBackupValidationException('تعذّر حفظ ملفات الوسائط للاستيراد.');
        }
      }finally{fclose($source);fclose($target);}
      if($size!==$asset['size']||!hash_equals($asset['sha256'],hash_final($hash)))throw new AdminBackupValidationException('فشل التحقق من سلامة أحد ملفات الصور أو التسجيلات.');
      @chmod($temporary,0644);
    }
    $totalBytes=0;
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');$foreignChecksDisabled=true;
    $pdo->beginTransaction();$inTransaction=true;
    foreach(array_reverse($tables) as $table)$pdo->exec('DELETE FROM `'.$table.'`');
    foreach($tables as $table){
      $entry=$manifest['tables'][$table];
      admin_backup_read_table_stream($zip,$entry['file'],$columns,$assetEntries,$totalBytes,$entry['sha256'],$entry['rows'],false,$pdo,$table);
    }
    foreach($stageFiles as $staged){
      if(!@rename($staged['temporary'],$staged['destination']))throw new RuntimeException('تعذّر تثبيت أحد ملفات الوسائط.');
      $movedFiles[]=$staged['destination'];
    }
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');$foreignChecksDisabled=false;
    $pdo->commit();$inTransaction=false;
    return ['tables'=>count($tables),'assets'=>count($assetEntries),'rows'=>array_sum(array_column($manifest['tables'],'rows'))];
  }catch(Throwable $ex){
    if($inTransaction&&$pdo->inTransaction())try{$pdo->rollBack();}catch(Throwable $ignored){}
    if($foreignChecksDisabled)try{$pdo->exec('SET FOREIGN_KEY_CHECKS=1');}catch(Throwable $ignored){}
    foreach($movedFiles as $path)@unlink($path);
    foreach($stageFiles as $staged)@unlink($staged['temporary']);
    if($ex instanceof AdminBackupValidationException)throw $ex;
    error_log('[Asrar backup restore] '.$ex->getMessage());
    throw new RuntimeException('تعذّر استيراد النسخة؛ لم تُحفظ تغييرات قاعدة البيانات. تحقق من توافق قاعدة البيانات ومساحة التخزين ثم أعد المحاولة.');
  }finally{$zip->close();}
}
?>
