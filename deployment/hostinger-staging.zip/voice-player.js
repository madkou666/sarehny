/* مشغّل الرسائل الصوتية — موجة صوتية + تقديم بالضغط + سرعة تشغيل */
(function(){
  var BARS=42, current=null;
  function fmt(s){s=Math.max(0,Math.round(s||0));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');}
  function fakePeaks(seed){var out=[],x=seed||7;for(var i=0;i<BARS;i++){x=(x*9301+49297)%233280;out.push(.25+.75*(x/233280)*Math.sin(Math.PI*(i+1)/(BARS+1))+.1);}return out;}
  function render(el){
    if(el._vp)return el._vp.reload(); var src=el.getAttribute('data-src')||'',dur=+el.getAttribute('data-secs')||0;
    el.innerHTML='<button type="button" class="vp-play" aria-label="تشغيل"><svg viewBox="0 0 24 24" class="vp-ic-play"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5Z"/></svg><svg viewBox="0 0 24 24" class="vp-ic-pause"><rect x="6" y="5" width="4" height="14" rx="1.2"/><rect x="14" y="5" width="4" height="14" rx="1.2"/></svg><span class="vp-spin"></span></button><div class="vp-wave" role="slider" tabindex="0" aria-label="موضع التشغيل" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div><span class="vp-time" dir="ltr">'+fmt(dur)+'</span><button type="button" class="vp-rate" aria-label="سرعة التشغيل">1×</button>';
    var a=new Audio(),play=el.querySelector('.vp-play'),wave=el.querySelector('.vp-wave'),time=el.querySelector('.vp-time'),rate=el.querySelector('.vp-rate'),bars=[],rates=[1,1.5,2],ri=0,loaded=false,version=0;
    a.preload='none';
    function drawBars(p){wave.innerHTML='';bars=p.map(function(v){var b=document.createElement('i');b.style.height=Math.round(v*100)+'%';wave.appendChild(b);return b;});}
    function initialBars(){var peaks;try{peaks=JSON.parse(el.getAttribute('data-peaks')||'null');}catch(e){}drawBars(Array.isArray(peaks)&&peaks.length===BARS?peaks:fakePeaks(src.length*13));}
    initialBars();
    function total(){return isFinite(a.duration)&&a.duration>0?a.duration:dur;}
    function paint(){var t=total(),p=t?a.currentTime/t:0;var n=Math.round(p*bars.length);for(var i=0;i<bars.length;i++)bars[i].classList.toggle('on',i<n);wave.setAttribute('aria-valuenow',Math.round(p*100));time.textContent=fmt(a.paused&&a.currentTime===0?t:a.currentTime);}
    var errorText=document.createElement('span');errorText.className='vp-error-text';errorText.setAttribute('role','status');errorText.hidden=true;el.appendChild(errorText);
    function fail(){el.classList.remove('loading','playing');el.classList.add('vp-error');errorText.hidden=false;errorText.textContent='تعذّر تشغيل التسجيل. حاول مجددًا.';play.setAttribute('aria-label','إعادة محاولة تشغيل التسجيل');}
    function load(){if(loaded||!src)return;loaded=true;a.src=src;}
    play.addEventListener('click',function(){load();errorText.hidden=true;el.classList.remove('vp-error');if(a.paused){if(current&&current!==a)current.pause();current=a;el.classList.add('loading');a.play().catch(fail);}else a.pause();});
    a.addEventListener('error',fail);
    a.addEventListener('waiting',function(){el.classList.add('loading');});
    a.addEventListener('playing',function(){el.classList.remove('loading');el.classList.add('playing');play.setAttribute('aria-label','إيقاف مؤقت');});
    a.addEventListener('pause',function(){el.classList.remove('playing','loading');play.setAttribute('aria-label','تشغيل');});
    a.addEventListener('ended',function(){a.currentTime=0;paint();});
    a.addEventListener('timeupdate',paint);a.addEventListener('loadedmetadata',paint);
    function seek(x){if(!src)return;load();var r=wave.getBoundingClientRect(),rtl=getComputedStyle(wave).direction==='rtl',p=(x-r.left)/r.width;if(rtl)p=1-p;p=Math.min(1,Math.max(0,p));var revision=version,go=function(){if(revision!==version)return;try{a.currentTime=p*total();paint();}catch(e){}};if(a.readyState>0)go();else a.addEventListener('loadedmetadata',go,{once:true});}
    var drag=false;wave.addEventListener('pointerdown',function(e){drag=true;wave.setPointerCapture(e.pointerId);seek(e.clientX);});wave.addEventListener('pointermove',function(e){if(drag)seek(e.clientX);});wave.addEventListener('pointerup',function(){drag=false;});wave.addEventListener('pointercancel',function(){drag=false;});wave.addEventListener('lostpointercapture',function(){drag=false;});
    wave.addEventListener('keydown',function(e){
      if(e.key==='ArrowLeft'||e.key==='ArrowRight'||e.key==='Home'||e.key==='End'){
        load();var rtl=getComputedStyle(wave).direction==='rtl',delta=e.key==='ArrowRight'?5:-5;if(rtl)delta=-delta;
        var revision=version,go=function(){if(revision!==version)return;try{a.currentTime=e.key==='Home'?0:e.key==='End'?total():Math.max(0,Math.min(total(),a.currentTime+delta));paint();}catch(err){}};
        if(a.readyState>0)go();else a.addEventListener('loadedmetadata',go,{once:true});e.preventDefault();
      }
      if(e.key===' '){play.click();e.preventDefault();}
    });
    rate.addEventListener('click',function(){ri=(ri+1)%rates.length;a.playbackRate=rates[ri];rate.textContent=rates[ri]+'×';rate.setAttribute('aria-label','سرعة التشغيل '+rates[ri]+' مرة');});
    function reset(){version++;a.pause();a.removeAttribute('src');a.load();loaded=false;src='';dur=0;ri=0;a.playbackRate=1;rate.textContent='1×';errorText.hidden=true;el.classList.remove('loading','playing','vp-error');if(current===a)current=null;}
    el._vp={reload:function(){reset();src=el.getAttribute('data-src')||'';dur=+el.getAttribute('data-secs')||0;initialBars();paint();},reset:reset,stop:function(){a.pause();}};
    window.addEventListener('pagehide',function(){reset();});
    el.classList.add('vp-ready');
  }
  window.VoicePlayer={mount:render,mountAll:function(root){(root||document).querySelectorAll('.vplayer[data-src]').forEach(render);}};
  if(document.readyState!=='loading')window.VoicePlayer.mountAll();else document.addEventListener('DOMContentLoaded',function(){window.VoicePlayer.mountAll();});
})();
