<?php require 'inc.php';
if(me()){ header('Location: dashboard.php'); exit; }
$mode=($_GET['m'] ?? 'signup')==='login'?'login':'signup'; $err='';
$restoreNotice=!empty($_SESSION['backup_restore_notice']);unset($_SESSION['backup_restore_notice']);
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=strtolower(trim($_POST['email']??'')); $pass=(string)($_POST['password']??'');
  if(($_POST['mode']??'')==='signup'){ $mode='signup';
    $u=strtolower(trim($_POST['username']??'')); $n=trim($_POST['name']??'');
    if(setting('allow_register','1')!=='1') $err='التسجيل مغلق حاليًا، حاول لاحقًا';
    elseif(mb_strlen($n)<2 || mb_strlen($n)>80) $err='اكتب اسمًا ظاهرًا من ٢ إلى ٨٠ حرفًا';
    elseif(!preg_match('/^[a-z0-9_]{3,30}$/',$u)) $err='اسم المستخدم من ٣ إلى ٣٠ حرفًا إنجليزيًا أو رقمًا أو _';
    elseif(in_array($u,array_filter(array_map('trim',explode("\n",strtolower(setting('reserved_usernames','admin\nadministrator\nroot\nsupport\nasrar'))))),true)) $err='اسم المستخدم هذا محجوز، اختر اسمًا آخر';
    elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)) $err='البريد الإلكتروني غير صالح';
    elseif(strlen($pass)<8) $err='كلمة المرور ٨ أحرف على الأقل';
    else { $s=$pdo->prepare('SELECT id FROM users WHERE username=? OR email=?'); $s->execute([$u,$email]);
      if($s->fetch()) $err='اسم المستخدم أو البريد مستخدم بالفعل';
      else { $pdo->prepare('INSERT INTO users(username,display_name,email,password_hash) VALUES(?,?,?,?)')->execute([$u,$n,$email,password_hash($pass,PASSWORD_DEFAULT)]);
        session_regenerate_id(true); $_SESSION['uid']=(int)$pdo->lastInsertId(); me(); flash('أهلًا بك! رابطك جاهز، شاركه وابدأ استقبال الرسائل.'); header('Location: dashboard.php'); exit; } }
  } else { $mode='login';
    $identifier=strtolower(trim($_POST['login_identifier']??$_POST['email']??''));
    $s=$pdo->prepare('SELECT * FROM users WHERE email=? OR username=? LIMIT 1'); $s->execute([$identifier,$identifier]); $u=$s->fetch();
    if(!$u || !password_verify($pass,$u['password_hash'])) $err='اسم المستخدم أو البريد الإلكتروني أو كلمة المرور غير صحيحة';
    elseif($u['is_disabled']) $err='هذا الحساب معطّل. تواصل مع الإدارة.';
    else { session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; me(); header('Location: dashboard.php'); exit; } }
}
head($mode==='signup'?'إنشاء حساب':'تسجيل الدخول','auth-page'); ?>
<section class="auth">
  <div class="auth-card">
    <aside class="auth-side">
      <span class="pill"><?=icon('lock')?> خاص وآمن</span>
      <h2><?= $mode==='signup'?'رابط واحد، وكلام كثير صادق.':'أهلًا بعودتك.' ?></h2>
      <p><?= $mode==='signup'?'أنشئ حسابك المجاني واحصل على رابطك الخاص لاستقبال الرسائل المجهولة.':'سجّل دخولك لقراءة رسائلك الجديدة.' ?></p>
      <ul class="auth-list">
        <li><?=icon('eye-off')?> هوية المرسل لا تظهر أبدًا</li>
        <li><?=icon('inbox')?> صندوق رسائل خاص بك</li>
        <li><?=icon('flag')?> أدوات حذف وإبلاغ</li>
      </ul>
    </aside>
    <div class="auth-form">
      <div class="seg" role="tablist">
        <a href="?m=signup" role="tab" aria-selected="<?= $mode==='signup'?'true':'false' ?>" class="<?= $mode==='signup'?'active':'' ?>">حساب جديد</a>
        <a href="?m=login" role="tab" aria-selected="<?= $mode==='login'?'true':'false' ?>" class="<?= $mode==='login'?'active':'' ?>">تسجيل الدخول</a>
      </div>
      <h1><?= $mode==='signup'?'أنشئ حسابك':'تسجيل الدخول' ?></h1>
      <?php if($restoreNotice): ?><?=alert_box('تمت استعادة النسخة بنجاح. سجّل الدخول باستخدام أحد الحسابات الموجودة في النسخة.','ok')?><?php endif; ?>
      <?php if($err) echo alert_box($err); ?>
      <?=oauth_buttons()?>
      <form method="post" class="form" novalidate>
        <?=csrf_field()?><input type="hidden" name="mode" value="<?=e($mode)?>">
        <?php if($mode==='signup'): ?>
        <div class="field"><label for="name">الاسم الظاهر</label><input id="name" name="name" required maxlength="80" autocomplete="name" placeholder="مثال: سارة" value="<?=e($_POST['name']??'')?>"></div>
        <div class="field"><label for="username">اسم المستخدم</label>
          <div class="input-prefix" dir="ltr"><span>@</span><input id="username" name="username" dir="ltr" required pattern="[a-zA-Z0-9_]{3,30}" maxlength="30" autocomplete="username" placeholder="sara_99" value="<?=e($_POST['username']??'')?>"></div>
          <small class="hint">حروف إنجليزية وأرقام و _ فقط</small></div>
        <?php endif; ?>
        <?php if($mode==='login'): ?>
        <div class="field"><label for="login_identifier">البريد الإلكتروني أو اسم المستخدم</label><input id="login_identifier" name="login_identifier" type="text" dir="ltr" required autocomplete="username" placeholder="you@example.com أو sara_99" value="<?=e($_POST['login_identifier']??$_POST['email']??'')?>"></div>
        <?php else: ?>
        <div class="field"><label for="email">البريد الإلكتروني</label><input id="email" name="email" type="email" dir="ltr" required autocomplete="email" placeholder="you@example.com" value="<?=e($_POST['email']??'')?>"></div>
        <?php endif; ?>
        <div class="field"><label for="password">كلمة المرور</label><input id="password" name="password" type="password" dir="ltr" minlength="8" required autocomplete="<?= $mode==='signup'?'new-password':'current-password' ?>" placeholder="••••••••">
          <?php if($mode==='signup'): ?><small class="hint">٨ أحرف على الأقل</small><?php endif; ?></div>
        <button class="btn lg block"><?= $mode==='signup'?'إنشاء الحساب':'دخول' ?> <?=icon('arrow')?></button>
      </form>
      <p class="switch"><?= $mode==='signup'?'لديك حساب بالفعل؟ <a href="?m=login">سجّل دخولك</a>':'ليس لديك حساب؟ <a href="?m=signup">أنشئ حسابًا مجانًا</a>' ?></p>
    </div>
  </div>
</section>
<?php foot();
