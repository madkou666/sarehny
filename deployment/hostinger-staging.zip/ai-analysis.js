(function () {
  var form = document.getElementById('ai-analysis-form');
  if (!form) return;
  var consent = document.getElementById('ai-consent');
  var button = form.querySelector('.ai-submit');
  var feedback = document.getElementById('ai-feedback');
  var resultSection = document.getElementById('ai-result');
  var ring = document.getElementById('ai-score-ring');

  if (consent && button && !button.disabled) {
    button.disabled = true;
    consent.addEventListener('change', function () { button.disabled = !consent.checked; });
  }

  function listInto(id, items) {
    var list = document.getElementById(id);
    list.replaceChildren();
    (Array.isArray(items) ? items : []).forEach(function (item) {
      var li = document.createElement('li');
      li.textContent = String(item);
      list.appendChild(li);
    });
    if (!list.children.length) {
      var li = document.createElement('li');
      li.textContent = 'لا توجد ملاحظة متكررة كافية في الرسائل المتاحة.';
      list.appendChild(li);
    }
  }


  var boot = {};
  try { boot = JSON.parse((document.getElementById('ai-boot') || {}).textContent || '{}') || {}; } catch (e) { boot = {}; }
  var DIM = boot.dimensions || { warmth: 'الدفء والمودة', admiration: 'الإعجاب والتقدير', respect: 'الاحترام', trust: 'الثقة والارتياح', humor: 'خفة الظل', support: 'الدعم والتشجيع' };
  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lastResult = null;
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = String(text); return n; }
  function arNum(n) { try { return Number(n).toLocaleString('ar-EG'); } catch (e) { return String(n); } }
  function level(s) {
    if (s >= 85) return 'حضور محبوب جدًا، رسائلك تفيض بالمودة.';
    if (s >= 70) return 'انطباع إيجابي واضح ومحبة ملحوظة.';
    if (s >= 50) return 'انطباع متوازن مع مساحة جميلة للنمو.';
    if (s >= 30) return 'آراء متباينة، وفرصة لتقوية الانطباع.';
    return 'الرسائل قليلة الدفء حاليًا، والنتيجة ليست حكمًا عليك.';
  }
  function animateScore(target) {
    var node = document.getElementById('ai-score');
    if (reduced) { node.textContent = arNum(target); ring.style.setProperty('--score', target + '%'); return; }
    var t0 = null;
    function step(t) { if (!t0) t0 = t; var p = Math.min(1, (t - t0) / 1100); var e = 1 - Math.pow(1 - p, 3); var v = Math.round(target * e); node.textContent = arNum(v); ring.style.setProperty('--score', v + '%'); if (p < 1) requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }
  function renderHistory(history) {
    var box = document.getElementById('ai-history-bars');
    if (!box || !Array.isArray(history)) return;
    box.replaceChildren();
    history.filter(function (h) { return h && h.score != null; }).forEach(function (h, i, arr) {
      var col = el('div', 'ai-hbar' + (i === arr.length - 1 ? ' is-latest' : ''));
      var bar = el('i'); bar.style.setProperty('--h', Math.max(4, Number(h.score)) + '%');
      col.append(el('b', null, arNum(h.score)), bar, el('small', null, String(h.created_at || '').slice(5, 10).replace('-', '/')));
      box.appendChild(col);
    });
  }
  function renderResult(r, meta) {
    meta = meta || {};
    lastResult = r;
    var score = Math.max(0, Math.min(100, Number(r.score) || 0));
    ring.setAttribute('aria-label', 'درجة المحبوبية: ' + score + ' من ١٠٠');
    animateScore(score);
    document.getElementById('ai-persona').textContent = r.personality_title ? r.personality_title : 'درجة المحبوبية';
    document.getElementById('ai-score-level').textContent = level(score);
    var delta = document.getElementById('ai-delta');
    if (meta.previous != null && Number.isFinite(Number(meta.previous))) {
      var d = score - Number(meta.previous);
      delta.hidden = false;
      delta.className = 'ai-delta ' + (d > 0 ? 'is-up' : d < 0 ? 'is-down' : 'is-same');
      delta.textContent = d === 0 ? 'نفس درجتك السابقة' : (d > 0 ? '▲ ' : '▼ ') + arNum(Math.abs(d)) + ' عن تحليلك السابق';
    } else delta.hidden = true;
    var date = document.getElementById('ai-result-date');
    if (date) { var dt = meta.at ? new Date(String(meta.at).replace(' ', 'T')) : new Date(); date.textContent = isNaN(dt) ? '' : 'بتاريخ ' + dt.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }); }
    document.getElementById('ai-impression').textContent = String(r.impression || '');
    var style = document.getElementById('ai-style');
    style.hidden = !r.communication_style; style.textContent = r.communication_style || '';
    document.getElementById('ai-summary').textContent = String(r.summary || '');
    listInto('ai-strengths', r.strengths);
    listInto('ai-traits', r.repeated_traits);
    listInto('ai-improvements', r.improvements);
    // dimensions
    var dp = document.getElementById('ai-dimensions-panel'), dims = document.getElementById('ai-dimensions');
    dims.replaceChildren();
    if (r.dimensions && typeof r.dimensions === 'object') {
      Object.keys(DIM).forEach(function (k) {
        if (r.dimensions[k] == null) return;
        var v = Math.max(0, Math.min(100, Number(r.dimensions[k]) || 0));
        var row = el('div', 'ai-dim');
        var head = el('div', 'ai-dim-head'); head.append(el('span', null, DIM[k]), el('b', null, arNum(v) + '٪'));
        var track = el('div', 'ai-dim-track'); var fill = el('i'); track.appendChild(fill);
        track.setAttribute('role', 'progressbar'); track.setAttribute('aria-valuemin', '0'); track.setAttribute('aria-valuemax', '100'); track.setAttribute('aria-valuenow', String(v)); track.setAttribute('aria-label', DIM[k]);
        row.append(head, track); dims.appendChild(row);
        setTimeout(function () { fill.style.width = v + '%'; }, reduced ? 0 : 120);
      });
    }
    dp.hidden = !dims.children.length;
    // sentiment
    var sp = document.getElementById('ai-sentiment-panel');
    var s = r.sentiment;
    if (s && typeof s === 'object') {
      var bar = document.getElementById('ai-sentiment-bar'), legend = document.getElementById('ai-sentiment-legend');
      bar.replaceChildren(); legend.replaceChildren();
      [['positive', 'إيجابية'], ['neutral', 'محايدة'], ['negative', 'سلبية']].forEach(function (p) {
        var v = Math.max(0, Number(s[p[0]]) || 0);
        var seg = el('i', 'is-' + p[0]); seg.style.flexGrow = String(v); if (v > 0) bar.appendChild(seg);
        var li = el('li', 'is-' + p[0]); li.append(el('span'), el('em', null, p[1]), el('b', null, arNum(v) + '٪')); legend.appendChild(li);
      });
      sp.hidden = false;
    } else sp.hidden = true;
    // themes
    var tp = document.getElementById('ai-themes-panel'), tags = document.getElementById('ai-themes');
    tags.replaceChildren();
    (Array.isArray(r.themes) ? r.themes : []).forEach(function (t) { tags.appendChild(el('span', 'ai-tag', t)); });
    tp.hidden = !tags.children.length;
    var ap = document.getElementById('ai-advice-panel');
    ap.hidden = !r.advice; document.getElementById('ai-advice').textContent = r.advice || '';
    if (meta.history) renderHistory(meta.history);
    resultSection.hidden = false;
  }

  // Share card (canvas, fully client-side)
  function wrapLines(ctx, text, maxW) {
    var words = String(text || '').split(/\s+/), lines = [], line = '';
    words.forEach(function (w) { var t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t; });
    if (line) lines.push(line); return lines;
  }
  function shareCard() {
    if (!lastResult) return;
    var r = lastResult, W = 1080, H = 1350, c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'), css = getComputedStyle(document.documentElement);
    var accent = (css.getPropertyValue('--secondary-accent') || '#ff4d8d').trim() || '#ff4d8d';
    var font = getComputedStyle(document.body).fontFamily || 'sans-serif';
    var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#1a1220'); g.addColorStop(1, '#0d0b12'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    var rg = x.createRadialGradient(W * .85, 120, 10, W * .85, 120, 520); rg.addColorStop(0, accent + '55'); rg.addColorStop(1, 'transparent'); x.fillStyle = rg; x.fillRect(0, 0, W, H);
    x.direction = 'rtl'; x.textAlign = 'center'; x.fillStyle = '#ffffffaa'; x.font = '600 34px ' + font; x.fillText('تحليل شخصيتي من رسائلي', W / 2, 120);
    var cx = W / 2, cy = 400, R = 190, sc = Math.max(0, Math.min(100, Number(r.score) || 0));
    x.lineWidth = 26; x.strokeStyle = '#ffffff1f'; x.beginPath(); x.arc(cx, cy, R, 0, Math.PI * 2); x.stroke();
    x.strokeStyle = accent; x.lineCap = 'round'; x.beginPath(); x.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * sc / 100); x.stroke();
    x.fillStyle = '#fff'; x.font = '800 150px ' + font; x.textBaseline = 'middle'; x.fillText(arNum(sc), cx, cy - 10);
    x.font = '500 32px ' + font; x.fillStyle = '#ffffff99'; x.fillText('من ١٠٠', cx, cy + 90); x.textBaseline = 'alphabetic';
    x.fillStyle = '#fff'; x.font = '800 58px ' + font; x.fillText(r.personality_title || 'شخص محبوب', W / 2, 700);
    x.font = '400 34px ' + font; x.fillStyle = '#ffffffcc';
    wrapLines(x, r.summary || r.impression, W - 200).slice(0, 4).forEach(function (l, i) { x.fillText(l, W / 2, 790 + i * 56); });
    var items = (r.strengths || []).slice(0, 3); x.font = '600 32px ' + font;
    var y = 1060; items.forEach(function (t) { var w = Math.min(W - 160, x.measureText(t).width + 70); x.fillStyle = '#ffffff14'; x.beginPath(); if (x.roundRect) x.roundRect((W - w) / 2, y - 44, w, 64, 32); else x.rect((W - w) / 2, y - 44, w, 64); x.fill(); x.fillStyle = '#fff'; x.fillText('✦ ' + t, W / 2, y); y += 84; });
    x.font = '500 28px ' + font; x.fillStyle = '#ffffff77'; x.fillText(location.host, W / 2, H - 50);
    c.toBlob(function (b) {
      if (!b) return;
      var file = new File([b], 'my-analysis.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: 'تحليل شخصيتي' }).catch(function () {}); return; }
      var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'my-analysis.png'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
    }, 'image/png');
  }
  var shareBtn = document.getElementById('ai-share-btn');
  if (shareBtn) shareBtn.addEventListener('click', shareCard);
  var copyBtn = document.getElementById('ai-copy-btn');
  if (copyBtn) copyBtn.addEventListener('click', function () {
    if (!lastResult) return;
    var r = lastResult;
    var txt = (r.personality_title ? r.personality_title + ' — ' : '') + 'درجة المحبوبية: ' + r.score + '/100\n' + (r.summary || '') + '\n' + location.origin;
    (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { copyBtn.textContent = 'تم النسخ ✓'; setTimeout(function () { copyBtn.textContent = '⧉ نسخ الملخص'; }, 1800); }).catch(function () {});
  });
  renderHistory(boot.history);
  if (boot.latest && boot.latest.result) {
    var h = (boot.history || []).filter(function (x) { return x.score != null; });
    renderResult(boot.latest.result, { at: boot.latest.analyzed_at, previous: h.length > 1 ? h[h.length - 2].score : null });
    var badge = document.querySelector('.ai-result-badge'); if (badge) badge.textContent = 'آخر تحليل محفوظ';
  }

  var inFlight = false;
  var latestRemaining = null;
  function showQuota(q) {
    if (!q || !Number.isFinite(Number(q.remaining))) return;
    latestRemaining = Number(q.remaining);
    var counter = document.querySelector('.ai-usage-row > strong');
    if (!counter) return;
    counter.replaceChildren();
    var a = document.createElement('span'); a.textContent = String(latestRemaining);
    var b = document.createElement('small'); b.textContent = ' / ' + Number(q.limit || 0);
    counter.append(a, b);
  }
  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (inFlight || !consent || !consent.checked || button.disabled) return;
    inFlight = true;
    button.disabled = true;
    var requestId = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : (Date.now().toString(36) + Math.random().toString(36).slice(2));
    form.classList.add('is-loading');
    feedback.textContent = 'نراجع الرسائل المؤهلة ونعدّ تحليلك…';
    feedback.className = 'ai-feedback';
    try {
      var send = function () {
        var fd = new FormData(form);
        fd.set('request_id', requestId);
        return fetch(form.getAttribute('action') || 'analysis.php', {
          method: 'POST',
          body: fd,
          credentials: 'same-origin',
          cache: 'no-store',
          headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        });
      };
      var response = await send();
      var payload;
      var rawText = await response.text();
      try { payload = JSON.parse(rawText.replace(/^\uFEFF/, '').trim()); } catch (e) { payload = null; }
      if (payload && payload.code === 'csrf' && payload.csrf) {
        var tokenInput = form.querySelector('input[name="csrf"]');
        if (tokenInput) tokenInput.value = payload.csrf;
        response = await send();
        rawText = await response.text();
        try { payload = JSON.parse(rawText.replace(/^\uFEFF/, '').trim()); } catch (e) { payload = null; }
      }
      if (!payload) {
        if (response.status === 504 || response.status === 524 || response.status === 408) throw new Error('استغرق التحليل وقتًا أطول من المسموح على الخادم. حاول مجددًا بعد قليل.');
        if (response.redirected || response.status === 401) throw new Error('انتهت الجلسة. أعد تحميل الصفحة وسجّل الدخول ثم حاول مجددًا.');
        throw new Error('تعذّر قراءة رد الخادم (رمز ' + response.status + '). حاول مجددًا بعد قليل.');
      }
      if (!response.ok || !payload.ok) { if (payload.quota) showQuota(payload.quota); throw new Error(payload.message || 'تعذّر إكمال التحليل الآن. حاول لاحقًا.'); }

      renderResult(payload.result, { stats: payload.stats, previous: payload.previous_score, history: payload.history, at: payload.analyzed_at });
      feedback.textContent = 'اكتمل التحليل بنجاح.';
      feedback.className = 'ai-feedback is-success';
      var bdg = document.querySelector('.ai-result-badge'); if (bdg) bdg.textContent = 'تحليل جديد';
      showQuota(payload.quota);
      button.disabled = !(latestRemaining === null || latestRemaining > 0) || !consent.checked;
      resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (error) {
      feedback.textContent = error && error.message ? error.message : 'تعذّر الاتصال بالخدمة. تحقّق من اتصالك وحاول لاحقًا.';
      feedback.className = 'ai-feedback is-error';
      button.disabled = !consent.checked || latestRemaining === 0;
    } finally {
      inFlight = false;
      form.classList.remove('is-loading');
    }
  });
})();
