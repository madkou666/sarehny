<?php
// صورة معاينة الرابط (Facebook / واتساب / X) لكل مستخدم: og.php?n=username
require 'inc.php';

function og_hex($h,$fb){ $h=ltrim((string)$h,'#'); if(!preg_match('/^[0-9a-f]{6}$/i',$h)) $h=ltrim($fb,'#'); return [hexdec(substr($h,0,2)),hexdec(substr($h,2,2)),hexdec(substr($h,4,2))]; }

// تشكيل الحروف العربية (GD لا يدعم وصل الحروف ولا الاتجاه من اليمين لليسار)
function og_ar($text){
  static $F=null;
  if($F===null){ $F=[ // iso, fin, ini, med
    0x0621=>[0xFE80,0,0,0],0x0622=>[0xFE81,0xFE82,0,0],0x0623=>[0xFE83,0xFE84,0,0],0x0624=>[0xFE85,0xFE86,0,0],0x0625=>[0xFE87,0xFE88,0,0],0x0626=>[0xFE89,0xFE8A,0xFE8B,0xFE8C],0x0627=>[0xFE8D,0xFE8E,0,0],0x0628=>[0xFE8F,0xFE90,0xFE91,0xFE92],0x0629=>[0xFE93,0xFE94,0,0],0x062A=>[0xFE95,0xFE96,0xFE97,0xFE98],0x062B=>[0xFE99,0xFE9A,0xFE9B,0xFE9C],0x062C=>[0xFE9D,0xFE9E,0xFE9F,0xFEA0],0x062D=>[0xFEA1,0xFEA2,0xFEA3,0xFEA4],0x062E=>[0xFEA5,0xFEA6,0xFEA7,0xFEA8],0x062F=>[0xFEA9,0xFEAA,0,0],0x0630=>[0xFEAB,0xFEAC,0,0],0x0631=>[0xFEAD,0xFEAE,0,0],0x0632=>[0xFEAF,0xFEB0,0,0],0x0633=>[0xFEB1,0xFEB2,0xFEB3,0xFEB4],0x0634=>[0xFEB5,0xFEB6,0xFEB7,0xFEB8],0x0635=>[0xFEB9,0xFEBA,0xFEBB,0xFEBC],0x0636=>[0xFEBD,0xFEBE,0xFEBF,0xFEC0],0x0637=>[0xFEC1,0xFEC2,0xFEC3,0xFEC4],0x0638=>[0xFEC5,0xFEC6,0xFEC7,0xFEC8],0x0639=>[0xFEC9,0xFECA,0xFECB,0xFECC],0x063A=>[0xFECD,0xFECE,0xFECF,0xFED0],0x0641=>[0xFED1,0xFED2,0xFED3,0xFED4],0x0642=>[0xFED5,0xFED6,0xFED7,0xFED8],0x0643=>[0xFED9,0xFEDA,0xFEDB,0xFEDC],0x0644=>[0xFEDD,0xFEDE,0xFEDF,0xFEE0],0x0645=>[0xFEE1,0xFEE2,0xFEE3,0xFEE4],0x0646=>[0xFEE5,0xFEE6,0xFEE7,0xFEE8],0x0647=>[0xFEE9,0xFEEA,0xFEEB,0xFEEC],0x0648=>[0xFEED,0xFEEE,0,0],0x0649=>[0xFEEF,0xFEF0,0,0],0x064A=>[0xFEF1,0xFEF2,0xFEF3,0xFEF4],
  ]; }
  $LA=[0x0622=>[0xFEF5,0xFEF6],0x0623=>[0xFEF7,0xFEF8],0x0625=>[0xFEF9,0xFEFA],0x0627=>[0xFEFB,0xFEFC]];
  $cs=[]; foreach(preg_split('//u',(string)$text,-1,PREG_SPLIT_NO_EMPTY) as $ch){ $o=mb_ord($ch,'UTF-8'); if(($o>=0x064B&&$o<=0x0652)||$o===0x0640) continue; $cs[]=$o; }
  $n=count($cs); $out=[];
  $joinsFwd=function($c)use($F){return isset($F[$c])&&$F[$c][2];};
  for($i=0;$i<$n;$i++){
    $c=$cs[$i];
    if(!isset($F[$c])){ $out[]=$c; continue; }
    $prev=$i>0&&$joinsFwd($cs[$i-1]);
    if($c===0x0644 && $i+1<$n && isset($LA[$cs[$i+1]])){ $out[]=$LA[$cs[$i+1]][$prev?1:0]; $i++; continue; }
    $next=$i+1<$n&&isset($F[$cs[$i+1]])&&$F[$c][2];
    $f=$F[$c];
    $out[]= $prev&&$next?$f[3]:($prev?$f[1]:($next?$f[2]:$f[0]));
  }
  // عكس الترتيب للعرض من اليمين لليسار مع الحفاظ على الكلمات اللاتينية والأرقام
  $runs=[];$cur=[];$curLtr=null;
  foreach($out as $c){ $ltr=($c<0x0590)&&$c!==0x20&&!in_array($c,[0x28,0x29,0x2E,0x21,0x3F,0x2C,0x3A],true); if($curLtr!==null&&$ltr!==$curLtr){$runs[]=[$curLtr,$cur];$cur=[];} $curLtr=$ltr;$cur[]=$c; }
  if($cur) $runs[]=[$curLtr,$cur];
  $hasAr=false; foreach($out as $c) if($c>=0x0600){$hasAr=true;break;}
  if(!$hasAr) return (string)$text;
  $s=''; foreach(array_reverse($runs) as [$ltr,$r]){ if(!$ltr) $r=array_reverse($r); foreach($r as $c){ $s.=mb_chr($c,'UTF-8'); } }
  return $s;
}

$s=$pdo->prepare('SELECT id,username,display_name,avatar,is_disabled,is_verified FROM users WHERE username=?');
$s->execute([strtolower((string)($_GET['n']??''))]); $user=$s->fetch();
if(!$user||$user['is_disabled']||!function_exists('imagecreatetruecolor')){ header('Location: '.base_url().'/og-image.jpg',true,302); exit; }

$av=avatar_url($user); $bgHex=theme_color('bg'); $prHex=theme_color('primary');
$key=md5($user['id'].'|'.$user['display_name'].'|'.$user['username'].'|'.$av.'|'.$bgHex.$prHex.site_name().'|v1');
$dir=__DIR__.'/uploads/og'; if(!is_dir($dir)) @mkdir($dir,0755,true);
$file=$dir.'/'.$user['id'].'-'.$key.'.jpg';
header('Content-Type: image/jpeg'); header('Cache-Control: public, max-age=86400');
if(is_file($file)){ readfile($file); exit; }

$W=1200;$H=630; $im=imagecreatetruecolor($W,$H); imageantialias($im,true);
[$br,$bg,$bb]=og_hex($bgHex,'#0b1020'); [$pr,$pg,$pb]=og_hex($prHex,'#3df0c0');
// خلفية متدرجة
for($y=0;$y<$H;$y++){ $t=$y/$H; $c=imagecolorallocate($im,(int)($br*(1-$t*0.35)),(int)($bg*(1-$t*0.35)),(int)($bb*(1-$t*0.35))); imageline($im,0,$y,$W,$y,$c); }
// توهج دائري بلون الهوية
for($r=520;$r>0;$r-=8){ $a=(int)(127-(1-$r/520)*38); $c=imagecolorallocatealpha($im,$pr,$pg,$pb,max(90,$a)); imagefilledellipse($im,980,140,$r,$r,$c); }
for($r=420;$r>0;$r-=8){ $a=(int)(127-(1-$r/420)*30); $c=imagecolorallocatealpha($im,$pr,$pg,$pb,max(100,$a)); imagefilledellipse($im,120,560,$r,$r,$c); }
// بطاقة زجاجية
$card=imagecolorallocatealpha($im,255,255,255,116); imagefilledrectangle($im,60,60,$W-60,$H-60,$card);
$line=imagecolorallocatealpha($im,255,255,255,100); imagerectangle($im,60,60,$W-60,$H-60,$line);
$white=imagecolorallocate($im,255,255,255); $soft=imagecolorallocatealpha($im,255,255,255,40); $prim=imagecolorallocate($im,$pr,$pg,$pb);
$bold=__DIR__.'/fonts/NotoKufiArabic-Bold.ttf'; $med=__DIR__.'/fonts/NotoKufiArabic-Medium.ttf';

// الصورة الشخصية دائرية
$cx=$W-260;$cy=$H/2;$D=300;
imagefilledellipse($im,$cx,$cy,$D+24,$D+24,$prim);
$src=null; if($av){ $raw=@file_get_contents(__DIR__.'/'.$av); if($raw) $src=@imagecreatefromstring($raw); }
if($src){
  $sw=imagesx($src);$sh=imagesy($src);$m=min($sw,$sh);
  $sq=imagecreatetruecolor($D,$D); imagecopyresampled($sq,$src,0,0,(int)(($sw-$m)/2),(int)(($sh-$m)/2),$D,$D,$m,$m);
  $r2=($D/2)*($D/2);
  for($x=0;$x<$D;$x++) for($y=0;$y<$D;$y++){ $dx=$x-$D/2+.5;$dy=$y-$D/2+.5; if($dx*$dx+$dy*$dy<=$r2) imagesetpixel($im,(int)($cx-$D/2+$x),(int)($cy-$D/2+$y),imagecolorat($sq,$x,$y)); }
  imagedestroy($sq); imagedestroy($src);
}else{
  $dark=imagecolorallocate($im,(int)($br*.6),(int)($bg*.6),(int)($bb*.6)); imagefilledellipse($im,$cx,$cy,$D,$D,$dark);
  $ini=mb_substr(trim($user['display_name'])?:$user['username'],0,1); $ini=og_ar($ini);
  $bx=imagettfbbox(130,0,$bold,$ini); imagettftext($im,130,0,(int)($cx-($bx[2]-$bx[0])/2),(int)($cy+60),$prim,$bold,$ini);
}

// النصوص (محاذاة يمين بجانب الصورة)
$right=$cx-$D/2-50; $maxW=$right-110;
$fit=function($txt,$font,$size,$min)use($maxW){ while($size>$min){ $b=imagettfbbox($size,0,$font,$txt); if($b[2]-$b[0]<=$maxW) break; $size-=2; } return $size; };
$draw=function($txt,$font,$size,$y,$col)use($im,$right){ $b=imagettfbbox($size,0,$font,$txt); imagettftext($im,$size,0,(int)($right-($b[2]-$b[0])),$y,$col,$font,$txt); return $b[2]-$b[0]; };

$name=trim($user['display_name'])?:$user['username']; if(mb_strlen($name)>28) $name=mb_substr($name,0,27).'…';
$t1=og_ar('أرسل رسالة مجهولة إلى'); $draw($t1,$med,30,200,$soft);
$nm=og_ar($name); $ns=$fit($nm,$bold,72,34); $draw($nm,$bold,$ns,200+30+$ns+10,$white);
$hy=200+30+$ns+10+60; $draw('@'.$user['username'],$med,28,$hy,$prim);
$t3=og_ar('اكتب بصراحة… لن يعرف من أنت'); $draw($t3,$med,28,$hy+70,$soft);
// شارة الموقع أسفل
$sn=og_ar(site_name()); $bx=imagettfbbox(26,0,$bold,$sn); $pw=$bx[2]-$bx[0]+56;
imagefilledrectangle($im,(int)($right-$pw),$H-150,(int)$right,$H-96,$prim);
$on=theme_on_primary(); [$or,$og,$ob]=og_hex($on,'#000000'); $onC=imagecolorallocate($im,$or,$og,$ob);
imagettftext($im,26,0,(int)($right-$pw+28),$H-111,$onC,$bold,$sn);

foreach(glob($dir.'/'.$user['id'].'-*.jpg')?:[] as $old) @unlink($old);
imagejpeg($im,$file,90); imagedestroy($im);
readfile($file);
