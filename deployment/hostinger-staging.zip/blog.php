<?php require 'inc.php';
$posts=$pdo->query('SELECT id,title,excerpt,body,created_at FROM blog_posts WHERE published=1 ORDER BY created_at DESC,id DESC LIMIT 60')->fetchAll();
head('المدونة','content-page'); ?>
<section class="content-intro"><div class="wrap"><span class="content-kicker">من أسرار / المدونة</span><h1>أفكار تستحق أن تُقال.</h1><p>مساحة للحكايات والأفكار حول الصراحة والتواصل.</p></div></section>
<section class="content-section"><div class="wrap"><div class="content-section-head"><h2>أحدث المقالات</h2><span><?=ar_num(count($posts))?> مقال</span></div>
<?php if(!$posts): ?><div class="content-empty"><h2>القصص قادمة قريبًا</h2><p>نعمل على إعداد محتوى يستحق القراءة. عد لزيارتنا قريبًا.</p></div><?php else: ?><div class="post-grid"><?php foreach($posts as $post): ?><article class="post-card"><span class="content-kicker"><?=e(date('Y/m/d',strtotime($post['created_at'])))?></span><h3><a href="post.php?id=<?=(int)$post['id']?>"><?=e($post['title'])?></a></h3><p><?=e($post['excerpt']!==''?$post['excerpt']:mb_substr($post['body'],0,160).'…')?></p><a class="text-link" href="post.php?id=<?=(int)$post['id']?>">اقرأ المقال <?=icon('arrow')?></a></article><?php endforeach; ?></div><?php endif; ?>
</div></section><?php foot(); ?>
