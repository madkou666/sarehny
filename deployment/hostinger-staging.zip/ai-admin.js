(function () {
  var form = document.getElementById('ai-admin-form');
  if (!form) return;

  document.querySelectorAll('[data-provider-test]').forEach(function (button) {
    button.addEventListener('click', async function () {
      var provider = button.getAttribute('data-provider-test');
      var card = button.closest('[data-provider-card]');
      if (!provider || !card) return;
      var status = card.querySelector('[data-provider-message]');
      var state = card.querySelector('[data-provider-state]');
      var key = card.querySelector('input[name="provider_api_key[' + provider + ']"]');
      var model = card.querySelector('input[name="provider_model[' + provider + ']"]');
      var dataList = card.querySelector('datalist');
      button.disabled = true;
      status.textContent = 'جارٍ اختبار المفتاح وجلب النماذج المتاحة…';
      status.className = 'ai-test-status';
      try {
        var data = new FormData();
        var csrf = form.querySelector('input[name="csrf"]');
        data.set('csrf', csrf ? csrf.value : '');
        data.set('action', 'test');
        data.set('provider', provider);
        if (key && key.value) data.set('provider_api_key[' + provider + ']', key.value);
        if (model) data.set('provider_model[' + provider + ']', model.value);
        var endpoint = new URL('ai_admin.php', window.location.href);
        var response = await fetch(endpoint.toString(), {
          method: 'POST', cache: 'no-store', body: data, credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        });
        var result;
        try { result = await response.json(); }
        catch (parseError) { throw new Error('أعاد الخادم ردًا غير صالح (HTTP ' + response.status + ').'); }
        (Array.isArray(result.models) ? result.models : []).forEach(function (available) {
          var option = document.createElement('option');
          option.value = String(available.id || '');
          option.label = String(available.label || available.id || '');
          if (dataList && option.value && !Array.from(dataList.options).some(function (existing) { return existing.value === option.value; })) dataList.appendChild(option);
        });
        if (result.suggested && model) model.value = result.suggested;
        if (!response.ok || !result.ok) throw new Error(result.message || 'تعذّر اختبار الاتصال (HTTP ' + response.status + ').');
        status.textContent = result.message || 'نجح الاتصال.';
        status.className = 'ai-test-status is-success';
        if (state) { state.textContent = 'متصل'; state.className = 'ai-provider-status is-connected'; }
      } catch (error) {
        status.textContent = error && error.message ? error.message : 'تعذّر الاتصال. تحقق من المفتاح واتصال الخادم.';
        status.className = 'ai-test-status is-error';
        if (state) { state.textContent = 'فشل الاختبار'; state.className = 'ai-provider-status is-failed'; }
      } finally {
        button.disabled = false;
      }
    });
  });
})();
