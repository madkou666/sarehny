<?php
/*
 * تحليل المرسل (ميزة مدفوعة يفعّلها المدير لكل مستخدم)
 * يجمع: IP، نوع الجهاز والنظام والمتصفح، الموقع التقريبي، وبيانات الجلسة.
 */

function insights_active($u){
  if(empty($u['insights_enabled'])) return false;
  $until=$u['insights_until'] ?? null;
  return !$until || strtotime((string)$until) > time();
}

function client_ip(){
  foreach(['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $k){
    $v=trim((string)($_SERVER[$k]??'')); if($v==='') continue;
    $v=trim(explode(',',$v)[0]);
    if(filter_var($v,FILTER_VALIDATE_IP)) return $v;
  }
  return '';
}

function parse_ua($ua){
  $ua=(string)$ua; $l=strtolower($ua);
  $os='غير معروف'; $device='غير معروف'; $type='كمبيوتر';
  if(preg_match('/iphone|ipod/i',$ua)){ $os='iOS'; $device='iPhone'; $type='موبايل'; }
  elseif(strpos($l,'ipad')!==false){ $os='iPadOS'; $device='iPad'; $type='تابلت'; }
  elseif(strpos($l,'android')!==false){
    $os='Android'; $type=strpos($l,'mobile')!==false?'موبايل':'تابلت';
    if(preg_match('/;\s*([^;\)]*(?:SM-|Redmi|POCO|CPH|Infinix|Tecno|vivo|OPPO|Pixel|HUAWEI|Nokia|realme)[^;\)]*)\s*(?:build|\))/i',$ua,$m)) $device=trim($m[1]);
    else $device='هاتف أندرويد';
  }
  elseif(strpos($l,'windows')!==false){ $os='Windows'; $device='كمبيوتر ويندوز'; }
  elseif(strpos($l,'mac os x')!==false){ $os='macOS'; $device='Mac'; }
  elseif(strpos($l,'linux')!==false){ $os='Linux'; $device='كمبيوتر لينكس'; }
  if(preg_match('/OS (\d+)[._](\d+)/',$ua,$m) && ($os==='iOS'||$os==='iPadOS')) $os.=' '.$m[1].'.'.$m[2];
  if(preg_match('/Android (\d+(?:\.\d+)?)/',$ua,$m)) $os='Android '.$m[1];

  $browser='غير معروف';
  if(preg_match('/(FBAV|FBAN)/i',$ua)) $browser='Facebook';
  elseif(stripos($ua,'Instagram')!==false) $browser='Instagram';
  elseif(stripos($ua,'Snapchat')!==false) $browser='Snapchat';
  elseif(preg_match('/Edg\/([\d.]+)/',$ua,$m)) $browser='Edge '.explode('.',$m[1])[0];
  elseif(preg_match('/OPR\/([\d.]+)/',$ua,$m)) $browser='Opera '.explode('.',$m[1])[0];
  elseif(preg_match('/Chrome\/([\d.]+)/',$ua,$m) && stripos($ua,'Chromium')===false) $browser='Chrome '.explode('.',$m[1])[0];
  elseif(preg_match('/Version\/([\d.]+).*Safari/',$ua,$m)) $browser='Safari '.explode('.',$m[1])[0];
  elseif(preg_match('/Firefox\/([\d.]+)/',$ua,$m)) $browser='Firefox '.explode('.',$m[1])[0];
  return ['os'=>$os,'device'=>$device,'browser'=>$browser,'type'=>$type];
}

/* ============ تحديد موديل الهاتف بدقة ============
 * المصادر بالترتيب: تلميحات العميل (Sec-CH-UA-Model / JS)، ثم كود الجهاز داخل الـ User-Agent،
 * ثم استنتاج موديل آيفون/آيباد من مقاس الشاشة. النتيجة اسم تجاري مفهوم + الكود الأصلي.
 */
function device_brand_of($code){
  $c=strtoupper((string)$code);
  $map=[
    'SM-'=>'Samsung','GT-'=>'Samsung','SAMSUNG'=>'Samsung','REDMI'=>'Xiaomi','POCO'=>'Xiaomi','XIAOMI'=>'Xiaomi','MI '=>'Xiaomi','M20'=>'Xiaomi','M21'=>'Xiaomi','M22'=>'Xiaomi',
    '23'=>'','CPH'=>'OPPO','OPPO'=>'OPPO','PE'=>'','RMX'=>'realme','REALME'=>'realme','VIVO'=>'vivo','V21'=>'vivo','V22'=>'vivo',
    'INFINIX'=>'Infinix','TECNO'=>'Tecno','ITEL'=>'itel','PIXEL'=>'Google','NEXUS'=>'Google','HUAWEI'=>'Huawei','HONOR'=>'Honor','NOKIA'=>'Nokia','MOTO'=>'Motorola','LENOVO'=>'Lenovo','ONEPLUS'=>'OnePlus','IN20'=>'OnePlus','LE2'=>'OnePlus','ZTE'=>'ZTE','ASUS'=>'Asus','SONY'=>'Sony','XQ-'=>'Sony','LG-'=>'LG','IPHONE'=>'Apple','IPAD'=>'Apple','MAC'=>'Apple',
  ];
  foreach($map as $k=>$v){ if($v!=='' && strpos($c,$k)===0) return $v; }
  foreach($map as $k=>$v){ if($v!=='' && strpos($c,$k)!==false) return $v; }
  return '';
}

function device_model_catalog(){
  // أكواد شائعة ↔ الاسم التجاري
  return [
    // Samsung
    'SM-S928'=>'Galaxy S24 Ultra','SM-S926'=>'Galaxy S24+','SM-S921'=>'Galaxy S24',
    'SM-S918'=>'Galaxy S23 Ultra','SM-S916'=>'Galaxy S23+','SM-S911'=>'Galaxy S23',
    'SM-S908'=>'Galaxy S22 Ultra','SM-S906'=>'Galaxy S22+','SM-S901'=>'Galaxy S22',
    'SM-G998'=>'Galaxy S21 Ultra','SM-G996'=>'Galaxy S21+','SM-G991'=>'Galaxy S21',
    'SM-G988'=>'Galaxy S20 Ultra','SM-G985'=>'Galaxy S20+','SM-G980'=>'Galaxy S20',
    'SM-G973'=>'Galaxy S10','SM-G975'=>'Galaxy S10+','SM-G960'=>'Galaxy S9','SM-G965'=>'Galaxy S9+',
    'SM-N986'=>'Galaxy Note 20 Ultra','SM-N981'=>'Galaxy Note 20','SM-N975'=>'Galaxy Note 10+','SM-N970'=>'Galaxy Note 10',
    'SM-F946'=>'Galaxy Z Fold 5','SM-F936'=>'Galaxy Z Fold 4','SM-F731'=>'Galaxy Z Flip 5','SM-F721'=>'Galaxy Z Flip 4',
    'SM-A556'=>'Galaxy A55','SM-A546'=>'Galaxy A54','SM-A536'=>'Galaxy A53','SM-A528'=>'Galaxy A52s','SM-A525'=>'Galaxy A52',
    'SM-A346'=>'Galaxy A34','SM-A336'=>'Galaxy A33','SM-A325'=>'Galaxy A32','SM-A245'=>'Galaxy A24','SM-A235'=>'Galaxy A23',
    'SM-A226'=>'Galaxy A22 5G','SM-A225'=>'Galaxy A22','SM-A217'=>'Galaxy A21s','SM-A155'=>'Galaxy A15','SM-A145'=>'Galaxy A14','SM-A135'=>'Galaxy A13','SM-A127'=>'Galaxy A12','SM-A057'=>'Galaxy A05s','SM-A045'=>'Galaxy A04',
    'SM-M325'=>'Galaxy M32','SM-M215'=>'Galaxy M21','SM-M127'=>'Galaxy M12',
    // Xiaomi / Redmi / POCO
    '2201116'=>'Redmi Note 11 Pro','21091116'=>'Redmi Note 11','M2101K6'=>'Redmi Note 10 Pro','M2103K19'=>'Redmi Note 10 5G',
    'M2007J3S'=>'Redmi Note 9 Pro','M2010J19'=>'Redmi 9T','23021RAA2Y'=>'Redmi 12C','22120RN86'=>'Redmi 12',
    '2211133'=>'Xiaomi 13 Pro','2210132'=>'Xiaomi 12T','2201123'=>'Xiaomi 12','M2102K1'=>'Xiaomi Mi 11',
    '22041219'=>'POCO M4 5G','21061119'=>'POCO M3 Pro','M2004J19'=>'POCO M2',
    // Google
    'PIXEL 8'=>'Google Pixel 8','PIXEL 7'=>'Google Pixel 7','PIXEL 6'=>'Google Pixel 6',
    // OnePlus
    'CPH2451'=>'OnePlus 11','CPH2413'=>'OnePlus 10 Pro','LE2123'=>'OnePlus 9 Pro','IN2023'=>'OnePlus 8 Pro',
  ];
}

function device_model_pretty($code){
  $code=trim(preg_replace('/\s+/',' ',(string)$code));
  if($code==='') return '';
  $u=strtoupper($code);
  foreach(device_model_catalog() as $k=>$name){ if(strpos($u,strtoupper($k))===0) return $name; }
  return $code;
}

function apple_model_from_screen($screen,$dpr,$isTablet=false){
  $parts=explode('x',strtolower((string)$screen));
  if(count($parts)!==2) return '';
  $w=(int)$parts[0]; $h=(int)$parts[1]; $d=(float)$dpr;
  if($w<=0||$h<=0) return '';
  if($w>$h){ $t=$w; $w=$h; $h=$t; }
  $key=$w.'x'.$h.'@'.rtrim(rtrim(number_format($d,1,'.',''),'0'),'.');
  $iphone=[
    '440x956@3'=>'iPhone 16 Pro Max','402x874@3'=>'iPhone 16 Pro','430x932@3'=>'iPhone 15 Pro Max / 14 Pro Max',
    '393x852@3'=>'iPhone 15 Pro / 14 Pro','428x926@3'=>'iPhone 13 Pro Max / 12 Pro Max','390x844@3'=>'iPhone 14 / 13 / 12',
    '375x812@3'=>'iPhone 13 mini / X / XS / 11 Pro','414x896@3'=>'iPhone XS Max / 11 Pro Max','414x896@2'=>'iPhone XR / 11',
    '414x736@3'=>'iPhone 8 Plus / 7 Plus','375x667@2'=>'iPhone SE / 8 / 7','320x568@2'=>'iPhone SE (الجيل الأول) / 5s',
  ];
  $ipad=['1024x1366@2'=>'iPad Pro 12.9"','834x1194@2'=>'iPad Pro 11"','820x1180@2'=>'iPad Air','810x1080@2'=>'iPad (10.2")','768x1024@2'=>'iPad / iPad mini'];
  $table=$isTablet?$ipad:$iphone;
  if(isset($table[$key])) return $table[$key];
  foreach($table as $k=>$v){ if(strpos($k,$w.'x'.$h.'@')===0) return $v; }
  return '';
}

/** يرجّع ['model'=>اسم تجاري,'code'=>الكود الخام,'brand'=>الماركة] */
function detect_device_model($ua,array $hints=[]){
  $code=trim((string)($hints['model']??''));
  if($code==='') $code=trim((string)($_SERVER['HTTP_SEC_CH_UA_MODEL']??''),"\" \t\n");
  $l=strtolower((string)$ua);
  if($code===''){
    if(preg_match('/android[^;\)]*;\s*([^;\)]+?)\s*(?:build\/|\))/i',$ua,$m)){
      $cand=trim($m[1]);
      if($cand!=='' && !preg_match('/^(wv|k|mobile|tablet|[a-z]{2}-[a-z]{2})$/i',$cand)) $code=$cand;
    }
  }
  if($code===''){
    if(strpos($l,'iphone')!==false) $code='iPhone';
    elseif(strpos($l,'ipad')!==false) $code='iPad';
  }
  $model=device_model_pretty($code);
  // آيفون/آيباد: التلميحات لا تكشف الموديل، نستنتجه من مقاس الشاشة
  if(preg_match('/^(iphone|ipad)$/i',$code)){
    $guess=apple_model_from_screen($hints['screen']??'',$hints['dpr']??0,strtolower($code)==='ipad');
    if($guess!=='') $model=$guess;
  }
  $brand=device_brand_of($code!==''?$code:$model);
  if($brand==='' && $model!==''){
    foreach(['Galaxy'=>'Samsung','Redmi'=>'Xiaomi','POCO'=>'Xiaomi','Pixel'=>'Google','iPhone'=>'Apple','iPad'=>'Apple','OnePlus'=>'OnePlus'] as $k=>$v){ if(stripos($model,$k)!==false){ $brand=$v; break; } }
  }
  return ['model'=>mb_substr($model,0,120),'code'=>mb_substr($code,0,80),'brand'=>mb_substr($brand,0,60)];
}

function geo_lookup($ip){
  if($ip==='' || !filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) return [];
  $url='http://ip-api.com/json/'.rawurlencode($ip).'?fields=status,country,regionName,city,lat,lon,isp,proxy,hosting&lang=ar';
  $raw=false;
  if(function_exists('curl_init')){
    $c=curl_init($url);
    curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>4,CURLOPT_CONNECTTIMEOUT=>3]);
    $raw=curl_exec($c); curl_close($c);
  }
  if($raw===false || $raw===''){
    $ctx=stream_context_create(['http'=>['timeout'=>4]]);
    $raw=@file_get_contents($url,false,$ctx);
  }
  if(!$raw) return [];
  $d=json_decode($raw,true);
  if(!is_array($d) || ($d['status']??'')!=='success') return [];
  return [
    'country'=>(string)($d['country']??''),
    'region'=>(string)($d['regionName']??''),
    'city'=>(string)($d['city']??''),
    'isp'=>(string)($d['isp']??''),
    'lat'=>isset($d['lat'])?(float)$d['lat']:null,
    'lon'=>isset($d['lon'])?(float)$d['lon']:null,
    'is_proxy'=>(!empty($d['proxy'])||!empty($d['hosting']))?1:0,
  ];
}

function save_message_meta($pdo,$messageId){
  if($messageId<=0) return;
  $ip=client_ip();
  $ua=mb_substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,400);
  $p=parse_ua($ua);
  $g=geo_lookup($ip);
  $ref=mb_substr(trim((string)($_POST['meta_ref']??($_SERVER['HTTP_REFERER']??''))),0,255);
  $screen=mb_substr((string)($_POST['meta_screen']??''),0,20);
  $dm=detect_device_model($ua,[
    'model'=>mb_substr((string)($_POST['meta_model']??''),0,80),
    'screen'=>$screen,
    'dpr'=>(float)($_POST['meta_dpr']??0),
  ]);
  $st=$pdo->prepare('INSERT INTO message_meta(message_id,ip,user_agent,device,os,browser,device_type,country,city,region,isp,lat,lon,lang,timezone,screen,referrer,time_on_page,is_proxy,precise_lat,precise_lon,precise_acc,device_model,device_brand,device_code) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  $st->execute([
    $messageId,$ip,$ua,$p['device'],$p['os'],$p['browser'],$p['type'],
    $g['country']??null,$g['city']??null,$g['region']??null,$g['isp']??null,$g['lat']??null,$g['lon']??null,
    mb_substr((string)($_POST['meta_lang']??($_SERVER['HTTP_ACCEPT_LANGUAGE']??'')),0,60),
    mb_substr((string)($_POST['meta_tz']??''),0,60),
    mb_substr((string)($_POST['meta_screen']??''),0,20),
    $ref,
    max(0,min(86400,(int)($_POST['meta_time']??0))),
    $g['is_proxy']??null,
    is_numeric($_POST['meta_lat']??'')?(float)$_POST['meta_lat']:null,
    is_numeric($_POST['meta_lon']??'')?(float)$_POST['meta_lon']:null,
    is_numeric($_POST['meta_acc']??'')?max(0,min(99999,(int)$_POST['meta_acc'])):null,
    $dm['model']!==''?$dm['model']:null,
    $dm['brand']!==''?$dm['brand']:null,
    $dm['code']!==''?$dm['code']:null,
  ]);
}

function load_meta($pdo,array $ids){
  $ids=array_values(array_filter(array_map('intval',$ids)));
  if(!$ids) return [];
  $in=implode(',',array_fill(0,count($ids),'?'));
  $s=$pdo->prepare("SELECT * FROM message_meta WHERE message_id IN ($in)");
  $s->execute($ids);
  $out=[];
  foreach($s->fetchAll() as $r) $out[(int)$r['message_id']]=$r;
  return $out;
}

function human_duration($sec){
  $sec=(int)$sec;
  if($sec<=0) return '—';
  if($sec<60) return ar_num($sec).' ثانية';
  $m=intdiv($sec,60); $s=$sec%60;
  return ar_num($m).' دقيقة'.($s?' و'.ar_num($s).' ثانية':'');
}

function insights_html($m){
  $place=trim(implode('، ',array_filter([$m['city']??'',$m['region']??'',$m['country']??''])));
  // موديل الهاتف: نعيد الاستنتاج من الـ User-Agent للرسائل القديمة المحفوظة قبل هذه الميزة
  $model=trim((string)($m['device_model']??''));
  $brand=trim((string)($m['device_brand']??''));
  $code=trim((string)($m['device_code']??''));
  if($model===''){
    $d=detect_device_model($m['user_agent']??'',['screen'=>$m['screen']??'']);
    $model=$d['model']; $brand=$brand?:$d['brand']; $code=$code?:$d['code'];
  }
  $modelTxt=$model!==''?e(trim(($brand && stripos($model,$brand)===false ? $brand.' ' : '').$model)):'غير معروف';
  if($code!=='' && strcasecmp($code,$model)!==0) $modelTxt.=' <small class="muted" dir="ltr">('.e($code).')</small>';
  $rows=[
    ['globe','عنوان IP','<span dir="ltr" class="mono">'.e($m['ip']?:'غير متاح').'</span>'],
    ['phone','موديل الهاتف',$modelTxt],
    ['phone','الجهاز',e(($m['device']?:'غير معروف').' — '.($m['device_type']?:''))],
    ['settings','النظام والمتصفح',e(trim(($m['os']?:'').' · '.($m['browser']?:'')))],
    ['pin','الموقع التقريبي',$place!==''?e($place):'غير متاح'],
    ['wifi','مزود الخدمة',e($m['isp']?:'غير متاح').(!empty($m['is_proxy'])?' <span class="tag red">VPN/بروكسي</span>':'')],
    ['clock','مدة الجلسة قبل الإرسال',human_duration($m['time_on_page']??0)],
    ['globe','المنطقة الزمنية واللغة',e(trim(($m['timezone']?:'—').' · '.($m['lang']?:'—')))],
    ['monitor','مقاس الشاشة','<span dir="ltr" class="mono">'.e($m['screen']?:'—').'</span>'],
    ['link','مصدر الزيارة',e($m['referrer']?:'مباشر')],
  ];
  $h='<details class="insights"><summary class="insights-sum">💎 تحليل المرسل</summary><div class="insights-grid">';
  foreach($rows as $r) $h.='<div class="ins-item"><span class="ins-k">'.e($r[1]).'</span><span class="ins-v">'.$r[2].'</span></div>';
  if(!empty($m['precise_lat'])&&!empty($m['precise_lon'])){
    $h.='<div class="ins-item ins-wide"><span class="ins-k">📍 الموقع الدقيق (بإذن المرسل)</span><span class="ins-v"><a dir="ltr" target="_blank" rel="noopener" href="https://www.google.com/maps?q='.e($m['precise_lat']).','.e($m['precise_lon']).'">'.e($m['precise_lat']).', '.e($m['precise_lon']).'</a>'.(!empty($m['precise_acc'])?' <small class="muted">دقة ~'.e($m['precise_acc']).' م</small>':'').'</span></div>';
  }
  if(!empty($m['lat'])&&!empty($m['lon'])){
    $h.='<div class="ins-item ins-wide"><span class="ins-k">الخريطة</span><span class="ins-v"><a dir="ltr" target="_blank" rel="noopener" href="https://www.google.com/maps?q='.e($m['lat']).','.e($m['lon']).'">'.e($m['lat']).', '.e($m['lon']).'</a></span></div>';
  }
  $h.='</div><p class="ins-note">الموقع تقريبي بحسب عنوان الإنترنت وقد يختلف عن الموقع الفعلي.</p></details>';
  return $h;
}

function insights_locked_html(){
  return '<div class="insights-locked">🔒 <b>تحليل المرسل</b> — ميزة مدفوعة تكشف عنوان IP ونوع الجهاز والموقع التقريبي وتفاصيل الجلسة. تواصل مع الإدارة لتفعيلها على حسابك.</div>';
}
