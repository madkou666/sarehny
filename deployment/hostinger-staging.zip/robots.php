<?php require 'inc.php';
header('Content-Type: text/plain; charset=utf-8');
$b=base_url();
if(setting('seo_index','1')!=='1'){ echo "User-agent: *\nDisallow: /\n"; exit; }
echo "User-agent: *\nAllow: /\nDisallow: /admin.php\nDisallow: /admin_parts/\nDisallow: /install.php\nDisallow: /dashboard.php\nDisallow: /account.php\nDisallow: /logout.php\nDisallow: /oauth.php\nDisallow: /uploads/\n\nSitemap: $b/sitemap.xml\n";
