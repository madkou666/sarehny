<?php
// نقطة اتصال الدعم الفني المباشر (JSON) — للزوار ولوحة التحكم
require __DIR__.'/inc.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function sj($d,$code=200){ http_response_code($code); echo json_encode($d,JSON_UNESCAPED_UNICODE); exit; }
function sup_csrf(){ $t=(string)($_SERVER['HTTP_X_CSRF']??($_POST['csrf']??'')); if(!hash_equals(csrf(),$t)) sj(['ok'=>false,'error'=>'انتهت الجلسة، أعد تحميل الصفحة'],400); }
function sup_token(){
  $t=(string)($_COOKIE['sup_t']??'');
  if(!preg_match('/^[a-f0-9]{48}$/',$t)){
    $t=bin2hex(random_bytes(24));
    setcookie('sup_t',$t,['expires'=>time()+86400*60,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]);
    $_COOKIE['sup_t']=$t;
  }
  return $t;
}
function sup_msgs($tid,$after){
  global $pdo;
  $s=$pdo->prepare('SELECT id,sender,body,created_at FROM support_messages WHERE thread_id=? AND id>? ORDER BY id ASC LIMIT 200');
  $s->execute([$tid,$after]); return $s->fetchAll();
}

if(setting('support_enabled','1')!=='1' && empty(me()['is_admin'])) sj(['ok'=>false,'error'=>'الدعم الفني غير متاح حاليًا'],403);

$a=(string)($_REQUEST['a']??'');
$after=max(0,(int)($_REQUEST['after']??0));
$u=me();

/* ===================== أوامر لوحة التحكم ===================== */
if(strpos($a,'admin_')===0){
  if(!$u || empty($u['is_admin'])) sj(['ok'=>false,'error'=>'غير مصرح'],403);
  if($a==='admin_threads'){
    $f=(string)($_GET['f']??'open');
    $where=$f==='closed'?"WHERE status='closed'":($f==='all'?'':"WHERE status='open'");
    $rows=$pdo->query("SELECT t.id,t.name,t.email,t.status,t.unread_admin,t.last_at,t.user_id,u.username,(SELECT body FROM support_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_body FROM support_threads t LEFT JOIN users u ON u.id=t.user_id $where ORDER BY t.last_at DESC LIMIT 200")->fetchAll();
    $unread=(int)$pdo->query("SELECT COALESCE(SUM(unread_admin),0) FROM support_threads WHERE status='open'")->fetchColumn();
    sj(['ok'=>true,'threads'=>$rows,'unread'=>$unread]);
  }
  $id=(int)($_REQUEST['id']??0);
  $s=$pdo->prepare('SELECT t.*,u.username FROM support_threads t LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?'); $s->execute([$id]); $th=$s->fetch();
  if(!$th) sj(['ok'=>false,'error'=>'المحادثة غير موجودة'],404);
  if($a==='admin_thread'){
    $pdo->prepare('UPDATE support_threads SET unread_admin=0 WHERE id=?')->execute([$id]);
    unset($th['token']);
    sj(['ok'=>true,'thread'=>$th,'messages'=>sup_msgs($id,$after)]);
  }
  if($_SERVER['REQUEST_METHOD']!=='POST') sj(['ok'=>false],405);
  sup_csrf();
  if($a==='admin_reply'){
    $body=mb_substr(trim((string)($_POST['body']??'')),0,2000);
    if($body==='') sj(['ok'=>false,'error'=>'اكتب الرد أولًا'],422);
    $pdo->prepare("INSERT INTO support_messages(thread_id,sender,admin_id,body) VALUES(?,'admin',?,?)")->execute([$id,$u['id'],$body]);
    $pdo->prepare("UPDATE support_threads SET last_at=NOW(),unread_user=unread_user+1,unread_admin=0,status='open' WHERE id=?")->execute([$id]);
    sj(['ok'=>true,'messages'=>sup_msgs($id,$after)]);
  }
  if($a==='admin_close'||$a==='admin_open'){
    $pdo->prepare('UPDATE support_threads SET status=? WHERE id=?')->execute([$a==='admin_close'?'closed':'open',$id]);
    log_action('support.'.($a==='admin_close'?'close':'open'),'محادثة #'.$id); sj(['ok'=>true]);
  }
  if($a==='admin_delete'){
    $pdo->prepare('DELETE FROM support_messages WHERE thread_id=?')->execute([$id]);
    $pdo->prepare('DELETE FROM support_threads WHERE id=?')->execute([$id]);
    log_action('support.delete','محادثة #'.$id); sj(['ok'=>true]);
  }
  sj(['ok'=>false,'error'=>'أمر غير معروف'],400);
}

/* ===================== أوامر الزائر ===================== */
$token=hash('sha256',sup_token());
$s=$pdo->prepare('SELECT * FROM support_threads WHERE token=?'); $s->execute([$token]); $th=$s->fetch();

if($a==='poll'){
  if(!$th) sj(['ok'=>true,'messages'=>[],'status'=>'none','need_name'=>!$u]);
  if($th['unread_user']) $pdo->prepare('UPDATE support_threads SET unread_user=0 WHERE id=?')->execute([$th['id']]);
  sj(['ok'=>true,'messages'=>sup_msgs($th['id'],$after),'status'=>$th['status'],'need_name'=>false]);
}

if($a==='send' && $_SERVER['REQUEST_METHOD']==='POST'){
  sup_csrf();
  $body=mb_substr(trim((string)($_POST['body']??'')),0,2000);
  if($body==='') sj(['ok'=>false,'error'=>'اكتب رسالتك أولًا'],422);
  if(!$th){
    $name=$u?$u['display_name']:mb_substr(trim((string)($_POST['name']??'')),0,80);
    $email=$u?($u['email']??''):mb_substr(strtolower(trim((string)($_POST['email']??''))),0,190);
    if($name==='') sj(['ok'=>false,'error'=>'اكتب اسمك'],422);
    if($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) sj(['ok'=>false,'error'=>'البريد الإلكتروني غير صحيح'],422);
    $pdo->prepare('INSERT INTO support_threads(token,user_id,name,email,ip_hash) VALUES(?,?,?,?,?)')->execute([$token,$u['id']??null,$name,$email,sender_hash()]);
    $s->execute([$token]); $th=$s->fetch();
  }
  // حد الإرسال: ١٥ رسالة كل ٥ دقائق
  $c=$pdo->prepare("SELECT COUNT(*) FROM support_messages WHERE thread_id=? AND sender='user' AND created_at>NOW()-INTERVAL 5 MINUTE"); $c->execute([$th['id']]);
  if((int)$c->fetchColumn()>=15) sj(['ok'=>false,'error'=>'أرسلت رسائل كثيرة، انتظر قليلًا'],429);
  $pdo->prepare("INSERT INTO support_messages(thread_id,sender,body) VALUES(?,'user',?)")->execute([$th['id'],$body]);
  $pdo->prepare("UPDATE support_threads SET last_at=NOW(),unread_admin=unread_admin+1,status='open' WHERE id=?")->execute([$th['id']]);
  sj(['ok'=>true,'messages'=>sup_msgs($th['id'],$after),'status'=>'open']);
}

sj(['ok'=>false,'error'=>'أمر غير معروف'],400);
