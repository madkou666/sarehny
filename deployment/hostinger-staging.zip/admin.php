<?php require 'inc.php'; $me=require_admin();require_once __DIR__.'/social_lab.php';
if($_SERVER['REQUEST_METHOD']==='POST'&&($_GET['t']??'')==='ai'&&in_array(($_POST['action']??''),['test','save'],true)){require __DIR__.'/ai_admin.php';exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&($_GET['t']??'')==='social'){social_lab_schema();social_lab_admin_post($me);}
require_once __DIR__.'/admin_backup.php';
define('IN_ADMIN', true);

$sections=[
  'overview'=>['نظرة عامة','chart','عام'],
  'users'=>['المستخدمون','users','الإدارة'],
  'messages'=>['الرسائل','message','الإدارة'],
  'reports'=>['البلاغات','flag','الإدارة'],
  'words'=>['فلتر الكلمات','filter','الحماية'],
  'bans'=>['المرسلون المحظورون','ban','الحماية'],
  'announce'=>['الإعلانات','megaphone','الموقع'],
  'homepage'=>['الرئيسية','grid','المحتوى'],
  'blog'=>['المدونة','edit','المحتوى'],
  'about'=>['حول أسرار','info','المحتوى'],
  'contact'=>['اتصل بنا','message','المحتوى'],
  'support'=>['الدعم الفني المباشر','message','الإدارة'],
  'themes'=>['القوالب والمظهر','grid','الموقع'],
  'identity'=>['الشعار والهوية','edit','الموقع'],
  'notify'=>['الإشعارات','megaphone','الموقع'],
  'settings'=>['الإعدادات','settings','الموقع'],
  'ai'=>['مزودو الذكاء الاصطناعي','activity','النظام'],
  'social'=>['المختبر الاجتماعي AI','activity','النظام'],
  'logs'=>['سجل النشاط','activity','النظام'],
  'tools'=>['التصدير والنسخ','database','النظام'],
  'system'=>['معلومات النظام','activity','النظام'],
];
$tab=(string)($_GET['t']??'overview'); if(!isset($sections[$tab])) $tab='overview';
$q=mb_substr(trim((string)($_GET['q']??'')),0,160); $f=(string)($_GET['f']??''); $page=max(1,(int)($_GET['p']??1));
$reasons=['harassment'=>'تحرش أو إساءة','threat'=>'تهديد','spam'=>'إزعاج','other'=>'أخرى'];
$actionLabels=[
  'user.admin'=>'ترقية لمدير','user.unadmin'=>'سحب صلاحية الإدارة','user.disable'=>'تعطيل حساب','user.enable'=>'تفعيل حساب',
  'user.edit'=>'تعديل بيانات مستخدم','user.delete'=>'حذف مستخدم','msg.hide'=>'إخفاء رسالة','msg.restore'=>'استعادة رسالة',
  'msg.delete'=>'حذف رسالة','msg.bulk'=>'إجراء جماعي على الرسائل','report.dismiss'=>'رفض بلاغ','report.remove'=>'قبول بلاغ وإخفاء الرسالة',
  'report.purge'=>'تنظيف البلاغات المغلقة','word.add'=>'إضافة كلمات محظورة','word.delete'=>'حذف كلمة محظورة',
  'ban.add'=>'حظر مرسل','ban.remove'=>'رفع حظر مرسل','announce.save'=>'تحديث الإعلان','settings.save'=>'تحديث الإعدادات',
  'homepage.save'=>'تعديل الرئيسية','about.save'=>'تعديل صفحة حول','blog.save'=>'حفظ مقال','blog.delete'=>'حذف مقال','contact.read'=>'قراءة رسالة تواصل','contact.delete'=>'حذف رسالة تواصل',
      'logs.clear'=>'مسح سجل النشاط','export'=>'تصدير بيانات','backup'=>'نسخة احتياطية','purge.hidden'=>'حذف الرسائل المخفية','theme.apply'=>'تطبيق قالب','logo.save'=>'تغيير الشعار','logo.remove'=>'حذف الشعار','identity.save'=>'تحديث الهوية','notify.save'=>'إعدادات الإشعارات','notify.broadcast'=>'إشعار جماعي','appearance.save'=>'تحديث المظهر','db.optimize'=>'تحسين قاعدة البيانات','logs.purgeold'=>'حذف السجل القديم','users.purgedisabled'=>'حذف الحسابات المعطّلة','reserved.save'=>'تحديث الأسماء المحجوزة','report.bulk'=>'مراجعة جماعية للبلاغات',
];

function admin_url(array $params){ $p=array_filter($params,fn($v)=>$v!==''&&$v!==null&&$v!==0); return 'admin.php'.($p?'?'.http_build_query($p):''); }
function pager($total,$per,$page,array $base){
  $pages=(int)ceil($total/$per); if($pages<=1) return '';
  $h='<nav class="pager" aria-label="التنقل بين الصفحات"><span class="pager-info">صفحة '.ar_num($page).' من '.ar_num($pages).'</span><div class="pager-btns">';
  if($page>1) $h.='<a class="btn xs ghost" href="'.e(admin_url($base+['p'=>$page-1])).'">السابق</a>';
  $start=max(1,$page-2); $end=min($pages,$page+2);
  for($i=$start;$i<=$end;$i++) $h.='<a class="pg'.($i===$page?' on':'').'" href="'.e(admin_url($base+['p'=>$i])).'"'.($i===$page?' aria-current="page"':'').'>'.ar_num($i).'</a>';
  if($page<$pages) $h.='<a class="btn xs ghost" href="'.e(admin_url($base+['p'=>$page+1])).'">التالي</a>';
  return $h.'</div></nav>';
}
function csv_cell($v){ $v=(string)$v; return ($v!=='' && strpbrk($v[0],'=+-@')!==false) ? "'".$v : $v; }
function send_csv($name,array $head,iterable $rows){
  header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="'.$name.'-'.date('Y-m-d').'.csv"');
  $out=fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF"); fputcsv($out,$head);
  foreach($rows as $r) fputcsv($out,array_map('csv_cell',array_values($r)));
  fclose($out); exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  $a=(string)($_POST['action']??''); $id=(int)($_POST['id']??0);
  if($a==='support_toggle'){ save_setting('support_enabled',setting('support_enabled','1')==='1'?'0':'1'); log_action('support.toggle',setting('support_enabled','1')); flash('تم تحديث حالة الدعم الفني'); header('Location: admin.php?t=support'); exit; }
  $ret=admin_url(['t'=>$tab,'q'=>$q,'f'=>$f,'p'=>$page>1?$page:'']);
  $userName=function($id) use($pdo){ $s=$pdo->prepare('SELECT username FROM users WHERE id=?'); $s->execute([$id]); return '@'.($s->fetchColumn()?:$id); };

  switch($a){
    case 'admin': case 'unadmin':
      if($id==$me['id'] && $a==='unadmin'){ flash('لا يمكنك سحب صلاحيتك بنفسك','err'); break; }
      $pdo->prepare('UPDATE users SET is_admin=? WHERE id=? AND is_disabled=0')->execute([$a==='admin'?1:0,$id]);
      log_action('user.'.$a,$userName($id)); flash($a==='admin'?'تمت ترقية المستخدم إلى مدير':'تم سحب صلاحية الإدارة'); break;
    case 'disable': case 'enable':
      if($id==$me['id']){ flash('لا يمكنك تعطيل حسابك','err'); break; }
      $dis=$a==='disable'?1:0; $pdo->prepare('UPDATE users SET is_disabled=?, is_admin=IF(?,0,is_admin) WHERE id=?')->execute([$dis,$dis,$id]);
      log_action('user.'.$a,$userName($id)); flash($dis?'تم تعطيل الحساب':'تم تفعيل الحساب'); break;
    case 'insights_on': case 'insights_off':
      $days=max(0,min(3650,(int)($_POST['days']??0)));
      if($a==='insights_on') $pdo->prepare('UPDATE users SET insights_enabled=1, insights_until=? WHERE id=?')->execute([$days?date('Y-m-d H:i:s',time()+$days*86400):null,$id]);
      else $pdo->prepare('UPDATE users SET insights_enabled=0, insights_until=NULL WHERE id=?')->execute([$id]);
      log_action('user.'.$a,$userName($id).($days?" ($days يوم)":'')); flash($a==='insights_on'?'تم تفعيل ميزة تحليل المرسل لهذا المستخدم':'تم إيقاف ميزة تحليل المرسل'); break;
    case 'verify': case 'unverify':
      $pdo->prepare('UPDATE users SET is_verified=? WHERE id=?')->execute([$a==='verify'?1:0,$id]);
      log_action('user.'.$a,$userName($id)); flash($a==='verify'?'تم توثيق الحساب بالعلامة الزرقاء':'تم إلغاء توثيق الحساب'); break;
    case 'deluser':
      if($id==$me['id']){ flash('لا يمكنك حذف حسابك','err'); break; }
      $n=$userName($id); $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
      log_action('user.delete',$n); flash('تم حذف المستخدم وكل رسائله نهائيًا'); $ret=admin_url(['t'=>'users']); break;
    case 'edituser':
      $name=trim((string)($_POST['display_name']??'')); $email=strtolower(trim((string)($_POST['email']??''))); $pass=(string)($_POST['password']??'');
      $ret=admin_url(['t'=>'users','edit'=>$id]);
      if(mb_strlen($name)<2||mb_strlen($name)>80){ flash('الاسم الظاهر من ٢ إلى ٨٠ حرفًا','err'); break; }
      if(!filter_var($email,FILTER_VALIDATE_EMAIL)){ flash('البريد الإلكتروني غير صالح','err'); break; }
      if($pass!=='' && strlen($pass)<8){ flash('كلمة المرور الجديدة ٨ أحرف على الأقل','err'); break; }
      $s=$pdo->prepare('SELECT id FROM users WHERE email=? AND id<>?'); $s->execute([$email,$id]);
      if($s->fetch()){ flash('هذا البريد مستخدم لحساب آخر','err'); break; }
      $pdo->prepare('UPDATE users SET display_name=?, email=? WHERE id=?')->execute([$name,$email,$id]);
      if($pass!=='') $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pass,PASSWORD_DEFAULT),$id]);
      log_action('user.edit',$userName($id).($pass!==''?' (مع تغيير كلمة المرور)':'')); flash('تم حفظ بيانات المستخدم'); $ret=admin_url(['t'=>'users']); break;

    case 'hide': case 'restore':
      $pdo->prepare('UPDATE messages SET is_removed=? WHERE id=?')->execute([$a==='hide'?1:0,$id]);
      log_action('msg.'.$a,'#'.$id); flash($a==='hide'?'تم إخفاء الرسالة عن صاحبها':'تمت استعادة الرسالة'); break;
    case 'delmsg':
      $pdo->prepare('DELETE FROM messages WHERE id=?')->execute([$id]); log_action('msg.delete','#'.$id); flash('تم حذف الرسالة نهائيًا'); break;
    case 'bulk':
      $ids=array_slice(array_values(array_unique(array_filter(array_map('intval',(array)($_POST['ids']??[])),fn($value)=>$value>0))),0,500); $op=(string)($_POST['bulk_op']??'');
      if(!$ids || !in_array($op,['hide','restore','delete','export'],true)){ flash('اختر رسائل وإجراءً أولًا','err'); break; }
      $in=implode(',',array_fill(0,count($ids),'?'));
      if($op==='export'){
        $selected=$pdo->prepare("SELECT m.id,u.username,m.body,m.is_favorite,m.is_removed,m.created_at,(SELECT COUNT(*) FROM reports r WHERE r.message_id=m.id) FROM messages m JOIN users u ON u.id=m.recipient_id WHERE m.id IN ($in) ORDER BY m.id DESC");
        $selected->execute($ids);log_action('export','الرسائل المحددة ('.count($ids).')');
        send_csv('selected-messages',['المعرّف','اسم المستلم','نص الرسالة','مفضلة','مخفية','تاريخ الإرسال','عدد البلاغات'],$selected);
      }
      if($op==='delete') $pdo->prepare("DELETE FROM messages WHERE id IN ($in)")->execute($ids);
      else $pdo->prepare("UPDATE messages SET is_removed=? WHERE id IN ($in)")->execute(array_merge([$op==='hide'?1:0],$ids));
      log_action('msg.bulk',['hide'=>'إخفاء','restore'=>'استعادة','delete'=>'حذف'][$op].' '.count($ids).' رسالة');
      flash('تم تنفيذ الإجراء على '.ar_num(count($ids)).' رسالة'); break;
    case 'bansender':
      $s=$pdo->prepare('SELECT sender_ip_hash FROM messages WHERE id=?'); $s->execute([$id]); $h=$s->fetchColumn();
      if(!$h){ flash('لا توجد بصمة مرسل لهذه الرسالة','err'); break; }
      $note=mb_substr(trim((string)($_POST['note']??''))?:('من الرسالة #'.$id),0,190);
      $pdo->prepare('INSERT IGNORE INTO sender_bans(ip_hash,note,created_by) VALUES(?,?,?)')->execute([$h,$note,$me['id']]);
      log_action('ban.add',$note); flash('تم حظر المرسل من إرسال أي رسائل جديدة'); break;

    case 'dismiss': case 'remove':
      $s=$pdo->prepare("SELECT * FROM reports WHERE id=? AND status='pending'"); $s->execute([$id]);
      if($r=$s->fetch()){
        $pdo->prepare('UPDATE reports SET status=?,reviewed_by=?,reviewed_at=NOW() WHERE id=?')->execute([$a==='remove'?'removed':'dismissed',$me['id'],$id]);
        if($a==='remove') $pdo->prepare('UPDATE messages SET is_removed=1 WHERE id=?')->execute([$r['message_id']]);
        log_action('report.'.$a,'بلاغ #'.$id); flash($a==='remove'?'تم إخفاء الرسالة وإغلاق البلاغ':'تم رفض البلاغ');
      } break;
    case 'bulkreports':
      $reportIds=array_slice(array_values(array_unique(array_filter(array_map('intval',(array)($_POST['ids']??[])),fn($value)=>$value>0))),0,500);
      $reportOperation=(string)($_POST['bulk_op']??'');
      if(!$reportIds||!in_array($reportOperation,['dismiss','remove'],true)){flash('حدّد بلاغًا واحدًا على الأقل واختر إجراء المراجعة','err');break;}
      $pdo->beginTransaction();
      try{
        $idPlaceholders=implode(',',array_fill(0,count($reportIds),'?'));
        $pendingReports=$pdo->prepare("SELECT id,message_id FROM reports WHERE status='pending' AND id IN ($idPlaceholders) FOR UPDATE");
        $pendingReports->execute($reportIds);
        $eligibleReports=$pendingReports->fetchAll();
        $eligibleIds=array_map(fn($report)=>(int)$report['id'],$eligibleReports);
        if($eligibleIds){
          if($reportOperation==='remove'){
            $messageIds=array_values(array_unique(array_map(fn($report)=>(int)$report['message_id'],$eligibleReports)));
            $messagePlaceholders=implode(',',array_fill(0,count($messageIds),'?'));
            $pdo->prepare("UPDATE messages SET is_removed=1 WHERE id IN ($messagePlaceholders)")->execute($messageIds);
          }
          $eligiblePlaceholders=implode(',',array_fill(0,count($eligibleIds),'?'));
          $reviewReports=$pdo->prepare("UPDATE reports SET status=?,reviewed_by=?,reviewed_at=NOW() WHERE status='pending' AND id IN ($eligiblePlaceholders)");
          $reviewReports->execute(array_merge([$reportOperation==='remove'?'removed':'dismissed',$me['id']],$eligibleIds));
          $reviewedCount=$reviewReports->rowCount();
        }else $reviewedCount=0;
        $pdo->commit();
      }catch(Throwable $error){if($pdo->inTransaction())$pdo->rollBack();throw $error;}
      if($reviewedCount){
        $operationLabel=$reportOperation==='remove'?'قبول وإخفاء':'رفض';
        log_action('report.bulk',$operationLabel.' '.$reviewedCount.' بلاغ');
        flash('تمت مراجعة '.ar_num($reviewedCount).' بلاغ'.($reportOperation==='remove'?' وإخفاء الرسائل المرتبطة':'').' بنجاح');
      }else flash('لم تعد البلاغات المحددة بحاجة إلى مراجعة','err');
      break;
    case 'purgereports':
      $n=$pdo->exec("DELETE FROM reports WHERE status<>'pending'"); log_action('report.purge',$n.' بلاغ'); flash('تم حذف '.ar_num($n).' بلاغ مغلق'); break;

    case 'addwords':
      $words=array_unique(array_filter(array_map(fn($w)=>mb_substr(trim($w),0,100),preg_split('/[\n,،]+/u',(string)($_POST['words']??'')))));
      $st=$pdo->prepare('INSERT IGNORE INTO banned_words(word) VALUES(?)'); $added=0;
      foreach($words as $w){ $st->execute([mb_strtolower($w)]); $added+=$st->rowCount(); }
      if($added){ log_action('word.add',implode('، ',array_slice($words,0,8))); flash('تمت إضافة '.ar_num($added).' كلمة'); } else flash('لم تتم إضافة كلمات جديدة','err'); break;
    case 'delword':
      $s=$pdo->prepare('SELECT word FROM banned_words WHERE id=?'); $s->execute([$id]); $w=$s->fetchColumn();
      $pdo->prepare('DELETE FROM banned_words WHERE id=?')->execute([$id]); if($w) log_action('word.delete',$w); flash('تم حذف الكلمة'); break;

    case 'unban':
      $h=(string)($_POST['hash']??''); $pdo->prepare('DELETE FROM sender_bans WHERE ip_hash=?')->execute([$h]);
      log_action('ban.remove',substr($h,0,12).'…'); flash('تم رفع الحظر'); break;

    case 'saveann':
      $text=mb_substr(trim((string)($_POST['ann_text']??'')),0,300); $type=in_array($_POST['ann_type']??'',['info','success','warning'],true)?$_POST['ann_type']:'info';
      save_setting('ann_text',$text); save_setting('ann_type',$type); save_setting('ann_active',!empty($_POST['ann_active'])&&$text!==''?'1':'0');
      log_action('announce.save',$text===''?'(فارغ)':$text); flash('تم حفظ الإعلان'); break;

    case 'savesettings':
      $colors=[];
      foreach(theme_fields() as $key=>$field){
        $value=(string)($_POST['theme_'.$key]??'');
        if(!preg_match('/^#[0-9a-fA-F]{6}$/D',$value)){flash('قيمة اللون غير صالحة: '.$field[0],'err');break 2;}
        $colors[$key]=strtolower($value);
      }
      $site=mb_substr(trim((string)($_POST['site_name']??'')),0,60);
      save_setting('site_name',$site);
      foreach(['allow_register','messages_open','precise_location','maintenance'] as $k) save_setting($k,!empty($_POST[$k])?'1':'0');
      save_setting('maintenance_msg',mb_substr(trim((string)($_POST['maintenance_msg']??'')),0,300));
      save_setting('max_len',max(50,min(5000,(int)($_POST['max_len']??1000))));
      save_setting('rate_limit',max(1,min(100,(int)($_POST['rate_limit']??10))));
      foreach($colors as $key=>$value) save_setting('theme_'.$key,$value);
      foreach(array_keys(oauth_providers()) as $op){
        save_setting($op.'_enabled',!empty($_POST[$op.'_enabled'])?'1':'0');
        save_setting($op.'_client_id',mb_substr(trim((string)($_POST[$op.'_client_id']??'')),0,255));
        $sec=trim((string)($_POST[$op.'_client_secret']??''));
        if(!empty($_POST[$op.'_clear_secret'])) save_setting($op.'_client_secret','');
        elseif($sec!=='') save_setting($op.'_client_secret',mb_substr($sec,0,255));
      }
      save_setting('facebook_email_scope',!empty($_POST['facebook_email_scope'])?'1':'0');
      save_setting('gsc_verify',seo_verify_code($_POST['gsc_verify']??''));
      save_setting('bing_verify',seo_verify_code($_POST['bing_verify']??''));
      foreach(['ads_enabled','ads_hide_users'] as $k) save_setting($k,!empty($_POST[$k])?'1':'0');
      save_setting('ads_pub',mb_substr(preg_replace('/[^0-9]/','',(string)($_POST['ads_pub']??'')),0,30));
      foreach(['ads_head_code','ads_top','ads_content','ads_bottom'] as $k) save_setting($k,mb_substr(trim((string)($_POST[$k]??'')),0,8000));
      save_setting('seo_index',!empty($_POST['seo_index'])?'1':'0');
      log_action('settings.save'); flash('تم حفظ الإعدادات والألوان'); break;

    case 'savelogo':
      $f=$_FILES['logo']??null; $ret=admin_url(['t'=>'identity']);
      if(!$f||($f['error']??1)!==UPLOAD_ERR_OK){ flash('اختر صورة الشعار','err'); break; }
      if($f['size']>2*1024*1024){ flash('أقصى حجم للشعار ٢ ميجابايت','err'); break; }
      $info=@getimagesize($f['tmp_name']); $types=[IMAGETYPE_PNG=>'png',IMAGETYPE_JPEG=>'jpg',IMAGETYPE_WEBP=>'webp'];
      if(!$info||!isset($types[$info[2]])){ flash('الصيغ المسموحة: PNG أو JPG أو WEBP','err'); break; }
      $name='logo-'.bin2hex(random_bytes(8)).'.'.$types[$info[2]];
      if(!@move_uploaded_file($f['tmp_name'],__DIR__.'/uploads/'.$name)){ flash('تعذّر حفظ الملف، تحقق من صلاحيات مجلد uploads','err'); break; }
      if(($old=logo_url())!=='') @unlink(__DIR__.'/'.$old);
      save_setting('site_logo',$name); log_action('logo.save'); flash('تم تغيير الشعار'); break;
    case 'removelogo':
      if(($old=logo_url())!=='') @unlink(__DIR__.'/'.$old); save_setting('site_logo','');
      log_action('logo.remove'); flash('تم حذف الشعار والعودة للشعار الافتراضي'); $ret=admin_url(['t'=>'identity']); break;
    case 'saveidentity':
      save_setting('logo_height',max(20,min(64,(int)($_POST['logo_height']??34))));
      save_setting('logo_hide_name',!empty($_POST['logo_hide_name'])?'1':'0');
      save_setting('site_description',mb_substr(trim((string)($_POST['site_description']??'')),0,300));
      foreach(array_keys(social_links()) as $k){ $v=trim((string)($_POST['social_'.$k]??'')); if($v!=='' && !preg_match('#^https://#',$v)) $v=preg_replace('/[^A-Za-z0-9_.@-]/','',$v); save_setting('social_'.$k,mb_substr($v,0,200)); }
      log_action('identity.save'); flash('تم حفظ الهوية'); $ret=admin_url(['t'=>'identity']); break;
    case 'savenotify':
      save_setting('push_preview',!empty($_POST['push_preview'])?'1':'0');
      log_action('notify.save'); flash('تم حفظ إعدادات الإشعارات'); $ret=admin_url(['t'=>'notify']); break;
    case 'broadcast':
      require_once __DIR__.'/push_lib.php'; $ret=admin_url(['t'=>'notify']);
      $tt=mb_substr(trim((string)($_POST['title']??'')),0,60); $bb=mb_substr(trim((string)($_POST['body']??'')),0,180);
      if($tt===''||$bb===''){ flash('اكتب عنوانًا ونصًا للإشعار','err'); break; }
      @set_time_limit(300); $n=0; foreach($pdo->query('SELECT DISTINCT user_id FROM push_subs')->fetchAll(PDO::FETCH_COLUMN) as $uid) $n+=push_notify_user((int)$uid,$tt,$bb,'index.php');
      log_action('notify.broadcast',$tt.' ('.$n.' جهاز)'); flash('تم إرسال الإشعار إلى '.ar_num($n).' جهاز'); break;
    case 'applytheme':
      $pk=(string)($_POST['preset']??''); $ps=admin_theme_presets();
      if(!isset($ps[$pk])){ flash('قالب غير معروف','err'); break; }
      foreach($ps[$pk][1] as $k=>$v) save_setting('theme_'.$k,$v);
      log_action('theme.apply',$ps[$pk][0]); flash('تم تطبيق قالب «'.$ps[$pk][0].'»'); break;
    case 'saveappearance':
      $font=(string)($_POST['site_font']??'Cairo'); save_setting('site_font',isset(font_options()[$font])?$font:'Cairo');
      save_setting('ui_radius',max(0,min(24,(int)($_POST['ui_radius']??8))));
      save_setting('theme_switcher',!empty($_POST['theme_switcher'])?'1':'0');
      foreach(['custom_css','custom_head','custom_footer'] as $k) save_setting($k,mb_substr((string)($_POST[$k]??''),0,20000));
      log_action('appearance.save'); flash('تم حفظ المظهر'); break;
    case 'optimizedb':
      foreach(['users','messages','reports','settings','banned_words','sender_bans','admin_logs','blog_posts','contact_messages'] as $t){ try{ $pdo->query("OPTIMIZE TABLE `$t`")->fetchAll(); }catch(Throwable $ex){} }
      log_action('db.optimize'); flash('تم تحسين الجداول'); break;
    case 'purgelogsold':
      $n=$pdo->exec('DELETE FROM admin_logs WHERE created_at < (NOW() - INTERVAL 90 DAY)'); log_action('logs.purgeold',$n.' سجل'); flash('تم حذف '.ar_num($n).' سجل قديم'); break;
    case 'purgedisabled':
      $n=$pdo->prepare('DELETE FROM users WHERE is_disabled=1 AND is_admin=0 AND id<>?'); $n->execute([$me['id']]); $n=$n->rowCount();
      log_action('users.purgedisabled',$n.' حساب'); flash('تم حذف '.ar_num($n).' حساب معطّل'); break;
    case 'savereserved':
      $list=array_unique(array_filter(array_map(fn($x)=>preg_replace('/[^a-z0-9_]/','',strtolower(trim($x))),explode("\n",(string)($_POST['reserved_usernames']??'')))));
      save_setting('reserved_usernames',implode("\n",array_slice($list,0,500))); log_action('reserved.save',count($list).' اسم'); flash('تم حفظ الأسماء المحجوزة'); break;

    case 'savehomepage':
      foreach(['home_title'=>180,'home_lead'=>500] as $key=>$limit) save_setting($key,mb_substr(trim((string)($_POST[$key]??'')),0,$limit));
      log_action('homepage.save'); flash('تم حفظ محتوى الرئيسية'); $ret=admin_url(['t'=>'homepage']); break;
    case 'saveabout':
      foreach(['about_title'=>180,'about_intro'=>600,'about_body'=>8000] as $key=>$limit) save_setting($key,mb_substr(trim((string)($_POST[$key]??'')),0,$limit));
      log_action('about.save'); flash('تم حفظ صفحة حول أسرار'); $ret=admin_url(['t'=>'about']); break;
    case 'saveblog':
      $title=mb_substr(trim((string)($_POST['title']??'')),0,180);
      $excerpt=mb_substr(trim((string)($_POST['excerpt']??'')),0,320);
      $body=mb_substr(trim((string)($_POST['body']??'')),0,60000);
      $ret=admin_url(['t'=>'blog','edit'=>$id]);
      if(mb_strlen($title)<3||mb_strlen($body)<20){ flash('اكتب عنوانًا من ٣ أحرف ومحتوى من ٢٠ حرفًا على الأقل','err'); break; }
      $published=!empty($_POST['published'])?1:0;
      if($id>0){
        $s=$pdo->prepare('UPDATE blog_posts SET title=?,excerpt=?,body=?,published=? WHERE id=?'); $s->execute([$title,$excerpt,$body,$published,$id]);
        if(!$s->rowCount()){ $exists=$pdo->prepare('SELECT id FROM blog_posts WHERE id=?');$exists->execute([$id]);if(!$exists->fetchColumn()){flash('المقال غير موجود','err');break;} }
      }else{ $pdo->prepare('INSERT INTO blog_posts(title,excerpt,body,published) VALUES(?,?,?,?)')->execute([$title,$excerpt,$body,$published]);$id=(int)$pdo->lastInsertId(); }
      log_action('blog.save','#'.$id.' '.$title); flash('تم حفظ المقال'); $ret=admin_url(['t'=>'blog']); break;
    case 'deleteblog':
      $s=$pdo->prepare('DELETE FROM blog_posts WHERE id=?');$s->execute([$id]);
      if($s->rowCount()){log_action('blog.delete','#'.$id);flash('تم حذف المقال');}
      $ret=admin_url(['t'=>'blog']); break;
    case 'readcontact':
      $s=$pdo->prepare('UPDATE contact_messages SET is_read=1 WHERE id=?');$s->execute([$id]);
      log_action('contact.read','#'.$id); $ret=admin_url(['t'=>'contact','view'=>$id,'f'=>$f,'q'=>$q,'p'=>$page>1?$page:'']); break;
    case 'deletecontact':
      $s=$pdo->prepare('DELETE FROM contact_messages WHERE id=?');$s->execute([$id]);
      if($s->rowCount()){log_action('contact.delete','#'.$id);flash('تم حذف رسالة التواصل');}
      $ret=admin_url(['t'=>'contact']); break;
    case 'bulkcontactread':
      $contactIds=array_slice(array_values(array_unique(array_filter(array_map('intval',(array)($_POST['ids']??[])),fn($value)=>$value>0))),0,500);
      if(!$contactIds){flash('حدّد رسالة واحدة على الأقل أولًا','err');break;}
      $in=implode(',',array_fill(0,count($contactIds),'?'));
      $updated=$pdo->prepare("UPDATE contact_messages SET is_read=1 WHERE is_read=0 AND id IN ($in)");$updated->execute($contactIds);
      $changed=$updated->rowCount();if($changed)log_action('contact.read',$changed.' رسالة تواصل (إجراء جماعي)');
      flash('تم تحديد '.ar_num($changed).' رسالة كمقروءة');$ret=admin_url(['t'=>'contact','q'=>$q,'f'=>$f,'p'=>$page>1?$page:'']);break;
    case 'clearlogs':
      $pdo->exec('DELETE FROM admin_logs'); log_action('logs.clear'); flash('تم مسح سجل النشاط'); break;

    case 'export':
      $what=(string)($_POST['what']??'');
      if($what==='users'){
        $userFilter=(string)($_POST['f']??'all');
        if(!in_array($userFilter,['all','active','admin','disabled','verified','premium'],true))$userFilter='all';
        $userSearch=mb_substr(trim((string)($_POST['q']??'')),0,160);$like='%'.$userSearch.'%';
        $userWhere=['(u.username LIKE ? OR u.email LIKE ? OR u.display_name LIKE ?)'];$userParams=[$like,$like,$like];
        $userFilterSql=['active'=>'u.is_disabled=0','admin'=>'u.is_admin=1','disabled'=>'u.is_disabled=1','verified'=>'u.is_verified=1','premium'=>'u.insights_enabled=1'];
        if(isset($userFilterSql[$userFilter]))$userWhere[]=$userFilterSql[$userFilter];
        $userSort=(string)($_POST['sort']??'newest');
        if(!in_array($userSort,['newest','oldest','messages','activity'],true))$userSort='newest';
        $userOrder=['newest'=>'u.id DESC','oldest'=>'u.id ASC','messages'=>'mc DESC,u.id DESC','activity'=>'u.last_active_at IS NULL ASC,u.last_active_at DESC,u.id DESC'][$userSort];
        $userExport=$pdo->prepare('SELECT u.id,u.username,u.display_name,u.email,u.is_admin,u.is_disabled,(SELECT COUNT(*) FROM messages m WHERE m.recipient_id=u.id) mc,u.created_at,u.last_active_at FROM users u WHERE '.implode(' AND ',$userWhere).' ORDER BY '.$userOrder);
        $userExport->execute($userParams);log_action('export','المستخدمون'.($userFilter!=='all'?' ('.['active'=>'النشطون','admin'=>'المديرون','disabled'=>'المعطلون','verified'=>'الموثقون','premium'=>'المشتركون'][$userFilter].')':'').($userSearch!==''?' (بحث مفلتر)':''));
        send_csv('users',['المعرّف','اسم المستخدم','الاسم الظاهر','البريد','مدير','معطّل','عدد الرسائل','تاريخ التسجيل','آخر نشاط'],$userExport);
      }
      if($what==='messages'){
        $messageFilter=(string)($_POST['f']??'');
        if(!in_array($messageFilter,['','visible','hidden','reported'],true)) $messageFilter='';
        $mediaFilter=(string)($_POST['media']??'');
        if(!in_array($mediaFilter,['','voice','text'],true)) $mediaFilter='';
        $periodFilter=(string)($_POST['period']??'');
        $periodDays=['today'=>1,'week'=>7,'month'=>30];
        if(!isset($periodDays[$periodFilter])) $periodFilter='';
        $favoriteFilter=(string)($_POST['favorite']??'')==='1';
        $sortFilter=(string)($_POST['sort']??'');
        if(!in_array($sortFilter,['newest','oldest','reports'],true)) $sortFilter='newest';
        $messageSearch=mb_substr(trim((string)($_POST['q']??'')),0,160);
        $where=['1=1'];$params=[];
        if($messageSearch!==''){$where[]='(m.body LIKE ? OR u.username LIKE ? OR u.display_name LIKE ?)';$like='%'.$messageSearch.'%';array_push($params,$like,$like,$like);}
        if($messageFilter==='visible')$where[]='m.is_removed=0';
        elseif($messageFilter==='hidden')$where[]='m.is_removed=1';
        elseif($messageFilter==='reported')$where[]='EXISTS(SELECT 1 FROM reports r WHERE r.message_id=m.id)';
        if($mediaFilter==='voice')$where[]="m.audio_path IS NOT NULL AND m.audio_path<>''";
        elseif($mediaFilter==='text')$where[]="(m.audio_path IS NULL OR m.audio_path='')";
        if($favoriteFilter)$where[]='m.is_favorite=1';
        if(isset($periodDays[$periodFilter]))$where[]='m.created_at>=DATE_SUB(NOW(), INTERVAL '.$periodDays[$periodFilter].' DAY)';
        $sortSql=['newest'=>'m.id DESC','oldest'=>'m.id ASC','reports'=>'(SELECT COUNT(*) FROM reports r WHERE r.message_id=m.id) DESC,m.id DESC'][$sortFilter];
        $export=$pdo->prepare('SELECT m.id,u.username,m.body,m.is_favorite,m.is_removed,m.created_at FROM messages m JOIN users u ON u.id=m.recipient_id WHERE '.implode(' AND ',$where).' ORDER BY '.$sortSql);
        $export->execute($params);log_action('export','الرسائل'.($messageSearch!==''?' (بحث مفلتر)':''));
        send_csv('messages',['المعرّف','اسم المستلم','نص الرسالة','مفضلة','مخفية','تاريخ الإرسال'],$export);
      }
      if($what==='contact'){
        $contactFilter=(string)($_POST['f']??'all');if(!in_array($contactFilter,['all','unread','read'],true))$contactFilter='all';
        $contactSearch=mb_substr(trim((string)($_POST['q']??'')),0,160);$contactWhere=[];$contactParams=[];
        if($contactFilter==='unread')$contactWhere[]='is_read=0';elseif($contactFilter==='read')$contactWhere[]='is_read=1';
        if($contactSearch!==''){$contactWhere[]='(name LIKE ? OR email LIKE ? OR subject LIKE ? OR body LIKE ?)';$contactLike='%'.$contactSearch.'%';array_push($contactParams,$contactLike,$contactLike,$contactLike,$contactLike);}
        $contactQuery=$pdo->prepare('SELECT id,name,email,subject,body,IF(is_read=1,\'مقروءة\',\'جديدة\') AS status,created_at FROM contact_messages'.($contactWhere?' WHERE '.implode(' AND ',$contactWhere):'').' ORDER BY created_at DESC,id DESC');
        $contactQuery->execute($contactParams);log_action('export','رسائل التواصل'.($contactFilter!=='all'?' ('.$contactFilter.')':'').($contactSearch!==''?' (بحث مفلتر)':''));
        send_csv('contact-messages',['المعرّف','الاسم','البريد الإلكتروني','الموضوع','نص الرسالة','الحالة','التاريخ'],$contactQuery);
      }
      if($what==='reports'){
        $reportFilter=(string)($_POST['f']??'all');
        if(!in_array($reportFilter,['all','pending','removed','dismissed'],true))$reportFilter='all';
        $reportSearch=mb_substr(trim((string)($_POST['q']??'')),0,160);
        $reportWhere=[];$reportParams=[];
        if($reportFilter!=='all'){$reportWhere[]='r.status=?';$reportParams[]=$reportFilter;}
        if($reportSearch!==''){$reportWhere[]='(m.body LIKE ? OR r.details LIKE ? OR u.username LIKE ? OR ru.username LIKE ?)';$reportLike='%'.$reportSearch.'%';array_push($reportParams,$reportLike,$reportLike,$reportLike,$reportLike);}
        $reportQuery=$pdo->prepare('SELECT r.id,r.message_id,u.username AS reporter_username,ru.username AS recipient_username,r.reason,r.details,r.status,r.created_at FROM reports r JOIN users u ON u.id=r.reporter_id JOIN messages m ON m.id=r.message_id JOIN users ru ON ru.id=m.recipient_id'.($reportWhere?' WHERE '.implode(' AND ',$reportWhere):'').' ORDER BY r.id DESC');
        $reportQuery->execute($reportParams);
        log_action('export','البلاغات'.($reportFilter!=='all'?' ('.$reportFilter.')':'').($reportSearch!==''?' (بحث مفلتر)':''));
        send_csv('reports',['المعرّف','رقم الرسالة','المُبلِّغ','اسم المستلم','السبب','التفاصيل','الحالة','التاريخ'],$reportQuery);
      }
      flash('نوع تصدير غير معروف','err'); break;
    case 'backup':
      log_action('backup');
      try{send_user_backup($pdo);}catch(AdminBackupValidationException $ex){flash($ex->getMessage(),'err');break;}catch(Throwable $ex){error_log('[Asrar backup export] '.$ex->getMessage());flash('تعذّر إنشاء النسخة الاحتياطية. تحقق من تفعيل ZIP وصلاحيات مجلد الملفات المؤقتة.','err');break;}
    case 'purgehidden':
      $n=$pdo->exec('DELETE FROM messages WHERE is_removed=1'); log_action('purge.hidden',$n.' رسالة'); flash('تم حذف '.ar_num($n).' رسالة مخفية نهائيًا'); break;
  }
  header('Location: '.$ret); exit;
}

$one=function($sql,$p=[]) use($pdo){ $s=$pdo->prepare($sql); $s->execute($p); return (int)$s->fetchColumn(); };
$pending=$one("SELECT COUNT(*) FROM reports WHERE status='pending'");
$socialPending=0;if($tab==='social'){social_lab_schema();$socialPending=$one("SELECT COUNT(*) FROM social_lab_reports WHERE status='pending'");}
$unreadContact=$one('SELECT COUNT(*) FROM contact_messages WHERE is_read=0');
$flash=flash();
$siteName=site_name();
$fav=theme_favicon();
$groups=[]; foreach($sections as $k=>$s) $groups[$s[2]][$k]=$s;
?><!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="<?=e(theme_color('bg'))?>"><meta name="robots" content="noindex,nofollow">
<title><?=e($sections[$tab][0])?> | لوحة تحكم <?=e($siteName)?></title>
<link rel="icon" href="<?=$fav?>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?=font_link()?>
<link rel="stylesheet" href="style.css?v=17"><link rel="stylesheet" href="admin.css?v=23"><?php if($tab==='ai'): ?><link rel="stylesheet" href="ai-admin.css?v=3"><?php elseif($tab==='social'): ?><link rel="stylesheet" href="ai-admin.css?v=3"><link rel="stylesheet" href="social-admin.css?v=1"><?php endif; ?>
<?=theme_css()?>
</head>
<body class="adm">
<a class="skip-link" href="#adm-main">تخطَّ إلى المحتوى</a>
<div class="adm-shell">
  <aside class="adm-side" id="adm-side" aria-label="القائمة الجانبية">
    <div class="adm-brand">
      <?php if(logo_url()): ?><img src="<?=e(logo_url())?>" alt="" style="height:32px;width:auto"><?php else: ?><span class="brand-mark">أ</span><?php endif; ?>
      <div><b><?=e($siteName)?></b><small>لوحة التحكم</small></div>
      <button type="button" class="adm-close" data-nav-close aria-label="إغلاق القائمة"><?=icon('x')?></button>
    </div>
    <div class="adm-nav-search" role="search">
      <?=icon('search')?>
      <input type="search" id="adm-nav-search" aria-label="البحث في أقسام لوحة التحكم" aria-describedby="adm-nav-shortcut" placeholder="ابحث عن قسم…" autocomplete="off">
      <kbd id="adm-nav-shortcut">Ctrl K</kbd>
    </div>
    <nav class="adm-nav" aria-label="أقسام لوحة التحكم">
      <p class="adm-nav-empty" hidden>لا توجد أقسام مطابقة.</p>
      <?php foreach($groups as $g=>$items): ?>
        <span class="adm-nav-group"><?=e($g)?></span>
        <?php foreach($items as $k=>[$label,$ic]): $on=$tab===$k; ?>
          <a href="<?=e(admin_url(['t'=>$k==='overview'?'':$k]))?>" class="<?=$on?'on':''?>" aria-label="<?=e($label)?>" title="<?=e($label)?>" <?=$on?'aria-current="page"':''?>>
            <?=icon($ic)?><span><?=e($label)?></span>
            <?php if($k==='reports' && $pending): ?><span class="adm-badge" aria-label="<?=ar_num($pending)?> بلاغ معلّق"><?=ar_num($pending)?></span><?php endif; ?>
            <?php if($k==='social' && $socialPending): ?><span class="adm-badge" aria-label="<?=ar_num($socialPending)?> بلاغ مختبر معلّق"><?=ar_num($socialPending)?></span><?php endif; ?>
            <?php if($k==='contact' && $unreadContact): ?><span class="adm-badge" aria-label="<?=ar_num($unreadContact)?> رسالة تواصل جديدة"><?=ar_num($unreadContact)?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>
    <div class="adm-me">
      <?=avatar_html($me,'sm')?>
      <div class="grow"><b><?=e($me['display_name'])?></b><small dir="ltr">@<?=e($me['username'])?></small></div>
      <form method="post" action="logout.php"><?=csrf_field()?><button class="adm-icon-btn" title="تسجيل الخروج" aria-label="تسجيل الخروج"><?=icon('logout')?></button></form>
    </div>
  </aside>
  <div class="adm-backdrop" data-nav-close></div>

  <div class="adm-body">
    <header class="adm-top">
      <button type="button" class="adm-icon-btn adm-menu" data-nav-open aria-controls="adm-side" aria-expanded="false" aria-label="فتح القائمة"><?=icon('menu')?></button>
      <button type="button" class="adm-icon-btn adm-collapse" data-sidebar-toggle aria-controls="adm-side" aria-expanded="true" aria-label="طي القائمة الجانبية" title="طي القائمة الجانبية"><?=icon('panel')?></button>
      <div class="adm-crumbs"><span><?=e($sections[$tab][2])?></span><span class="adm-crumb-divider" aria-hidden="true">/</span><b><?=e($sections[$tab][0])?></b></div>
      <div class="adm-top-actions">
        <span class="adm-top-date"><?=icon('calendar')?><span><?=ar_num(date('Y/m/d'))?></span></span>
        <?php if(setting('maintenance','0')==='1'): ?><a class="adm-pill warn" href="<?=e(admin_url(['t'=>'settings']))?>"><?=icon('wrench')?><span>وضع الصيانة مفعّل</span></a><?php endif; ?>
        <?php if($pending): ?><a class="adm-icon-btn has-dot" href="<?=e(admin_url(['t'=>'reports']))?>" title="بلاغات معلّقة" aria-label="<?=ar_num($pending)?> بلاغ معلّق"><?=icon('flag')?></a><?php endif; ?>
        <a class="btn sm ghost" href="index.php" target="_blank" rel="noopener"><?=icon('external')?><span class="hide-sm">عرض الموقع</span></a>
        <a class="btn sm ghost" href="dashboard.php"><?=icon('inbox')?><span class="hide-sm">رسائلي</span></a>
      </div>
    </header>

    <main id="adm-main" class="adm-main">
      <?php if($flash): ?><div class="adm-toast <?=$flash[1]==='ok'?'ok':'err'?>" role="<?=$flash[1]==='ok'?'status':'alert'?>"><?=icon($flash[1]==='ok'?'check':'alert')?><span><?=e($flash[0])?></span><button type="button" class="adm-toast-x" aria-label="إغلاق" data-dismiss><?=icon('x')?></button></div><?php endif; ?>
      <?php require __DIR__.'/admin_parts/'.$tab.'.php'; ?>
    </main>
  </div>
</div>
<script>
(function(){
  var side=document.getElementById('adm-side'),openBtn=document.querySelector('[data-nav-open]'),sidebarToggle=document.querySelector('[data-sidebar-toggle]');
  var navSearch=document.getElementById('adm-nav-search'),nav=document.querySelector('.adm-nav'),navEmpty=document.querySelector('.adm-nav-empty');
  var navLinks=nav?Array.prototype.slice.call(nav.querySelectorAll('a')):[],navGroups=[],currentNavGroup=null;
  if(nav){Array.prototype.forEach.call(nav.children,function(node){
    if(node.classList.contains('adm-nav-group')){currentNavGroup=node;navGroups.push(node)}
    if(node.tagName==='A')node._admNavGroup=currentNavGroup;
  });}
  function filterNavigation(){
    var query=navSearch?navSearch.value.trim().toLocaleLowerCase('ar'):'';
    navLinks.forEach(function(link){link.hidden=!!query&&link.textContent.toLocaleLowerCase('ar').indexOf(query)===-1});
    navGroups.forEach(function(group){group.hidden=!!query&&!navLinks.some(function(link){return link._admNavGroup===group&&!link.hidden})});
    if(navEmpty)navEmpty.hidden=navLinks.some(function(link){return !link.hidden});
  }
  if(navSearch)navSearch.addEventListener('input',filterNavigation);
  function setNav(o){document.body.classList.toggle('nav-open',o);if(openBtn)openBtn.setAttribute('aria-expanded',o?'true':'false');}
  function setSidebarCompact(compact){document.body.classList.toggle('admin-sidebar-compact',compact);if(sidebarToggle){sidebarToggle.setAttribute('aria-expanded',compact?'false':'true');sidebarToggle.setAttribute('aria-label',compact?'توسيع القائمة الجانبية':'طي القائمة الجانبية');sidebarToggle.title=compact?'توسيع القائمة الجانبية':'طي القائمة الجانبية';}}
  if(sidebarToggle)sidebarToggle.addEventListener('click',function(){setSidebarCompact(!document.body.classList.contains('admin-sidebar-compact'));});
  function copyTextToClipboard(text){
    var fallback=function(){var field=document.createElement('textarea');field.value=text;field.setAttribute('readonly','');field.style.position='fixed';field.style.opacity='0';document.body.appendChild(field);field.select();var ok=false;try{ok=document.execCommand('copy')}catch(ignore){}field.remove();return ok?Promise.resolve():Promise.reject();};
    return navigator.clipboard&&window.isSecureContext?navigator.clipboard.writeText(text).catch(fallback):fallback();
  }
  document.addEventListener('click',function(e){
    if(e.target.closest('[data-nav-open]'))setNav(true);
    if(e.target.closest('[data-nav-close]'))setNav(false);
    var d=e.target.closest('[data-dismiss]');if(d)d.parentElement.remove();
    var all=e.target.closest('[data-check-all]');
    if(all){document.querySelectorAll('input[name="ids[]"]').forEach(function(c){c.checked=all.checked});updateBulk();}
    if(e.target.matches('input[name="ids[]"]'))updateBulk();
    var copy=e.target.closest('[data-copy]');
    if(copy&&!copy.dataset.copying){
      copy.dataset.copying='1';var original=copy.innerHTML,text=copy.dataset.copy||'';
      copyTextToClipboard(text).then(function(){copy.textContent='تم النسخ';copy.setAttribute('aria-label','تم نسخ نص الرسالة');setTimeout(function(){copy.innerHTML=original;copy.removeAttribute('aria-label');delete copy.dataset.copying;},1400);}).catch(function(){delete copy.dataset.copying;});
    }
    var copySelected=e.target.closest('[data-copy-selected]');
    if(copySelected){
      var chosen=Array.prototype.slice.call(document.querySelectorAll('input[name="ids[]"]:checked'));
      var batchText=chosen.map(function(input){var row=input.closest('.message-table-row'),body=row&&row.querySelector('.message-table-body');return 'رسالة #'+input.value+'\n'+(body?body.textContent.trim():'');}).join('\n\n');
      var feedback=document.getElementById('bulk-feedback');
      copyTextToClipboard(batchText).then(function(){if(feedback)feedback.textContent='تم نسخ '+chosen.length.toLocaleString('ar-EG')+' نصوص';}).catch(function(){if(feedback)feedback.textContent='تعذّر النسخ، حاول مرة أخرى';});
    }
  });
  document.addEventListener('keydown',function(e){
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&navSearch){e.preventDefault();setSidebarCompact(false);setNav(true);navSearch.focus();return;}
    if(e.key==='Escape'){
      if(navSearch&&navSearch.value){navSearch.value='';filterNavigation();navSearch.blur();e.preventDefault();}
      setNav(false);
    }
  });
  document.addEventListener('submit',function(e){
    var f=e.target,b=e.submitter,msg=(b&&b.dataset.confirm)||f.dataset.confirm;
    if(msg&&!confirm(msg))e.preventDefault();
  });
  function updateBulk(){var boxes=document.querySelectorAll('input[name="ids[]"]'),n=document.querySelectorAll('input[name="ids[]"]:checked').length,c=document.getElementById('bulk-count'),bar=document.getElementById('bulk-bar'),contactCount=document.getElementById('contact-bulk-count'),contactBar=document.getElementById('contact-bulk-bar'),reportCount=document.getElementById('reports-bulk-count'),reportBar=document.getElementById('reports-bulk-bar'),all=document.querySelector('[data-check-all]'),feedback=document.getElementById('bulk-feedback');if(c)c.textContent=n.toLocaleString('ar-EG');if(bar)bar.classList.toggle('show',n>0);if(contactCount)contactCount.textContent=n.toLocaleString('ar-EG');if(contactBar)contactBar.classList.toggle('show',n>0);if(reportCount)reportCount.textContent=n.toLocaleString('ar-EG');if(reportBar)reportBar.classList.toggle('show',n>0);if(all){all.checked=boxes.length>0&&n===boxes.length;all.indeterminate=n>0&&n<boxes.length;}if(feedback)feedback.textContent='';}
  var ann=document.getElementById('ann_text');
  if(ann){var pv=document.getElementById('ann-preview-text'),box=document.getElementById('ann-preview');
    var sync=function(){pv.textContent=ann.value||'اكتب نص الإعلان لتراه هنا…';var t=document.querySelector('input[name="ann_type"]:checked');if(t)box.className='announce '+t.value;};
    ann.addEventListener('input',sync);document.querySelectorAll('input[name="ann_type"]').forEach(function(r){r.addEventListener('change',sync)});sync();}
  document.querySelectorAll('textarea[data-count]').forEach(function(t){var c=document.getElementById(t.dataset.count);var u=function(){c.textContent=t.value.length+' / '+t.maxLength};t.addEventListener('input',u);u()});
  var themeForm=document.querySelector('[data-theme-form]');
  if(themeForm){
    var colors=Array.prototype.slice.call(themeForm.querySelectorAll('[data-theme-color]'));
    var names={'secondary':'secondary-accent','success':'green','warning':'amber','danger':'red','info':'blue','ink_2':'ink-2'};
    function syncColors(){
      colors.forEach(function(input){
        var prop=names[input.dataset.themeColor]||input.dataset.themeColor;
        document.documentElement.style.setProperty('--'+prop,input.value);
        var text=input.parentElement.querySelector('.color-value');if(text)text.textContent=input.value.toUpperCase();
      });
      var hex=colors.filter(function(c){return c.dataset.themeColor==='primary'})[0];
      if(hex){var x=hex.value.slice(1),rgb=[0,2,4].map(function(i){var v=parseInt(x.slice(i,i+2),16)/255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4)});
        document.documentElement.style.setProperty('--on-primary',rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722>.179?'#06070a':'#ffffff');}
    }
    colors.forEach(function(input){input.addEventListener('input',syncColors)});
    var reset=themeForm.querySelector('[data-reset-colors]');
    if(reset)reset.addEventListener('click',function(){colors.forEach(function(input){input.value=input.dataset.defaultColor});syncColors()});
  }
  var t=document.querySelector('.adm-toast.ok');if(t)setTimeout(function(){t.classList.add('hide')},4000);
})();
</script>
</body>
</html>
