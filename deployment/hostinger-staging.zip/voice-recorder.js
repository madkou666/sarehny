/* Recorder UI: preserves the existing multipart voice / voice_secs fields. */
(function () {
  'use strict';
  var box = document.getElementById('voice-rec');
  if (!box) return;
  var $ = function (id) { return document.getElementById(id); };
  var file = $('voice-file'), secs = $('voice-secs'), ta = $('body'), form = $('send-form');
  var preview = $('voice-preview'), status = $('voice-status'), time = $('voice-time');
  var startButton = $('voice-start'), pauseButton = $('voice-pause'), sendButton = $('send-submit');
  var MAX = 120, recorder, rawRecorder, stream, processedStream, context, toneOscillator, timer, frame, processingGuard, chunks = [], rawChunks = [], rawStopPromise = null, rawRecordingBlob = null, decodedRawBuffer = null, effectCache = Object.create(null), effectRequest = 0, recordedEffect = null, request = 0;
  var elapsed = 0, started = 0, cancelled = false, recordingError = '', url = null, pending = false, levels = [];
  var initialPlaceholder = ta.placeholder, selectedEffect = 'mask';
  var effectNames = { extreme: 'تغيير جذري', mask: 'تمويه', alien: 'فضائي', robot: 'روبوت', radio: 'مشوّش', echo: 'صدى غريب', bass: 'غليظ جدًا', high: 'رفيع جدًا' };
  var effectButtons = Array.prototype.slice.call(box.querySelectorAll('[data-effect]'));
  var audioEngineSupported = !!(window.AudioContext || window.webkitAudioContext) && !!(window.OfflineAudioContext || window.webkitOfflineAudioContext);
  var supported = !!(window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  function fmt(n) { return Math.floor(n / 60) + ':' + String(n % 60).padStart(2, '0'); }
  function isQuestion() { var q = document.querySelector('input[name=kind][value=question]'); return !!(q && q.checked); }
  function duration() { return elapsed + (recorder && recorder.state === 'recording' ? (performance.now() - started) / 1000 : 0); }
  function say(text, error) { status.textContent = text; box.classList.toggle('vr-err', !!error); }
  function createPitchShiftNode(audioContext, effect) {
    if (typeof audioContext.createScriptProcessor !== 'function') throw new Error('effects-unsupported');
    var semitones = { extreme: -9, mask: -3, alien: 4, robot: -2, radio: -3, echo: -2, bass: -7, high: 12 };
    var ratio = Math.pow(2, semitones[effect] / 12);
    var windowFrames = Math.round(audioContext.sampleRate * 0.12);
    var bufferLength = windowFrames + 4;
    var delayBuffer = new Float32Array(bufferLength);
  var processor = audioContext.createScriptProcessor(2048, 1, 1);
  processor.channelCount = 1; processor.channelCountMode = 'explicit';
  var writeIndex = 0, phase = 0, processedFrames = 0;
    var phaseStep = Math.abs(ratio - 1) / windowFrames;
    function readDelayedSample(delay) {
      var position = writeIndex - delay;
      while (position < 0) position += bufferLength;
      var firstIndex = Math.floor(position) % bufferLength;
      var secondIndex = (firstIndex + 1) % bufferLength;
      var mix = position - Math.floor(position);
      return delayBuffer[firstIndex] * (1 - mix) + delayBuffer[secondIndex] * mix;
    }
  processor.onaudioprocess = function (event) {
    var inputSamples = event.inputBuffer.getChannelData(0);
    var outputSamples = event.outputBuffer.getChannelData(0);
    processedFrames += inputSamples.length;
    for (var i = 0; i < inputSamples.length; i++) {
        delayBuffer[writeIndex] = inputSamples[i];
        var secondPhase = (phase + 0.5) % 1;
        var firstWeight = 0.5 - 0.5 * Math.cos(phase * Math.PI * 2);
        var firstDelay = 2 + phase * windowFrames;
        var secondDelay = 2 + secondPhase * windowFrames;
        outputSamples[i] = readDelayedSample(firstDelay) * firstWeight + readDelayedSample(secondDelay) * (1 - firstWeight);
        writeIndex = (writeIndex + 1) % bufferLength;
        phase = (phase + (ratio > 1 ? -phaseStep : phaseStep) + 1) % 1;
      }
    };
  return { node: processor, processedFrames: function () { return processedFrames; } };
}
  function buildEffectGraph(input, effect, suppliedContext, suppliedSource, suppliedOutput) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error('effects-unsupported');
    context = suppliedContext || new AC();
    var source = suppliedSource || context.createMediaStreamSource(input);
    var pitchShift = createPitchShiftNode(context, effect);
    var analyser = suppliedSource ? null : context.createAnalyser();
    if (analyser) { analyser.fftSize = 512; source.connect(analyser); }
    source.connect(pitchShift.node);
    var destination = suppliedOutput ? null : context.createMediaStreamDestination();
    var output = suppliedOutput || destination;
    var master = context.createGain(); master.gain.value = 0.9;
    var effectedVoice = context.createGain(); effectedVoice.gain.value = 1;
  var voiceHighpass = context.createBiquadFilter(); voiceHighpass.type = 'highpass'; voiceHighpass.frequency.value = 75; voiceHighpass.Q.value = 0.707;
  var presence = context.createBiquadFilter(); presence.type = 'peaking'; presence.frequency.value = 2800; presence.gain.value = 1.2; presence.Q.value = 0.8;
  var leveler = context.createDynamicsCompressor(); leveler.threshold.value = -20; leveler.knee.value = 12; leveler.ratio.value = 2; leveler.attack.value = 0.005; leveler.release.value = 0.16;
  master.connect(voiceHighpass); voiceHighpass.connect(presence); presence.connect(leveler); leveler.connect(output);
    var ring = context.createGain(); ring.gain.value = 0.68;
    var carrier = effect === 'bass' || effect === 'high' ? null : context.createOscillator();
    if (carrier) {
      carrier.type = effect === 'alien' ? 'triangle' : 'sine';
      carrier.frequency.value = { extreme: 83, mask: 61, alien: 91, robot: 34, radio: 48, echo: 67, bass: 22, high: 80 }[effect];
      var carrierDepth = context.createGain(); carrierDepth.gain.value = effect === 'robot' ? 0.32 : 0.18;
      carrier.connect(carrierDepth); carrierDepth.connect(ring.gain); carrier.start(); toneOscillator = carrier;
    }
    var tone = context.createBiquadFilter(); tone.type = effect === 'bass' ? 'lowpass' : effect === 'high' ? 'highshelf' : (effect === 'extreme' || effect === 'radio' ? 'bandpass' : 'peaking');
    tone.frequency.value = effect === 'extreme' ? 1500 : effect === 'bass' ? 1700 : effect === 'alien' ? 2400 : effect === 'robot' ? 1800 : effect === 'echo' ? 2200 : effect === 'radio' ? 1300 : effect === 'high' ? 3200 : 2200;
    tone.gain.value = effect === 'alien' || effect === 'high' ? 1.5 : 0;
    tone.Q.value = 0.65;
  if (effect === 'bass' || effect === 'high') pitchShift.node.connect(tone);
  else { pitchShift.node.connect(ring); ring.connect(tone); }
    var current = tone;
    function addFilter(type, frequency, gain, q) {
      var node = context.createBiquadFilter(); node.type = type; node.frequency.value = frequency;
      if (gain !== undefined) node.gain.value = gain;
      if (q !== undefined) node.Q.value = q;
      current.connect(node); current = node; return node;
    }
    function addCompressor(threshold, ratio) {
      var node = context.createDynamicsCompressor(); node.threshold.value = threshold; node.knee.value = 18; node.ratio.value = ratio; node.attack.value = 0.006; node.release.value = 0.16;
      current.connect(node); current = node;
    }
    function addSaturation(amount) {
      var node = context.createWaveShaper(), curve = new Float32Array(1024);
      for (var i = 0; i < curve.length; i++) { var x = i * 2 / (curve.length - 1) - 1; curve[i] = Math.tanh(amount * x) / Math.tanh(amount); }
      node.curve = curve; node.oversample = '2x'; current.connect(node); current = node;
    }
    if (effect === 'high') {
      addFilter('highpass', 120); addFilter('highshelf', 3200, 1.5); addFilter('lowpass', 9000); addCompressor(-20, 1.7); current.connect(effectedVoice);
    } else if (effect === 'extreme') {
      addFilter('highpass', 100); addFilter('peaking', 980, 2, 1.1); addFilter('lowpass', 4800);
      addSaturation(2.2); addCompressor(-25, 2.5); current.connect(effectedVoice);
    } else if (effect === 'bass') {
      addFilter('highpass', 70); addFilter('lowshelf', 150, 4); addFilter('peaking', 240, 2.5, 0.9);
      addFilter('lowpass', 3800); addCompressor(-26, 2.5); addSaturation(1.8); current.connect(effectedVoice);
    } else if (effect === 'mask') {
      addFilter('lowpass', 4200); addSaturation(1.7); addCompressor(-23, 2); current.connect(effectedVoice);
    } else if (effect === 'alien') {
      addFilter('highpass', 180); addFilter('lowpass', 4200); addSaturation(1.5); current.connect(effectedVoice);
    } else if (effect === 'robot') {
      addFilter('lowpass', 4200); addSaturation(1.7); addCompressor(-27, 2.2); current.connect(effectedVoice);
    } else if (effect === 'radio') {
      addFilter('highpass', 250); addFilter('peaking', 1450, 2, 0.8); addFilter('lowpass', 4200); addCompressor(-23, 2.2); addSaturation(1.4); current.connect(effectedVoice);
    } else {
      var dry = context.createGain(); dry.gain.value = 0.55; current.connect(dry); dry.connect(effectedVoice);
      var delay = context.createDelay(0.7); delay.delayTime.value = 0.24;
      var feedback = context.createGain(); feedback.gain.value = 0.12;
      var wet = context.createGain(); wet.gain.value = 0.2;
      current.connect(delay); delay.connect(wet); wet.connect(effectedVoice); delay.connect(feedback); feedback.connect(delay);
    }
    effectedVoice.connect(master);
    return { stream: destination ? destination.stream : null, analyser: analyser, processedFrames: pitchShift.processedFrames };
  }
  function normalizeVoiceLevel(audioBuffer) {
    var samples = audioBuffer.getChannelData(0), peak = 0, activeSquareSum = 0, activeSamples = 0;
    for (var i = 0; i < samples.length; i++) {
      var magnitude = Math.abs(samples[i]); peak = Math.max(peak, magnitude);
      if (magnitude > 0.006) { activeSquareSum += samples[i] * samples[i]; activeSamples++; }
    }
    var activeRms = activeSamples ? Math.sqrt(activeSquareSum / activeSamples) : peak;
    var gain = Math.min(1.75, 0.14 / Math.max(activeRms, 0.01), 0.9 / Math.max(peak, 0.01));
    for (var j = 0; j < samples.length; j++) samples[j] *= gain;
    return audioBuffer;
  }
  function encodeWav(audioBuffer) {
    var samples = audioBuffer.getChannelData(0), bytes = 44 + samples.length * 2, output = new ArrayBuffer(bytes), view = new DataView(output);
    function writeText(offset, text) { for (var i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i)); }
    writeText(0, 'RIFF'); view.setUint32(4, bytes - 8, true); writeText(8, 'WAVE'); writeText(12, 'fmt ');
    view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true);
    view.setUint32(24, audioBuffer.sampleRate, true); view.setUint32(28, audioBuffer.sampleRate * 2, true);
    view.setUint16(32, 2, true); view.setUint16(34, 16, true); writeText(36, 'data'); view.setUint32(40, samples.length * 2, true);
    for (var i = 0; i < samples.length; i++) { var sample = Math.max(-1, Math.min(1, samples[i])); view.setInt16(44 + i * 2, sample < 0 ? sample * 32768 : sample * 32767, true); }
    return new Blob([output], { type: 'audio/wav' });
  }
  function processRecordedAudio(blob, effect) {
    var AC = window.AudioContext || window.webkitAudioContext;
    var Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!AC || !Offline) return Promise.reject(new Error('effects-unsupported'));
    if (decodedRawBuffer) return renderDecodedAudio(decodedRawBuffer, effect, Offline);
    var decoder = new AC();
    return blob.arrayBuffer().then(function (bytes) { return decoder.decodeAudioData(bytes); }).then(function (decoded) {
      decodedRawBuffer = decoded;
      if (decoder.state !== 'closed') decoder.close().catch(function () {});
      return renderDecodedAudio(decoded, effect, Offline);
    }).catch(function (error) {
      if (decoder.state !== 'closed') decoder.close().catch(function () {});
      throw error;
    });
  }
  function renderDecodedAudio(decoded, effect, Offline) {
    try {
      var sampleRate = 24000, frameCount = Math.max(1, Math.ceil((Math.min(decoded.duration, MAX) + 0.45) * sampleRate));
      var offline = new Offline(1, frameCount, sampleRate), source = offline.createBufferSource();
      source.buffer = decoded;
      buildEffectGraph(null, effect, offline, source, offline.destination);
      source.start(0);
      return offline.startRendering().then(function (rendered) {
        if (toneOscillator) { try { toneOscillator.stop(); } catch (e) {} toneOscillator = null; }
        context = null;
        return encodeWav(normalizeVoiceLevel(rendered));
      }).catch(function (error) {
        if (toneOscillator) { try { toneOscillator.stop(); } catch (e) {} toneOscillator = null; }
        context = null;
        throw error;
      });
    } catch (error) {
      if (toneOscillator) { try { toneOscillator.stop(); } catch (e) {} toneOscillator = null; }
      context = null;
      return Promise.reject(error);
    }
  }
  function renderRecordedEffect(effect) {
    if (!rawRecordingBlob) return;
    var token = ++effectRequest, effectBlob = effectCache[effect], shouldFocusPreview = recordedEffect === null;
    if (preview._vp) preview._vp.stop();
    state('processing'); say('جارٍ تجهيز صوت ' + effectNames[effect] + ' للاستماع…');
    var rendered = effectBlob ? Promise.resolve(effectBlob) : processRecordedAudio(rawRecordingBlob, effect);
    rendered.then(function (blob) {
      if (token !== effectRequest) return;
      if (!effectBlob) effectCache[effect] = blob;
      if (blob.size > 6 * 1024 * 1024) throw new Error('recording-too-large');
      var transfer = new DataTransfer();
      transfer.items.add(new File([blob], 'voice.wav', { type: 'audio/wav' }));
      file.files = transfer.files;
      if (preview._vp) preview._vp.reset();
      if (url) URL.revokeObjectURL(url);
      url = URL.createObjectURL(blob);
      preview.setAttribute('data-src', url); preview.setAttribute('data-secs', secs.value); preview.setAttribute('data-bytes', blob.size);
      $('voice-meta').textContent = fmt(Math.ceil(elapsed)) + ' · ' + Math.max(1, Math.round(blob.size / 1024)) + ' ك.ب · ' + effectNames[effect];
      recordedEffect = effect;
      state('ready'); say('يمكنك الاستماع إلى ' + effectNames[effect] + ' أو اختيار صوت آخر.');
      if (window.VoicePlayer) window.VoicePlayer.mount(preview);
      var play = preview.querySelector('.vp-play'); if (play && shouldFocusPreview) play.focus();
    }).catch(function (error) {
      if (token !== effectRequest) return;
      if (recordedEffect) { selectedEffect = recordedEffect; state('ready'); say(error.message === 'recording-too-large' ? 'حجم الملف بعد المعالجة تجاوز الحد؛ اختر تأثيرًا آخر.' : 'تعذّرت معاينة هذا التأثير. احتفظنا بالنسخة السابقة، جرّب تأثيرًا آخر.', true); }
      else { discard(); say(error.message === 'recording-too-large' ? 'حجم الملف بعد المعالجة تجاوز الحد. سجّل مدة أقصر.' : 'تعذّرت معالجة التسجيل على هذا الجهاز. جرّب متصفحًا حديثًا وأعد التسجيل.', true); }
    });
  }
  function state(value) {
    box.dataset.state = value;
    box.querySelectorAll('.vr-pane').forEach(function (pane) {
      pane.hidden = !(pane.classList.contains('vr-' + value) || (pane.classList.contains('vr-rec') && value === 'paused'));
    });
    ta.required = value !== 'ready';
    ta.minLength = value === 'ready' ? 0 : 2;
    if (sendButton) sendButton.disabled = ['requesting', 'rec', 'paused', 'processing'].indexOf(value) !== -1;
    startButton.disabled = !supported || !audioEngineSupported || isQuestion() || value === 'requesting';
    effectButtons.forEach(function (button) {
      var unavailable = !audioEngineSupported;
      button.disabled = (value !== 'idle' && value !== 'ready') || isQuestion() || unavailable;
      button.tabIndex = button.dataset.effect === selectedEffect ? 0 : -1;
      if (unavailable) button.title = 'تأثيرات الصوت غير مدعومة في هذا المتصفح';
      button.setAttribute('aria-checked', String(button.dataset.effect === selectedEffect));
      button.setAttribute('aria-pressed', String(button.dataset.effect === selectedEffect));
      button.classList.toggle('is-selected', button.dataset.effect === selectedEffect);
    });
    box.setAttribute('aria-busy', String(value === 'requesting' || value === 'processing'));
    pauseButton.setAttribute('aria-label', value === 'paused' ? 'استكمال التسجيل' : 'إيقاف التسجيل مؤقتًا');
    pauseButton.title = pauseButton.getAttribute('aria-label');
    pauseButton.setAttribute('aria-pressed', String(value === 'paused'));
  }
  function release() {
    clearInterval(timer); clearInterval(processingGuard); processingGuard = null; cancelAnimationFrame(frame);
    if (rawRecorder && rawRecorder.state !== 'inactive') { try { rawRecorder.stop(); } catch (e) {} }
    rawRecorder = null;
    if (toneOscillator) { try { toneOscillator.stop(); } catch (e) {} toneOscillator = null; }
    if (processedStream && processedStream !== stream) processedStream.getTracks().forEach(function (track) { track.stop(); });
    if (stream) stream.getTracks().forEach(function (track) { track.stop(); });
    processedStream = null; stream = null;
    if (context && context.state !== 'closed' && typeof context.close === 'function') context.close().catch(function () {});
    context = null;
  }
  function discard() {
    effectRequest++;
    rawRecordingBlob = null; decodedRawBuffer = null; rawChunks = []; effectCache = Object.create(null); rawStopPromise = null; recordedEffect = null;
    if (preview._vp) preview._vp.reset();
    preview.removeAttribute('data-src'); preview.removeAttribute('data-secs'); preview.removeAttribute('data-peaks'); preview.removeAttribute('data-bytes');
    $('voice-meta').textContent = '';
    if (url) URL.revokeObjectURL(url);
    url = null; file.value = ''; secs.value = ''; elapsed = 0;
    box.classList.remove('vr-near'); $('voice-bar').style.width = '0%'; time.textContent = '0:00';
    ta.placeholder = isQuestion() ? 'ما السؤال الذي تود طرحه؟' : initialPlaceholder;
    state('idle'); say(isQuestion() ? 'الصوت متاح للرسائل الخاصة فقط' : supported ? '' : 'التسجيل غير مدعوم هنا. جرّب متصفحًا حديثًا عبر اتصال آمن.', !supported);
  }
  function cancel() {
    request++; pending = false; cancelled = true;
    if (recorder && recorder.state !== 'inactive') { recorder.stop(); if (rawRecorder && rawRecorder.state !== 'inactive') rawRecorder.stop(); }
    else { release(); discard(); }
  }
  function draw(analyser) {
    var canvas = $('voice-wave'), ctx = canvas.getContext('2d');
    if (!ctx) return;
    var samples = new Uint8Array(analyser.fftSize), history = [], last = 0;
    var color = getComputedStyle(box).getPropertyValue('--vr-live').trim();
    function loop(now) {
      frame = requestAnimationFrame(loop);
      if (document.hidden || !recorder || recorder.state !== 'recording' || now - last < 50) return;
      last = now;
      var w = canvas.clientWidth, h = canvas.clientHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (!w || !h) return;
      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
      analyser.getByteTimeDomainData(samples);
      var peak = 0;
      for (var j = 0; j < samples.length; j++) peak = Math.max(peak, Math.abs(samples[j] - 128) / 128);
      peak = Math.min(1, peak * 2); levels.push(peak); history.push(peak);
      var count = Math.floor(w / 6); if (history.length > count) history.splice(0, history.length - count);
      ctx.fillStyle = color;
      history.forEach(function (p, i) { var bh = Math.max(3, p * h); ctx.fillRect(w - (history.length - i) * 6, (h - bh) / 2, 3, bh); });
    }
    frame = requestAnimationFrame(loop);
  }
  function pause() {
    if (!recorder || recorder.state !== 'recording') return;
    elapsed = duration(); recorder.pause(); if (rawRecorder && rawRecorder.state === 'recording') rawRecorder.pause(); state('paused'); update(); say('التسجيل متوقف مؤقتًا');
  }
  function update() {
    var d = Math.min(MAX, duration()); time.textContent = fmt(Math.floor(d));
    $('voice-bar').style.width = d / MAX * 100 + '%';
    box.classList.toggle('vr-near', d >= MAX - 10);
    if (d >= MAX) stop();
  }
  function stop() {
    if (!recorder || recorder.state === 'inactive') return;
    elapsed = Math.min(MAX, duration());
    state('processing'); say('جارٍ تجهيز التسجيل…'); recorder.stop(); if (rawRecorder && rawRecorder.state !== 'inactive') rawRecorder.stop();
  }
  function waitForEffectProcessing(graph, token) {
    return new Promise(function (resolve, reject) {
      var startedAt = performance.now(), initialFrames = graph.processedFrames();
      function verify() {
        if (token !== request || cancelled || !stream) return;
        var outputTracks = graph.stream.getAudioTracks();
        var microphoneTracks = stream.getAudioTracks();
        var outputIsProcessed = outputTracks.length === 1 && outputTracks[0].readyState === 'live' && !microphoneTracks.some(function (track) { return track.id === outputTracks[0].id; });
        if (context && context.state === 'running' && graph.processedFrames() > initialFrames && outputIsProcessed) { resolve(); return; }
        if (performance.now() - startedAt >= 1500) { reject(new Error('effects-unsupported')); return; }
        setTimeout(verify, 40);
      }
      verify();
    });
  }
  function beginCapture(graph) {
    var outputTracks = graph.stream.getAudioTracks();
    if (outputTracks.length !== 1 || outputTracks.some(function (track) { return stream.getTracks().some(function (sourceTrack) { return sourceTrack.id === track.id; }); })) throw new Error('effects-unsupported');
    var mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/ogg;codecs=opus'].find(function (m) { return MediaRecorder.isTypeSupported(m); });
    recorder = new MediaRecorder(graph.stream, mime ? { mimeType: mime, audioBitsPerSecond: 96000 } : {});
    var activeRecorder = recorder;
    rawChunks = [];
    rawRecorder = new MediaRecorder(stream, mime ? { mimeType: mime, audioBitsPerSecond: 96000 } : {});
    var activeRawRecorder = rawRecorder;
    rawStopPromise = new Promise(function (resolve) {
      activeRawRecorder.addEventListener('stop', function () { resolve(new Blob(rawChunks, { type: (activeRawRecorder.mimeType || 'audio/webm').split(';')[0] })); }, { once: true });
    });
    rawRecorder.ondataavailable = function (event) { if (event.data.size) rawChunks.push(event.data); };
    rawRecorder.onerror = function () { cancelled = true; recordingError = 'تعذّر التسجيل بسبب خطأ في الميكروفون. حاول مرة أخرى.'; if (activeRawRecorder.state !== 'inactive') activeRawRecorder.stop(); if (activeRecorder.state !== 'inactive') activeRecorder.stop(); };
    recorder.onerror = function () { cancelled = true; recordingError = 'تعذّر التسجيل بسبب خطأ في الميكروفون. حاول مرة أخرى.'; if (activeRecorder.state !== 'inactive') activeRecorder.stop(); if (activeRawRecorder.state !== 'inactive') activeRawRecorder.stop(); };
    recorder.onstop = function () {
      if (activeRecorder !== recorder) return;
      Promise.resolve(rawStopPromise).then(function (rawBlob) {
        release();
        if (cancelled || isQuestion()) { var errorMessage = recordingError; recordingError = ''; discard(); if(errorMessage) say(errorMessage, true); return; }
        if (elapsed < 1 || !rawBlob || !rawBlob.size) { discard(); say('التسجيل قصير جدًا. سجّل ثانية واحدة على الأقل.', true); return; }
        if (rawBlob.size > 6 * 1024 * 1024) { discard(); say('التسجيل كبير جدًا. جرّب تسجيلًا أقصر.', true); return; }
        rawRecordingBlob = rawBlob; effectCache = Object.create(null); recordedEffect = null;
        secs.value = Math.min(MAX, Math.max(1, Math.ceil(elapsed)));
        var peaks = [];
        for (var i = 0; i < 42; i++) { var from = Math.floor(i * levels.length / 42), to = Math.max(from + 1, Math.floor((i + 1) * levels.length / 42)), peak = 0; for (var j = from; j < to; j++) peak = Math.max(peak, levels[j] || 0); peaks.push(Math.max(.12, peak)); }
        preview.setAttribute('data-peaks', JSON.stringify(peaks));
        ta.placeholder = 'أضف تعليقًا مع الصوت (اختياري)';
        renderRecordedEffect(selectedEffect);
      }).catch(function () { release(); discard(); say('تعذّر تجهيز التسجيل. أعد التسجيل وحاول مرة أخرى.', true); });
    };
    rawRecorder.start(250); recorder.start(250); started = performance.now(); state('rec'); say('جارٍ التسجيل بصوتك؛ يمكنك اختيار التأثير بعد انتهائه.');
    time.textContent = '0:00'; $('voice-bar').style.width = '0%';
    timer = setInterval(update, 200);
    var lastProcessedFrames = graph.processedFrames(), stalledChecks = 0;
    processingGuard = setInterval(function () {
      if (!recorder || recorder.state !== 'recording') return;
      var currentFrames = graph.processedFrames();
      if (context && context.state === 'running' && currentFrames > lastProcessedFrames) {
        lastProcessedFrames = currentFrames; stalledChecks = 0; return;
      }
      stalledChecks++;
      if (stalledChecks >= 3) {
        cancelled = true;
        recordingError = 'توقفت معالجة تمويه الصوت؛ أُلغي التسجيل حفاظًا على صوتك. أعد التسجيل في متصفح حديث.';
        if (recorder.state !== 'inactive') recorder.stop();
        if (rawRecorder && rawRecorder.state !== 'inactive') rawRecorder.stop();
      }
    }, 500);
    if (graph.analyser) draw(graph.analyser);
    $('voice-stop').focus();
  }
  function start() {
    if (pending || isQuestion() || !supported || (recorder && recorder.state !== 'inactive')) return;
    if (preview._vp) preview._vp.stop();
    pending = true; var token = ++request;
    state('requesting'); say('جارٍ فتح الميكروفون…');
    navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }).then(function (s) {
      if (token !== request || isQuestion()) { s.getTracks().forEach(function (t) { t.stop(); }); return; }
      pending = false; stream = s; chunks = []; levels = []; elapsed = 0; cancelled = false; recordingError = '';
      try {
        var graph = buildEffectGraph(s, selectedEffect); processedStream = graph.stream;
        var resumed = context && context.state === 'suspended' ? context.resume() : Promise.resolve();
        resumed.then(function () {
          if (token !== request || cancelled || !stream) return;
          return waitForEffectProcessing(graph, token);
        }).then(function () {
          if (token !== request || cancelled || !stream) return;
          beginCapture(graph);
        }).catch(function () {
          if (token !== request) return;
          release(); discard(); state('idle');
          say('تعذّر التحقق من معالجة الصوت على هذا الجهاز؛ لم يبدأ التسجيل حفاظًا على صوتك. جرّب متصفحًا حديثًا.', true);
        });
    } catch (e) {
      pending = false; release(); state('idle');
      say(e.message === 'effects-unsupported' ? 'هذا المتصفح لا يدعم تمويه الصوت؛ استخدم متصفحًا حديثًا.' : 'تعذّر تجهيز مؤثر تمويه الصوت. حاول مرة أخرى.', true);
      }
    }).catch(function (error) {
      if (token !== request) return;
      pending = false; state('idle');
      say(error.name === 'NotAllowedError' ? 'اسمح باستخدام الميكروفون من إعدادات المتصفح، ثم حاول مجددًا.' : error.name === 'NotFoundError' ? 'لم يتم العثور على ميكروفون. تأكد من توصيله.' : 'الميكروفون غير متاح الآن. أغلق أي تطبيق يستخدمه وحاول مجددًا.', true);
    });
  }
  pauseButton.addEventListener('click', function () {
    if (!recorder) return;
    if (recorder.state === 'recording') { pause(); }
    else if (recorder.state === 'paused') {
      var activeRecorder = recorder;
      var resumeAudio = context && context.state === 'suspended' ? context.resume() : Promise.resolve();
      resumeAudio.then(function () {
        if (activeRecorder !== recorder || activeRecorder.state !== 'paused') return;
        activeRecorder.resume(); if (rawRecorder && rawRecorder.state === 'paused') rawRecorder.resume(); started = performance.now(); state('rec'); say('جارٍ التسجيل');
      }).catch(function () {
        cancelled = true; recordingError = 'تعذّرت استعادة معالجة الصوت على هذا الجهاز؛ أُلغي التسجيل للحفاظ على صوتك.';
        if (activeRecorder.state !== 'inactive') activeRecorder.stop();
        if (rawRecorder && rawRecorder.state !== 'inactive') rawRecorder.stop();
      });
    }
  });
  effectButtons.forEach(function (button) {
    button.addEventListener('click', function () {
      if (button.disabled || !effectNames[button.dataset.effect]) return;
      selectedEffect = button.dataset.effect;
      state(box.dataset.state || 'idle');
      var help = $('voice-effect-help');
      if (help) help.textContent = 'بعد التسجيل، بدّل بين الأصوات واستمع لكل نسخة قبل الإرسال. لا يحوّل المؤثر صوتك إلى صوت شخص آخر ولا يضمن إخفاء الهوية.';
      if (rawRecordingBlob) renderRecordedEffect(selectedEffect);
      else say('تم اختيار تأثير ' + effectNames[selectedEffect] + ' للتسجيل.');
    });
  });
  var effectGroup = box.querySelector('[role="radiogroup"]');
  effectGroup.addEventListener('keydown', function (event) {
    var current = effectButtons.indexOf(document.activeElement);
    if (current < 0 || ['ArrowLeft', 'ArrowRight', 'ArrowDown', 'ArrowUp', 'Home', 'End'].indexOf(event.key) < 0) return;
    event.preventDefault();
    var next = event.key === 'Home' ? 0 : event.key === 'End' ? effectButtons.length - 1 : (current + (event.key === 'ArrowRight' || event.key === 'ArrowDown' ? 1 : -1) + effectButtons.length) % effectButtons.length;
    while (effectButtons[next].disabled && next !== current) next = (next + (next > current ? 1 : -1) + effectButtons.length) % effectButtons.length;
    effectButtons[next].focus(); effectButtons[next].click();
  });
  startButton.addEventListener('click', start);
  $('voice-stop').addEventListener('click', stop);
  $('voice-cancel').addEventListener('click', cancel);
  $('voice-del').addEventListener('click', function () { discard(); startButton.focus(); });
  $('voice-redo').addEventListener('click', function () { discard(); start(); });
  document.querySelectorAll('input[name=kind]').forEach(function (radio) { radio.addEventListener('change', function () { if (isQuestion()) cancel(); box.classList.toggle('disabled', isQuestion()); state(box.dataset.state || 'idle'); say(isQuestion() ? 'الصوت متاح للرسائل الخاصة فقط' : ''); }); });
  form.addEventListener('submit', function (e) {
    if (['requesting', 'rec', 'paused', 'processing'].indexOf(box.dataset.state) !== -1) { e.preventDefault(); e.stopImmediatePropagation(); say('أنهِ التسجيل أولًا قبل الإرسال.', true); }
  }, true);
  document.addEventListener('visibilitychange', function () { if (document.hidden) { if (pending) cancel(); else pause(); if (preview._vp) preview._vp.stop(); } });
  window.addEventListener('pagehide', function () { request++; cancelled = true; if (recorder && recorder.state !== 'inactive') recorder.stop(); release(); if (url) URL.revokeObjectURL(url); });
  discard(); box.classList.toggle('disabled', isQuestion());
})();
