<?php require 'inc.php'; require_once 'push_lib.php'; $u=require_login();
header('Content-Type: application/json; charset=utf-8');
$a=(string)($_GET['a']??'');
if($a==='key'){ $v=push_vapid(); echo json_encode(['key'=>$v?$v['pub']:null,'enabled'=>true]); exit; }
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); exit; }
$ep=(string)($_POST['endpoint']??''); $p=(string)($_POST['p256dh']??''); $au=(string)($_POST['auth']??'');
if($a==='sub'){
  if(!preg_match('#^https://#',$ep)||strlen($ep)>800||!preg_match('/^[A-Za-z0-9_-]{80,100}$/',$p)||!preg_match('/^[A-Za-z0-9_-]{16,30}$/',$au)){ http_response_code(400); echo '{"ok":false}'; exit; }
  $pdo->prepare('INSERT INTO push_subs(user_id,endpoint_hash,endpoint,p256dh,auth) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),p256dh=VALUES(p256dh),auth=VALUES(auth)')->execute([$u['id'],hash('sha256',$ep),$ep,$p,$au]);
  echo '{"ok":true}'; exit;
}
if($a==='unsub'){ echo '{"ok":true}'; exit; }
if($a==='test'){ $n=push_notify_user($u['id'],'إشعار تجريبي 🔔','الإشعارات تعمل! ستصلك تنبيهات عند وصول رسائل جديدة.'); echo json_encode(['ok'=>$n>0,'sent'=>$n]); exit; }
http_response_code(400);
