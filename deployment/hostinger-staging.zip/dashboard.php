<?php require 'inc.php'; $u=require_login();
$filter=in_array($_GET['f']??'', ['q','pending','published','fav'], true)?$_GET['f']:'all';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=(int)($_POST['id']??0); $a=$_POST['action']??'';
  if($a==='fav') $pdo->prepare('UPDATE messages SET is_favorite=1-is_favorite WHERE id=? AND recipient_id=?')->execute([$id,$u['id']]);
  if($a==='del'){ $vp=$pdo->prepare('SELECT audio_path FROM messages WHERE id=? AND recipient_id=?'); $vp->execute([$id,$u['id']]); $vpath=$vp->fetchColumn(); if($vpath && preg_match('/^[a-f0-9]{32}\.[a-z0-9]{3,4}$/',$vpath)) @unlink(__DIR__.'/uploads/voice/'.$vpath); $pdo->prepare('DELETE FROM messages WHERE id=? AND recipient_id=?')->execute([$id,$u['id']]); flash('تم حذف الرسالة'); }
  if($a==='answer' || $a==='unpublish'){
    $target=$pdo->prepare('SELECT answer FROM messages WHERE id=? AND recipient_id=? AND is_question=1 AND is_removed=0'); $target->execute([$id,$u['id']]); $existing=$target->fetch();
    if(!$existing){ flash('لم يتم العثور على السؤال','err'); }
    elseif($a==='unpublish'){ $pdo->prepare('UPDATE messages SET answer=NULL,answered_at=NULL WHERE id=? AND recipient_id=? AND is_question=1')->execute([$id,$u['id']]); flash('تم إخفاء السؤال والجواب من صفحتك العامة'); }
    else { $ans=trim((string)($_POST['answer']??''));
      if(mb_strlen($ans)<2 || mb_strlen($ans)>2000) flash('اكتب جوابًا بين حرفين و٢٠٠٠ حرف','err');
      elseif(find_banned_word($ans)!==null) flash('يحتوي الجواب على كلمات غير مسموح بها','err');
      else { $pdo->prepare('UPDATE messages SET answer=?,answered_at=COALESCE(answered_at,NOW()) WHERE id=? AND recipient_id=? AND is_question=1')->execute([$ans,$id,$u['id']]); flash($existing['answer']===null?'تم نشر سؤالك وجوابك للجميع':'تم تحديث جوابك المنشور'); }
    }
  }
  if($a==='report'){ $s=$pdo->prepare('SELECT id FROM messages WHERE id=? AND recipient_id=?'); $s->execute([$id,$u['id']]);
    $reason=in_array($_POST['reason']??'',['harassment','threat','spam','other'],true)?$_POST['reason']:'other';
    if($s->fetch()){ $pdo->prepare('INSERT INTO reports(message_id,reporter_id,reason,details) VALUES(?,?,?,?)')->execute([$id,$u['id'],$reason,mb_substr(trim((string)($_POST['details']??'')),0,500)]); flash('تم إرسال البلاغ، شكرًا لمساعدتك في الحفاظ على المجتمع'); } }
  header('Location: dashboard.php'.($filter!=='all'?'?f='.$filter:'')); exit;
}
$cnt=$pdo->prepare('SELECT COUNT(*) total, COALESCE(SUM(is_favorite),0) fav, COALESCE(SUM(is_question),0) questions, COALESCE(SUM(is_question=1 AND answer IS NULL),0) pending, COALESCE(SUM(is_question=1 AND answer IS NOT NULL),0) published, COALESCE(SUM(created_at>NOW()-INTERVAL 1 DAY),0) today FROM messages WHERE recipient_id=? AND is_removed=0'); $cnt->execute([$u['id']]); $c=$cnt->fetch();
$activityQuery=$pdo->prepare('SELECT DATE(created_at) AS activity_day, COUNT(*) AS total FROM messages WHERE recipient_id=? AND is_removed=0 AND created_at>=DATE_SUB(CURRENT_DATE, INTERVAL 29 DAY) GROUP BY DATE(created_at)');
$activityQuery->execute([$u['id']]); $activityMap=[];
foreach($activityQuery->fetchAll() as $activityRow) $activityMap[$activityRow['activity_day']]=(int)$activityRow['total'];
$activityDays=[]; $activityTotal7=0; $activityMax=1;
for($age=29;$age>=0;$age--){$dayKey=date('Y-m-d',strtotime('-'.$age.' days'));$dayCount=$activityMap[$dayKey]??0;$activityDays[]=['age'=>$age,'date'=>$dayKey,'count'=>$dayCount];if($age<7)$activityTotal7+=$dayCount;$activityMax=max($activityMax,$dayCount);}
$replyRate=(int)$c['questions']?round(((int)$c['published']/(int)$c['questions'])*100):0;
$s=$pdo->prepare('SELECT * FROM messages WHERE recipient_id=? AND is_removed=0 '.($filter==='fav'?'AND is_favorite=1 ':($filter==='q'?'AND is_question=1 ':($filter==='pending'?'AND is_question=1 AND answer IS NULL ':($filter==='published'?'AND is_question=1 AND answer IS NOT NULL ':'')))).'ORDER BY created_at DESC LIMIT 300'); $s->execute([$u['id']]); $msgs=$s->fetchAll();
$favoriteQuery=$pdo->prepare('SELECT id,body,audio_path,created_at FROM messages WHERE recipient_id=? AND is_removed=0 AND is_favorite=1 ORDER BY created_at DESC LIMIT 3'); $favoriteQuery->execute([$u['id']]); $featuredFavorites=$favoriteQuery->fetchAll();
$insOn=insights_active($u); $metaMap=$insOn&&$msgs?load_meta($pdo,array_column($msgs,'id')):[];
$link=base_url().'/'.rawurlencode($u['username']);
$shareText='أرسل لي رسالة مجهولة بصدق: ';
$flash=flash();
head('صندوق رسائلي','app dashboard-glass'); ?>
<section class="page dashboard-page">
  <div class="wrap">
    <div class="dashboard-heading">
      <div class="dashboard-identity"><?=avatar_html($u,'','span')?><div class="dashboard-welcome">
        <span class="dashboard-eyebrow">أسرار · لوحة المستخدم</span>
        <h1>مرحبًا، <?=e($u['display_name'])?><?=verified_badge($u,'lg')?></h1>
        <p>صندوق رسائلك الخاص</p>
      </div>
      </div>
      <div class="dashboard-heading-actions">
        <a class="btn ghost" href="analysis.php"><?=icon('activity')?> تحليل شخصيتي</a>
        <a class="btn ghost" href="social-lab.php"><?=icon('activity')?> المختبر الاجتماعي AI</a>
        <a class="btn ghost" href="account.php?t=profile"><?=icon('settings')?> إعدادات الملف</a>
        <a class="btn" href="<?=e($link)?>" target="_blank" rel="noopener"><?=icon('external')?> عرض صفحتي</a>
      </div>
    </div>
    <div class="dashboard-stats" aria-label="ملخص صندوق الرسائل">
      <?php foreach([['total','إجمالي الرسائل','inbox','cyan','كل ما وصل إليك'],['today','آخر ٢٤ ساعة','clock','violet','رسائل اليوم'],['pending','أسئلة معلّقة','message','amber','بانتظار إجابتك'],['fav','المفضلة','heart','pink','رسائلك المحفوظة']] as [$key,$label,$glyph,$tone,$note]): ?>
      <div class="dashboard-stat"><div class="stat-top"><span><?=e($label)?></span><span class="dashboard-stat-icon <?=e($tone)?>"><?=icon($glyph)?></span></div><b><?=ar_num($c[$key])?></b><small><?=e($note)?></small></div>
      <?php endforeach; ?>
    </div>

    <?php if($flash) echo alert_box($flash[0],$flash[1]); ?>

<?php if(true): ?>
    <div class="push-card" id="pushCard" hidden>
      <div class="push-info"><span class="link-icon">🔔</span><div><b>إشعارات الموبايل</b><small id="pushText">الإشعارات مفعّلة تلقائيًا ليصلك تنبيه فور وصول رسالة جديدة.</small></div></div>
      <div class="push-actions"><button type="button" class="btn sm ghost" id="pushTest" hidden>إرسال تجربة</button></div>
    </div>
    <style>.push-card{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px 20px;margin-bottom:20px}.push-card[hidden]{display:none}.push-info{display:flex;align-items:center;gap:12px}.push-info small{display:block;color:var(--muted)}.push-actions{display:flex;gap:8px;flex-wrap:wrap}</style>
    <script>
    (function(){
      var card=document.getElementById('pushCard'),txt=document.getElementById('pushText'),test=document.getElementById('pushTest');
      var csrf=<?=json_encode(csrf())?>;
      var ios=/iphone|ipad|ipod/i.test(navigator.userAgent),standalone=window.matchMedia('(display-mode: standalone)').matches||navigator.standalone;
      card.hidden=false;
      if(!('serviceWorker' in navigator)||!('PushManager' in window)){
        txt.textContent=ios&&!standalone?'على الآيفون: اضغط زر المشاركة ثم «إضافة إلى الشاشة الرئيسية»، وافتح الموقع من الأيقونة لتعمل الإشعارات.':'متصفحك لا يدعم الإشعارات. جرّب Chrome أو Safari الحديث.';
        return;
      }
      function post(a,data){var f=new FormData();f.append('csrf',csrf);for(var k in data)f.append(k,data[k]);return fetch('push.php?a='+a,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()})}
      function keyBytes(b){b=b.replace(/-/g,'+').replace(/_/g,'/');b+='==='.slice((b.length+3)%4);var r=atob(b),a=new Uint8Array(r.length);for(var i=0;i<r.length;i++)a[i]=r.charCodeAt(i);return a}
      function state(sub){test.hidden=!sub;txt.textContent=sub?'الإشعارات مفعّلة على هذا الجهاز ✓':(Notification.permission==='denied'?'الإشعارات محظورة من إعدادات المتصفح، فعّلها من إعدادات الموقع لتصلك التنبيهات.':'جارٍ تفعيل الإشعارات تلقائيًا…')}
      function subscribe(reg){
        return Notification.requestPermission().then(function(p){if(p!=='granted')throw 0;return fetch('push.php?a=key',{credentials:'same-origin'}).then(function(r){return r.json()})})
        .then(function(k){return reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:keyBytes(k.key)})})
        .then(function(sub){var j=sub.toJSON();return post('sub',{endpoint:j.endpoint,p256dh:j.keys.p256dh,auth:j.keys.auth}).then(function(){state(sub)})})
        .catch(function(){state(null)});
      }
      navigator.serviceWorker.register('sw.js').then(function(reg){return reg.pushManager.getSubscription().then(function(sub){
        if(sub){var j=sub.toJSON();post('sub',{endpoint:j.endpoint,p256dh:j.keys.p256dh,auth:j.keys.auth});state(sub);}
        else subscribe(reg);
      })});
      test.onclick=function(){test.disabled=true;post('test',{}).then(function(r){txt.textContent=r.ok?'تم إرسال إشعار تجريبي، يجب أن يظهر خلال ثوانٍ.':'تعذّر الإرسال، أعد تحميل الصفحة.'}).finally(function(){test.disabled=false})};
    })();
    </script>
    <?php endif; ?>

<div class="dashboard-overview">
    <section class="dashboard-activity" aria-labelledby="activity-title">
      <div class="dashboard-activity-head">
        <div class="dashboard-activity-title"><span class="dashboard-activity-icon"><?=icon('inbox')?></span><span><h2 id="activity-title">الرسائل الواردة</h2><small>نشاط صندوقك خلال الأيام الماضية</small></span></div>
        <div class="dashboard-activity-actions"><div class="activity-range" role="group" aria-label="نطاق الرسم البياني"><button type="button" class="active" data-activity-range="7" aria-pressed="true">٧ أيام</button><button type="button" data-activity-range="30" aria-pressed="false">٣٠ يومًا</button></div></div>
      </div>
      <div class="dashboard-activity-body">
        <div class="activity-chart-card"><div class="activity-chart-head"><span><b>الرسائل الواردة</b><small>عدد الرسائل لكل يوم</small></span><strong id="activityTotal"><?=ar_num($activityTotal7)?><small>رسالة</small></strong></div>
          <div class="activity-chart-scroll"><div class="activity-chart week-chart" role="group" aria-label="عدد الرسائل اليومية خلال آخر ٣٠ يومًا">
            <?php foreach($activityDays as $day): $barHeight=$day['count']?max(12,round(($day['count']/$activityMax)*100)):3; ?>
            <span class="activity-bar-item" data-activity-age="<?=$day['age']?>" data-activity-count="<?=$day['count']?>" title="<?=e(ar_num(date('j/n',strtotime($day['date']))).' — '.ar_num($day['count']).' رسالة')?>"><span class="activity-bar-track"><span class="activity-bar<?= $day['count']?'':' quiet' ?>" style="height:<?=$barHeight?>%" role="img" aria-label="<?=e(ar_num(date('j/n',strtotime($day['date']))).' — '.ar_num($day['count']).' رسالة')?>"></span></span><span class="activity-axis-label"><?=($day['age']===0||$day['age']%5===0)?e(ar_num(date('j',strtotime($day['date'])))):'&nbsp;'?></span></span>
            <?php endforeach; ?>
          </div></div><p class="activity-chart-note"><span></span> إحصائياتك محسوبة من الرسائل الفعلية في حسابك.</p>
        </div>
        <aside class="activity-summary" aria-label="ملخص التفاعل"><div class="activity-metric"><span>إجمالي آخر ٧ أيام</span><strong><?=ar_num($activityTotal7)?></strong><small>رسالة واردة</small></div><div class="activity-separator"></div><div class="activity-metric"><span>معدل الإجابة</span><strong><?=ar_num($replyRate)?><small>٪</small></strong><span class="reply-progress" role="progressbar" aria-label="معدل الإجابة على الأسئلة" aria-valuenow="<?=$replyRate?>" aria-valuemin="0" aria-valuemax="100"><i style="width:<?=$replyRate?>%"></i></span><small><?=ar_num($c['published'])?> من <?=ar_num($c['questions'])?> سؤال تمت الإجابة عنه</small></div><a class="activity-pending-link" href="?f=pending"><?=icon('message')?> مراجعة الأسئلة المعلّقة <span aria-hidden="true">←</span></a></aside>
      </div>
    </section>

    <div class="link-card">
      <div class="link-info"><span class="link-icon"><?=icon('link')?></span><div><b>رابطك الشخصي</b><small>شاركه لوصول الرسائل إليك</small></div></div>
      <div class="link-row">
        <input id="mylink" class="link-input" readonly dir="ltr" value="<?=e($link)?>" aria-label="رابطك الخاص" onclick="this.select()">
        <button type="button" class="btn" data-copy="mylink"><?=icon('copy')?><span>نسخ الرابط</span></button>
      </div>
      <?=share_tools_html($link,$shareText)?>
    </div>

</div>
<div class="dashboard-mail-layout"><section class="dashboard-inbox" aria-labelledby="inbox-title"><div class="inbox-heading"><h2 id="inbox-title">صندوق الرسائل</h2><button type="button" class="btn ghost sm" data-export-csv <?=!$msgs?'disabled':''?>><?=icon('download')?> تصدير CSV</button></div>
    <div class="toolbar">
      <nav class="seg" aria-label="تصفية الرسائل">
        <a href="dashboard.php" class="<?= $filter==='all'?'active':'' ?>" <?= $filter==='all'?'aria-current="page"':'' ?>>كل الرسائل <span class="count"><?=ar_num($c['total'])?></span></a>
        <a href="?f=q" class="<?= $filter==='q'?'active':'' ?>" <?= $filter==='q'?'aria-current="page"':'' ?>>الأسئلة <span class="count"><?=ar_num($c['questions'])?></span></a>
        <a href="?f=pending" class="<?= $filter==='pending'?'active':'' ?>" <?= $filter==='pending'?'aria-current="page"':'' ?>>بانتظار الإجابة <span class="count"><?=ar_num($c['pending'])?></span></a>
        <a href="?f=published" class="<?= $filter==='published'?'active':'' ?>" <?= $filter==='published'?'aria-current="page"':'' ?>>منشورة <span class="count"><?=ar_num($c['published'])?></span></a>
        <a href="?f=fav" class="<?= $filter==='fav'?'active':'' ?>" <?= $filter==='fav'?'aria-current="page"':'' ?>>المفضلة <span class="count"><?=ar_num($c['fav'])?></span></a>
      </nav>
      <?php if($msgs): ?>
      <div class="dashboard-tools">
        <label class="dashboard-search" for="messageSearch"><?=icon('search')?><span class="sr-only">البحث في الرسائل</span><input id="messageSearch" type="search" placeholder="ابحث في رسائلك..." autocomplete="off"></label>
        <label class="dashboard-sort" for="messageSort"><span class="sr-only">ترتيب الرسائل</span><select id="messageSort"><option value="newest">الأحدث أولًا</option><option value="oldest">الأقدم أولًا</option></select></label>
        <span class="sr-only" id="dashboardExportStatus" role="status" aria-live="polite"></span>
      </div>
      <div class="dashboard-selection"><button type="button" class="btn ghost sm" data-select-visible>تحديد الرسائل الظاهرة</button><span data-selection-count aria-live="polite">لم يتم تحديد رسائل</span><button type="button" class="btn sm" data-export-selected disabled>تنزيل المحدد CSV</button></div>
      <?php endif; ?>
    </div>
    <?php if($msgs): ?><p class="dashboard-result-count" id="messageResultCount" aria-live="polite"><?=ar_num(count($msgs))?> رسالة</p><?php endif; ?>

    <?php if(!$msgs): ?>
      <div class="empty">
        <span class="empty-icon"><?=icon($filter==='q'||$filter==='pending'||$filter==='published'?'message':($filter==='fav'?'star':'inbox'))?></span>
        <h2><?= $filter==='q'?'لا توجد أسئلة بعد':($filter==='pending'?'لا توجد أسئلة تنتظر الإجابة':($filter==='published'?'لم تنشر إجابات بعد':($filter==='fav'?'لا توجد رسائل مفضلة':'صندوقك فارغ حاليًا'))) ?></h2>
        <p><?= $filter==='q'?'شارك رابطك لتبدأ باستقبال الأسئلة.':($filter==='pending'?'أجبت عن كل الأسئلة الحالية.':($filter==='published'?'أجب عن سؤال ليظهر هنا وعلى صفحتك العامة.':($filter==='fav'?'اضغط على النجمة في أي رسالة لحفظها هنا.':'انسخ رابطك وشاركه مع أصحابك، وستظهر رسائلهم هنا.'))) ?></p>
        <?php if($filter==='all'): ?><button type="button" class="btn" data-copy="mylink"><?=icon('copy')?><span>نسخ الرابط</span></button><?php endif; ?>
      </div>
    <?php else: ?>
    <div class="msg-grid" id="messageGrid">
      <?php foreach($msgs as $m): $mid=(int)$m['id']; ?>
      <article class="msg<?= $m['is_favorite']?' fav':'' ?><?= !empty($m['is_question'])?' question-msg':'' ?>" data-search="<?=e(mb_strtolower(trim(($m['body']??'').' '.($m['answer']??'').' '.(!empty($m['is_question'])?'سؤال':''))))?>" data-created="<?=e(strtotime($m['created_at']))?>">
        <header class="msg-top"><label class="msg-select"><input type="checkbox" data-message-select aria-label="تحديد هذه الرسالة"><span class="sr-only">تحديد هذه الرسالة</span></label>
          <span class="anon"><span class="anon-dot"><?=icon('eye-off')?></span> مجهول<?php if(!empty($m['is_question'])): ?> <span class="q-tag">سؤال</span><?php endif; ?></span>
          <time datetime="<?=e($m['created_at'])?>" title="<?=e($m['created_at'])?>"><?=ago($m['created_at'])?></time>
        </header>
        <?php if(!empty($m['audio_path'])): ?><div class="msg-voice"><span class="msg-voice-tag"><?=icon('mic')?> رسالة صوتية</span><div class="vplayer" data-src="voice.php?id=<?=$mid?>" data-secs="<?=(int)$m['audio_secs']?>"></div></div><?php endif; ?>
        <?php if(empty($m['audio_path']) || $m['body']!=='🎙️ رسالة صوتية'): ?><p class="msg-body"><?=e($m['body'])?></p><?php endif; ?>
        <?php if($insOn && isset($metaMap[$mid])) echo insights_html($metaMap[$mid]); elseif(!$insOn) echo insights_locked_html(); ?>
        <?php if(!empty($m['is_question'])): ?>
        <details class="answer-area" <?= $m['answer']!==null?'open':'' ?>><summary class="answer-toggle"><?=icon('message')?> <?= $m['answer']!==null?'إجابتك المنشورة':'الرد على السؤال' ?> <?=icon('chevron')?></summary>
          <div class="answer-state <?= $m['answer']!==null?'published':'private' ?>"><?=icon($m['answer']!==null?'eye':'lock')?> <span><?= $m['answer']!==null?'منشور للجميع':'خاص — لن يظهر إلا بعد إجابتك' ?></span></div>
          <form method="post" class="answer-form form" id="answer-<?=$mid?>"><?=csrf_field()?><input type="hidden" name="id" value="<?=$mid?>">
            <label for="reply-<?=$mid?>"><?= $m['answer']!==null?'تعديل إجابتك':'اكتب إجابتك' ?></label>
            <textarea id="reply-<?=$mid?>" name="answer" rows="3" minlength="2" maxlength="2000" required placeholder="إجابتك هنا..." aria-describedby="answer-hint-<?=$mid?>"><?=e($m['answer']??'')?></textarea>
            <p class="answer-hint" id="answer-hint-<?=$mid?>">سيرى الجميع السؤال والإجابة على صفحتك بمجرد النشر، دون اسم المرسل.</p>
            <div class="answer-controls"><button class="btn sm" name="action" value="answer"><?=icon($m['answer']!==null?'check':'send')?> <?= $m['answer']!==null?'حفظ التعديل':'نشر الإجابة' ?></button>
              <?php if($m['answer']!==null): ?><button class="btn ghost sm unpublish-btn" type="submit" name="action" value="unpublish" formnovalidate onclick="return confirm('إخفاء السؤال والجواب من صفحتك العامة؟')"><?=icon('eye-off')?> إخفاء من الصفحة</button><?php endif; ?>
            </div>
          </form>
        </details>
        <?php endif; ?>
        <footer class="msg-actions">
          <form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=$mid?>">
            <button class="act<?= $m['is_favorite']?' on':'' ?>" name="action" value="fav" aria-pressed="<?= $m['is_favorite']?'true':'false' ?>"><?=icon('star')?><span><?= $m['is_favorite']?'في المفضلة':'مفضلة' ?></span></button></form>
          <details class="report">
            <summary class="act"><?=icon('flag')?><span>إبلاغ</span></summary>
            <form method="post" class="report-pop form"><?=csrf_field()?><input type="hidden" name="id" value="<?=$mid?>">
              <b>الإبلاغ عن رسالة</b>
              <select name="reason" aria-label="سبب البلاغ"><option value="harassment">تحرش أو إساءة</option><option value="threat">تهديد</option><option value="spam">إزعاج أو سبام</option><option value="other">سبب آخر</option></select>
              <input name="details" placeholder="تفاصيل إضافية (اختياري)" maxlength="500" aria-label="تفاصيل البلاغ">
              <button class="btn sm danger block" name="action" value="report">إرسال البلاغ</button>
            </form>
          </details>
          <form method="post" class="inline push" onsubmit="return confirm('هل تريد حذف هذه الرسالة نهائيًا؟')"><?=csrf_field()?><input type="hidden" name="id" value="<?=$mid?>">
            <button class="act danger" name="action" value="del" aria-label="حذف الرسالة"><?=icon('trash')?><span>حذف</span></button></form>
        </footer>
      </article>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

</section><aside class="dashboard-favorites" aria-labelledby="favorites-title"><div class="inbox-heading"><h2 id="favorites-title"><?=icon('heart')?> أبرز المفضلة</h2><a href="?f=fav" class="favorites-all">عرض الكل <?=icon('arrow')?></a></div>
<?php if($featuredFavorites): foreach($featuredFavorites as $favorite): ?>
<article class="favorite-preview"><span class="favorite-mark"><?=icon('heart')?></span><p><?=e(mb_strimwidth($favorite['body']??'',0,240,'…','UTF-8'))?></p><small><?=ago($favorite['created_at'])?></small></article>
<?php endforeach; else: ?><div class="favorites-empty"><?=icon('heart')?><p>لم تحفظ رسائل بعد</p><small>رسائلك المفضلة ستظهر هنا</small></div><?php endif; ?>
<div class="dashboard-privacy"><?=icon('shield')?><span>مساحتك الخاصة<small>هوية المرسل تبقى مجهولة</small></span></div></aside></div>
  </div>
</section>
<script src="voice-player.js" defer></script>
<script src="dashboard.js" defer></script>
<?php foot();
