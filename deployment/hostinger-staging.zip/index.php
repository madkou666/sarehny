<?php require 'inc.php'; $u=me(); head('رسائل مجهولة بصدق','home');
$cta=$u?'dashboard.php':'auth.php'; $ctaText=$u?'افتح صندوق رسائلك':'أنشئ رابطك الآن';
?>
<section class="hero">
 <div class="wrap hero-in">
  <div class="hero-copy">
   <span class="pill"><span class="live-dot"></span> مساحة للكلام الصادق · اسم المرسل لا يظهر تلقائيًا</span>
   <h1><?=e(setting('home_title','مساحة للكلام الذي لم يُقَل'))?></h1>
   <p class="lead"><?=e(setting('home_lead','أنشئ رابطك الخاص، شاركه مع من تحب، واستقبل كلماتهم الصادقة في صندوق لا يراه سواك.'))?></p>
   <div class="hero-link"><div class="hero-link-row"><div class="hero-link-display" dir="ltr"><span><?=e(parse_url(base_url(), PHP_URL_HOST) ?: 'your-site.com')?>/u.php?n=</span><strong>your_name</strong><i>_</i></div><a class="btn" href="<?=e($cta)?>"><?=e($ctaText)?> <?=icon('arrow')?></a></div><p>إنشاء الرابط يتطلب حسابًا مجانيًا وبريدًا إلكترونيًا.</p></div>
   <ul class="hero-points"><li><span class="point magenta"></span>اسم المرسل لا يظهر في الرسالة</li><li><span class="point amber"></span>إبلاغ عن الرسائل المسيئة</li><li><span class="point volt"></span>تحكم كامل بصندوقك</li></ul>
  </div>
  <div class="hero-visual" aria-label="مثال لصندوق الرسائل">
   <div class="mock"><div class="mock-head"><span>INBOX <span class="mock-ar">· صندوق الوارد</span></span><span class="mock-badge">رسائل مجهولة</span></div>
    <div class="mock-msg"><span class="mock-avatar">م</span><div><p>شكرًا على مساعدتك في المشروع، كان يعني لي الكثير.</p><small>مجهول · الآن</small></div><span class="unread-dot"></span></div>
    <div class="mock-msg pink"><span class="mock-avatar">م</span><div><p>كان ودي أقول لك الكلام هذا من زمان، أنت شخص رائع.</p><small>مجهول · منذ ٤ دقائق</small></div></div>
    <div class="mock-msg gold"><span class="mock-avatar">م</span><div><p>أتمنى تكمّل في الرسم، موهبتك تستحق أن يراها العالم.</p><small>مجهول · أمس</small></div></div>
    <div class="mock-foot"><span>صندوق الرسائل لصاحب الرابط</span><span><?=icon('lock')?> خاص وآمن</span></div>
   </div>
  </div>
 </div>
</section>
<section class="home-editorial"><div class="wrap home-editorial-in"><div><span class="content-kicker">مساحة آمنة، وكلام حقيقي</span><h2>بعض الكلام يحتاج مساحة مختلفة.</h2></div><div><p>الأشياء الجميلة التي نخجل من قولها، والأسئلة التي نبحث لها عن إجابة، والرسائل التي انتظرت طويلًا. أسرار يمنحها طريقًا إليك.</p><a class="text-link" href="about.php">اعرف أكثر عن أسرار <?=icon('arrow')?></a></div></div></section>
<section class="home-features" id="features" aria-labelledby="home-features-title"><div class="wrap">
 <div class="home-features-head"><div><span class="content-kicker">أكثر من مجرد صندوق رسائل</span><h2 id="home-features-title">كل شيء تحتاجه لتواصل أصدق.</h2></div><p>مزايا عملية تمنحك طرقًا مختلفة للتعبير، مع إعدادات تظل بين يديك.</p></div>
 <div class="home-feature-grid">
  <article class="home-feature-card"><span class="home-feature-icon mint"><?=icon('message')?></span><h3>رسائل وأسئلة مجهولة</h3><p>استقبل كلمات صادقة وأسئلة من أصحاب رابطك، من دون أن يحتاجوا إلى إنشاء حساب.</p></article>
  <article class="home-feature-card"><span class="home-feature-icon violet"><?=icon('mic')?></span><h3>رسائل صوتية بنبرة مختلفة</h3><p>أرسل رسالة صوتية مع مؤثرات تُطبّق محليًا أثناء التسجيل قبل إرسال الملف.</p></article>
  <article class="home-feature-card"><span class="home-feature-icon blue"><?=icon('share')?></span><h3>رابط سهل المشاركة</h3><p>شارك رابط ملفك مباشرة أو استخدم رمز QR لتسهيل الوصول إلى صفحة الإرسال.</p></article>
  <article class="home-feature-card"><span class="home-feature-icon rose"><?=icon('heart')?></span><h3>صندوق رسائل منظم</h3><p>احفظ الرسائل المفضلة، واحذف أو أبلغ عن الرسائل غير المناسبة.</p></article>
  <article class="home-feature-card"><span class="home-feature-icon amber"><?=icon('grid')?></span><h3>مظهر يناسبك</h3><p>اختر من القوالب اللونية المتاحة، مع إعدادات إضافية للمظهر من لوحة الإدارة.</p></article>
  <article class="home-feature-card"><span class="home-feature-icon slate"><?=icon('shield')?></span><h3>إعدادات وإشراف واضحان</h3><p>تحكّم في استقبال الرسائل وراجع البلاغات من حسابك أو لوحة الإدارة.</p></article>
 </div>
 <div class="home-features-note"><?=icon('settings')?><p><strong>إعداداتك الحالية محفوظة.</strong> خصائص التسجيل والرسائل والمظهر والإشراف تظل قابلة للإدارة من لوحة التحكم.</p></div>
 </div></section>
<section class="trust-strip" id="how"><div class="wrap trust-grid">
 <article><span class="trust-number">01 / PRIVACY</span><h2>اسم المرسل لا يظهر تلقائيًا</h2><p>الرسائل العادية لا تعرض اسم المرسل لصاحب الرابط. قد تختلف البيانات المتاحة عند تفعيل أدوات تحليل اختيارية.</p></article>
 <article><span class="trust-number">02 / INBOX</span><h2>كل رسائلك في مكان واحد</h2><p>أنشئ رابطك وشاركه بسهولة، ثم اقرأ الرسائل في صندوق خاص لا يفتحه سواك.</p></article>
 <article><span class="trust-number">03 / CONTROL</span><h2>التحكم بين يديك</h2><p>احفظ الرسائل المفضلة، احذف ما لا تريد، وبلّغ عن أي إساءة لتُراجع.</p></article>
</div></section>
<?=ad_slot('content')?>
<section class="faq-band" id="faq"><div class="wrap faq-layout"><div><span class="trust-number">الأسئلة الشائعة</span><h2>عندك سؤال؟</h2><p>إجابات سريعة قبل ما تبدأ.</p><a class="btn" href="<?=e($cta)?>"><?=e($ctaText)?> <?=icon('arrow')?></a></div><div class="faq-list">
 <details><summary>هل تظهر هويتي لمن أرسلت له رسالة؟</summary><p>في الرسائل العادية لا يظهر اسمك لصاحب الرابط. قد تظهر بيانات إضافية إذا فعّل الموقع ميزة تحليل المرسل؛ راجع سياسة الخصوصية قبل الإرسال.</p></details>
 <details><summary>كيف أشارك رابطي؟</summary><p>بعد إنشاء الحساب ستجد رابطك في أعلى صندوق الرسائل. انسخه وشاركه أينما تريد.</p></details>
 <details><summary>ماذا أفعل مع رسالة مسيئة؟</summary><p>يمكنك حذفها أو الإبلاغ عنها لمراجعتها من فريق الإشراف.</p></details>
 <details><summary>هل الخدمة مجانية؟</summary><p>نعم، إنشاء الحساب واستقبال الرسائل مجاني.</p></details>
</div></div></section>
<section class="home-journal"><div class="wrap"><div class="content-section-head"><div><span class="content-kicker">من المدونة</span><h2>أفكار وكلمات من أسرار</h2></div><a class="text-link" href="blog.php">جميع المقالات <?=icon('arrow')?></a></div><div class="post-grid"><?php $latest=$pdo->query('SELECT id,title,excerpt,body,created_at FROM blog_posts WHERE published=1 ORDER BY created_at DESC,id DESC LIMIT 3')->fetchAll();if($latest):foreach($latest as $post): ?><article class="post-card"><span class="content-kicker"><?=e(date('Y/m/d',strtotime($post['created_at'])))?></span><h3><a href="post.php?id=<?=(int)$post['id']?>"><?=e($post['title'])?></a></h3><p><?=e($post['excerpt']!==''?$post['excerpt']:mb_substr($post['body'],0,120).'…')?></p><a class="text-link" href="post.php?id=<?=(int)$post['id']?>">اقرأ المقال <?=icon('arrow')?></a></article><?php endforeach;else: ?><div class="content-empty"><h3>القصص قادمة قريبًا</h3><p>تابع مدونتنا لأفكار جديدة عن التواصل والكلام الصادق.</p></div><?php endif; ?></div></div></section>
<section class="home-final"><div class="wrap"><span class="content-kicker">البداية عندك</span><h2>اسمع ما يريدون قوله لك.</h2><p>رابط واحد يفتح باب الكلام.</p><a class="btn" href="<?=e($cta)?>"><?=e($ctaText)?> <?=icon('arrow')?></a></div></section>
<?php foot(); ?>
