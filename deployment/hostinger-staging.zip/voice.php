<?php require 'inc.php';
// يقدّم الرسائل الصوتية لصاحب الصندوق فقط (أو المشرف)
$u=me(); $id=(int)($_GET['id']??0);
if(!$u||$id<1){ http_response_code(403); exit; }
$s=$pdo->prepare('SELECT recipient_id,audio_path FROM messages WHERE id=?'); $s->execute([$id]); $m=$s->fetch();
$isAdmin=!empty($u['is_admin']);
if(!$m||!$m['audio_path']||((int)$m['recipient_id']!==(int)$u['id']&&!$isAdmin)){ http_response_code(404); exit; }
if(!preg_match('/^[a-f0-9]{32}\.(webm|ogg|m4a|mp3|wav)$/',$m['audio_path'],$mm)){ http_response_code(404); exit; }
$path=__DIR__.'/uploads/voice/'.$m['audio_path']; if(!is_file($path)){ http_response_code(404); exit; }
$types=['webm'=>'audio/webm','ogg'=>'audio/ogg','m4a'=>'audio/mp4','mp3'=>'audio/mpeg','wav'=>'audio/wav'];
$size=filesize($path); $start=0; $end=$size-1;
header('Content-Type: '.$types[$mm[1]]); header('Accept-Ranges: bytes'); header('Cache-Control: private, max-age=3600'); header('X-Content-Type-Options: nosniff');
if(isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/',$_SERVER['HTTP_RANGE'],$r)){
  if($r[1]!=='') $start=(int)$r[1]; if($r[2]!=='') $end=min((int)$r[2],$size-1); if($r[1]===''&&$r[2]!==''){ $start=max(0,$size-(int)$r[2]); $end=$size-1; }
  if($start>$end){ http_response_code(416); header("Content-Range: bytes */$size"); exit; }
  http_response_code(206); header("Content-Range: bytes $start-$end/$size");
}
header('Content-Length: '.($end-$start+1));
$f=fopen($path,'rb'); fseek($f,$start); $left=$end-$start+1; while($left>0&&!feof($f)){ $chunk=fread($f,min(65536,$left)); echo $chunk; $left-=strlen($chunk); } fclose($f);
