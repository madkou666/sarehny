<?php require 'inc.php';
header('Content-Type: application/manifest+json; charset=utf-8');
$icons=[]; if($l=logo_url()) foreach(['192x192','512x512'] as $s) $icons[]=['src'=>$l,'sizes'=>$s,'purpose'=>'any'];
echo json_encode(['name'=>site_name(),'short_name'=>mb_substr(site_name(),0,12),'start_url'=>'dashboard.php','scope'=>'./','display'=>'standalone','dir'=>'rtl','lang'=>'ar','background_color'=>theme_color('bg'),'theme_color'=>theme_color('bg'),'icons'=>$icons],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
