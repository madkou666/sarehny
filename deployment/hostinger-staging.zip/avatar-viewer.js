/* Shared, accessible viewer for original uploaded profile photos. */
(function () {
  document.addEventListener('click', function (event) {
    var open = event.target.closest('[data-avatar-open]');
    if (open) {
      var dialog = open.closest('main').querySelector('.avatar-dialog');
      if (dialog && !dialog.open) dialog.showModal();
      return;
    }
    var close = event.target.closest('[data-avatar-close]');
    if (close) close.closest('dialog').close();
  });
  document.querySelectorAll('.avatar-dialog').forEach(function (dialog) {
    dialog.addEventListener('click', function (event) {
      if (event.target === dialog) dialog.close();
    });
  });
})();
