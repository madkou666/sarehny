<?php defined('IN_ADMIN') || exit;
$words=$pdo->query('SELECT * FROM banned_words ORDER BY word')->fetchAll();
?>
<div class="adm-head">
  <div><h1>فلتر الكلمات</h1><p class="muted">أي رسالة تحتوي على كلمة من هذه القائمة سيتم رفضها تلقائيًا قبل وصولها.</p></div>
</div>

<div class="adm-grid-2">
  <section class="card" aria-labelledby="add-w">
    <div class="card-head"><h2 id="add-w">إضافة كلمات</h2></div>
    <form method="post" class="form pad"><?=csrf_field()?><input type="hidden" name="action" value="addwords">
      <div class="field"><label for="words">الكلمات المحظورة</label>
        <textarea id="words" name="words" rows="5" required placeholder="اكتب كل كلمة في سطر، أو افصل بينها بفاصلة"></textarea>
        <small class="hint">المطابقة لا تفرّق بين الأحرف الكبيرة والصغيرة، وتشمل الكلمة إذا وردت داخل كلمة أخرى.</small></div>
      <button class="btn"><?=icon('plus')?> إضافة إلى القائمة</button>
    </form>
  </section>

  <section class="card" aria-labelledby="list-w">
    <div class="card-head"><h2 id="list-w">القائمة الحالية</h2><span class="tag"><?=ar_num(count($words))?> كلمة</span></div>
    <?php if(!$words): ?>
      <div class="empty flat"><span class="empty-icon"><?=icon('filter')?></span><h2>القائمة فارغة</h2><p>أضف كلمات لمنع وصول الرسائل المسيئة.</p></div>
    <?php else: ?>
    <ul class="word-chips">
      <?php foreach($words as $w): ?>
      <li><span><?=e($w['word'])?></span>
        <form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$w['id']?>"><button class="chip-x" name="action" value="delword" aria-label="حذف الكلمة <?=e($w['word'])?>"><?=icon('x')?></button></form></li>
      <?php endforeach; ?>
    </ul>
    <?php endif; ?>
  </section>
</div>
