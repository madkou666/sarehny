<?php defined('IN_ADMIN') || exit;
$filters=['all'=>'الكل','visible'=>'ظاهرة','hidden'=>'مخفية','reported'=>'عليها بلاغات'];
if(!isset($filters[$f])) $f='all';
$media=in_array($_GET['media']??'',['all','voice','text'],true)?$_GET['media']:'all';
$period=in_array($_GET['period']??'',['all','today','week','month'],true)?$_GET['period']:'all';
$favorite=($_GET['favorite']??'')==='1';
$sort=in_array($_GET['sort']??'',['newest','oldest','reports'],true)?$_GET['sort']:'newest';
$sq='%'.$q.'%'; $where=['(m.body LIKE ? OR u.username LIKE ? OR u.display_name LIKE ?)']; $params=[$sq,$sq,$sq];
if($f==='visible') $where[]='m.is_removed=0'; if($f==='hidden') $where[]='m.is_removed=1';
if($f==='reported') $where[]='EXISTS(SELECT 1 FROM reports r WHERE r.message_id=m.id)';
if($media==='voice') $where[]="m.audio_path IS NOT NULL AND m.audio_path<>''"; elseif($media==='text') $where[]="(m.audio_path IS NULL OR m.audio_path='')";
if($favorite) $where[]='m.is_favorite=1';
$periodDays=['today'=>1,'week'=>7,'month'=>30];
if(isset($periodDays[$period]))$where[]='m.created_at>=DATE_SUB(NOW(), INTERVAL '.$periodDays[$period].' DAY)';
$w=implode(' AND ',$where); $per=20;
$total=$one("SELECT COUNT(*) FROM messages m JOIN users u ON u.id=m.recipient_id WHERE $w",$params);
$sortSql=['newest'=>'m.id DESC','oldest'=>'m.id ASC','reports'=>'rc DESC,m.id DESC'][$sort];
$s=$pdo->prepare("SELECT m.*,u.username,u.display_name,(SELECT COUNT(*) FROM reports r WHERE r.message_id=m.id) rc,(SELECT 1 FROM sender_bans b WHERE b.ip_hash=m.sender_ip_hash) banned FROM messages m JOIN users u ON u.id=m.recipient_id WHERE $w ORDER BY $sortSql LIMIT $per OFFSET ".(($page-1)*$per));
$s->execute($params); $rows=$s->fetchAll();
$metaMap=$rows?load_meta($pdo,array_column($rows,'id')):[];
$counts=['all'=>$one('SELECT COUNT(*) FROM messages'),'visible'=>$one('SELECT COUNT(*) FROM messages WHERE is_removed=0'),'hidden'=>$one('SELECT COUNT(*) FROM messages WHERE is_removed=1'),'reported'=>$one('SELECT COUNT(DISTINCT message_id) FROM reports')];
$voiceCount=$one("SELECT COUNT(*) FROM messages WHERE audio_path IS NOT NULL AND audio_path<>''");
$favCount=$one('SELECT COUNT(*) FROM messages WHERE is_favorite=1');
$base=['t'=>'messages','f'=>$f==='all'?'':$f,'q'=>$q,'media'=>$media==='all'?'':$media,'period'=>$period==='all'?'':$period,'favorite'=>$favorite?'1':'','sort'=>$sort==='newest'?'':$sort];
?>
<div class="adm-head message-page-head">
  <div><span class="message-eyebrow"><?=icon('inbox')?> مركز الرسائل</span><h1>إدارة الرسائل</h1><p class="muted">تابع الرسائل والبلاغات والتسجيلات، ونظّمها من مكان واحد.</p></div>
  <form method="post" class="message-export"><?=csrf_field()?>
    <input type="hidden" name="action" value="export"><input type="hidden" name="what" value="messages">
    <input type="hidden" name="f" value="<?=$f==='all'?'':e($f)?>"><input type="hidden" name="q" value="<?=e($q)?>">
    <input type="hidden" name="media" value="<?=$media==='all'?'':e($media)?>"><input type="hidden" name="period" value="<?=$period==='all'?'':e($period)?>">
    <input type="hidden" name="favorite" value="<?=$favorite?'1':''?>"><input type="hidden" name="sort" value="<?=e($sort)?>">
    <button class="btn sm ghost"><?=icon('download')?> تصدير النتائج CSV</button>
  </form>
</div>

<div class="message-stats" aria-label="ملخص الرسائل">
  <div class="message-stat-card"><span class="message-stat-icon tone-blue"><?=icon('inbox')?></span><span class="message-stat-copy"><span>إجمالي الرسائل</span><b><?=ar_num(number_format($counts['all']))?></b></span></div>
  <div class="message-stat-card"><span class="message-stat-icon tone-violet"><?=icon('mic')?></span><span class="message-stat-copy"><span>رسائل صوتية</span><b><?=ar_num(number_format($voiceCount))?></b></span></div>
  <div class="message-stat-card"><span class="message-stat-icon tone-amber"><?=icon('star')?></span><span class="message-stat-copy"><span>رسائل مفضلة</span><b><?=ar_num(number_format($favCount))?></b></span></div>
  <div class="message-stat-card"><span class="message-stat-icon tone-red"><?=icon('flag')?></span><span class="message-stat-copy"><span>عليها بلاغات</span><b><?=ar_num(number_format($counts['reported']))?></b></span></div>
</div>

<div class="toolbar-adm">
  <nav class="chips message-tabs" aria-label="تصفية الرسائل">
    <?php $filterIcons=['all'=>'inbox','visible'=>'eye','hidden'=>'eye-off','reported'=>'flag']; foreach($filters as $k=>$l): ?><a href="<?=e(admin_url(array_merge($base,['f'=>$k==='all'?'':$k,'p'=>''])))?>" class="<?=$f===$k?'on':''?>" <?=$f===$k?'aria-current="true"':''?>><?=icon($filterIcons[$k])?><?=$l?> <span><?=ar_num($counts[$k])?></span></a><?php endforeach; ?>
  </nav>
  <form class="search" role="search"><input type="hidden" name="t" value="messages"><?php if($f!=='all'): ?><input type="hidden" name="f" value="<?=e($f)?>"><?php endif; ?>
    <?php if($media!=='all'): ?><input type="hidden" name="media" value="<?=e($media)?>"><?php endif; ?><?php if($period!=='all'): ?><input type="hidden" name="period" value="<?=e($period)?>"><?php endif; ?>
    <?php if($favorite): ?><input type="hidden" name="favorite" value="1"><?php endif; ?><?php if($sort!=='newest'): ?><input type="hidden" name="sort" value="<?=e($sort)?>"><?php endif; ?>
    <?=icon('search')?><input name="q" aria-label="بحث في الرسائل" placeholder="ابحث في النص أو اسم المستلم" value="<?=e($q)?>">
  </form>
</div>
<form class="message-filters" method="get" aria-label="خيارات التصفية المتقدمة">
  <input type="hidden" name="t" value="messages"><?php if($f!=='all'): ?><input type="hidden" name="f" value="<?=e($f)?>"><?php endif; ?><?php if($q!==''): ?><input type="hidden" name="q" value="<?=e($q)?>"><?php endif; ?>
  <div class="message-filters-heading"><span class="message-filter-heading-icon"><?=icon('filter')?></span><span><b>تصفية النتائج</b><small>خصص عرض الرسائل حسب النوع والفترة</small></span></div>
  <label><span class="message-filter-label"><?=icon('grid')?>نوع الرسالة</span><select name="media"><option value="all" <?=$media==='all'?'selected':''?>>كل الأنواع</option><option value="text" <?=$media==='text'?'selected':''?>>نصية</option><option value="voice" <?=$media==='voice'?'selected':''?>>صوتية</option></select></label>
  <label><span class="message-filter-label"><?=icon('clock')?>الفترة</span><select name="period"><option value="all" <?=$period==='all'?'selected':''?>>كل الفترات</option><option value="today" <?=$period==='today'?'selected':''?>>آخر ٢٤ ساعة</option><option value="week" <?=$period==='week'?'selected':''?>>آخر ٧ أيام</option><option value="month" <?=$period==='month'?'selected':''?>>آخر ٣٠ يومًا</option></select></label>
  <label><span class="message-filter-label"><?=icon('star')?>المفضلة</span><select name="favorite"><option value="" <?=$favorite?'':'selected'?>>الكل</option><option value="1" <?=$favorite?'selected':''?>>المفضلة فقط</option></select></label>
  <label><span class="message-filter-label"><?=icon('activity')?>ترتيب النتائج</span><select name="sort"><option value="newest" <?=$sort==='newest'?'selected':''?>>الأحدث أولًا</option><option value="oldest" <?=$sort==='oldest'?'selected':''?>>الأقدم أولًا</option><option value="reports" <?=$sort==='reports'?'selected':''?>>الأكثر بلاغًا</option></select></label>
  <div class="message-filter-actions"><button class="btn sm"><?=icon('filter')?> تطبيق</button><a class="btn sm ghost" href="<?=e(admin_url(['t'=>'messages']))?>">إعادة ضبط</a></div>
</form>

<?php if(!$rows): ?>
  <div class="empty"><span class="empty-icon"><?=icon('message')?></span><h2>لا توجد رسائل</h2><p>لم يتم العثور على رسائل مطابقة لهذه الفلاتر. جرّب تعديل البحث أو خيارات التصفية.</p></div>
<?php else: ?>
<form method="post" id="bulk-form"><?=csrf_field()?><input type="hidden" name="action" value="bulk"></form>
<section class="card message-list-card">
  <div class="message-list-heading"><span class="message-list-heading-icon"><?=icon('message')?></span><span><b>سجل الرسائل</b><small>تصفح الرسائل واتخذ الإجراء المناسب</small></span><span class="message-results-count"><?=icon('inbox')?><?=ar_num(number_format($total))?> رسالة</span></div>
  <div class="list-head">
    <label class="check"><input type="checkbox" data-check-all aria-label="تحديد كل الرسائل في الصفحة"><span>تحديد الكل <span class="muted sm">(<?=ar_num(count($rows))?> في هذه الصفحة)</span></span></label>
    <div class="bulk-bar" id="bulk-bar" aria-live="polite">
      <span class="muted sm">المحدد: <b id="bulk-count">0</b></span>
      <span class="bulk-bar-feedback" id="bulk-feedback"></span>
      <button type="button" class="btn xs ghost" data-copy-selected><?=icon('copy')?> نسخ النصوص</button>
      <button class="btn xs ghost" form="bulk-form" name="bulk_op" value="export"><?=icon('download')?> تصدير المحدد CSV</button>
      <button class="btn xs ghost" form="bulk-form" name="bulk_op" value="hide"><?=icon('eye-off')?> إخفاء</button>
      <button class="btn xs ghost" form="bulk-form" name="bulk_op" value="restore"><?=icon('eye')?> استعادة</button>
      <button class="btn xs danger-soft" form="bulk-form" name="bulk_op" value="delete" data-confirm="حذف الرسائل المحددة نهائيًا؟"><?=icon('trash')?> حذف</button>
    </div>
  </div>
  <div class="table-wrap message-table-wrap">
    <table class="adm-table message-adm-table">
      <thead><tr><th scope="col"><span class="sr-only">تحديد</span></th><th scope="col">محتوى الرسالة</th><th scope="col">المستلم</th><th scope="col">النوع</th><th scope="col">الحالة</th><th scope="col">وقت الإرسال</th><th scope="col"><span class="sr-only">الإجراءات</span></th></tr></thead>
      <tbody>
      <?php foreach($rows as $m): $mid=(int)$m['id']; ?>
        <tr class="message-table-row<?=$m['is_removed']?' is-hidden':''?><?=!empty($m['audio_path'])?' has-voice':''?><?=$m['rc']?' has-reports':''?>">
          <td class="message-select-cell"><input type="checkbox" name="ids[]" value="<?=$mid?>" form="bulk-form" aria-label="تحديد الرسالة رقم <?=ar_num($mid)?>"></td>
          <td data-label="محتوى الرسالة" class="message-content-cell">
            <div class="message-table-id"><span class="message-id">#<?=ar_num($mid)?></span><span><?=icon('message')?> محتوى الرسالة</span></div>
            <p class="message-table-body"><?=e($m['body'])?></p>
            <details class="message-insights"><summary><?=icon('activity')?> بيانات إضافية عن المرسل</summary><?php if(isset($metaMap[$mid])): ?><?=insights_html($metaMap[$mid])?><?php else: ?><p class="muted sm">بيانات تحليل المرسل غير متاحة لهذه الرسالة.</p><?php endif; ?></details>
          </td>
          <td data-label="المستلم" class="message-recipient-cell"><span class="message-recipient-name"><?=icon('user')?><?=e($m['display_name'])?></span><span class="message-recipient-handle" dir="ltr">@<?=e($m['username'])?></span></td>
          <td data-label="نوع الرسالة" class="message-type-cell">
            <?php if(!empty($m['audio_path'])): ?><span class="message-type-badge voice"><?=icon('mic')?> صوتية</span><audio class="message-table-audio" controls preload="none" src="voice.php?id=<?=$mid?>" aria-label="تشغيل التسجيل الصوتي للرسالة رقم <?=ar_num($mid)?>"></audio>
            <?php else: ?><span class="message-type-badge text"><?=icon('message')?> نصية</span><?php endif; ?>
          </td>
          <td data-label="الحالة" class="message-status-cell"><div class="message-status-list">
            <?php if($m['is_removed']): ?><span class="tag red">مخفية</span><?php else: ?><span class="tag green">ظاهرة</span><?php endif; ?>
            <?php if($m['rc']): ?><span class="tag amber"><?=ar_num($m['rc'])?> بلاغ</span><?php endif; ?>
            <?php if($m['is_favorite']): ?><span class="tag violet">مفضلة</span><?php endif; ?>
            <?php if($m['banned']): ?><span class="tag gray">المرسل محظور</span><?php endif; ?>
          </div></td>
          <td data-label="وقت الإرسال" class="message-date-cell"><span><?=icon('clock')?><time datetime="<?=e($m['created_at'])?>" title="<?=e($m['created_at'])?>"><?=ago($m['created_at'])?></time></span></td>
          <td data-label="الإجراءات" class="message-actions-cell">
            <form method="post" class="row-actions end"><?=csrf_field()?><input type="hidden" name="id" value="<?=$mid?>">
              <button type="button" class="btn xs ghost" data-copy="<?=e($m['body'])?>" aria-label="نسخ نص الرسالة رقم <?=ar_num($mid)?>" title="نسخ نص الرسالة"><?=icon('copy')?><span>نسخ</span></button>
              <?php if($m['is_removed']): ?><button class="btn xs ghost" name="action" value="restore" aria-label="استعادة الرسالة رقم <?=ar_num($mid)?>"><?=icon('eye')?> <span>استعادة</span></button>
              <?php else: ?><button class="btn xs ghost" name="action" value="hide" aria-label="إخفاء الرسالة رقم <?=ar_num($mid)?>"><?=icon('eye-off')?> <span>إخفاء</span></button><?php endif; ?>
              <?php if($m['sender_ip_hash'] && !$m['banned']): ?><button class="btn xs ghost" name="action" value="bansender" data-confirm="حظر مرسل هذه الرسالة من إرسال أي رسائل جديدة؟" aria-label="حظر مرسل الرسالة رقم <?=ar_num($mid)?>"><?=icon('ban')?> <span>حظر</span></button><?php endif; ?>
              <button class="btn xs danger-soft" name="action" value="delmsg" data-confirm="حذف الرسالة نهائيًا؟" aria-label="حذف الرسالة رقم <?=ar_num($mid)?>" title="حذف الرسالة"><?=icon('trash')?></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?=pager($total,$per,$page,$base)?>
</section>
<?php endif; ?>
