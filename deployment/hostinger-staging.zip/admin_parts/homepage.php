<?php defined('IN_ADMIN') || exit; ?>
<div class="adm-head"><div><h1>محتوى الرئيسية</h1><p class="muted">حدّث العنوان والتعريف اللذين يراهما الزوار أولًا.</p></div><a class="btn sm ghost" href="index.php" target="_blank" rel="noopener">عرض الصفحة</a></div>
<section class="card"><div class="card-head"><h2>المقدمة الرئيسية</h2></div>
<form method="post" class="form pad"><?=csrf_field()?><input type="hidden" name="action" value="savehomepage">
<div class="field"><label for="home_title">العنوان الرئيسي</label><input id="home_title" name="home_title" maxlength="180" value="<?=e(setting('home_title','مساحة للكلام الذي لم يُقَل'))?>" required></div>
<div class="field"><label for="home_lead">النص التعريفي</label><textarea id="home_lead" name="home_lead" maxlength="500" rows="4" required><?=e(setting('home_lead','أنشئ رابطك الخاص، شاركه مع من تحب، واستقبل كلماتهم الصادقة في صندوق لا يراه سواك.'))?></textarea></div>
<button class="btn"><?=icon('check')?> حفظ التغييرات</button></form></section>
