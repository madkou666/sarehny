<?php defined('IN_ADMIN') || exit;
$tables=[]; $total=0;
try{ $st=$pdo->prepare('SELECT table_name n, table_rows r, (data_length+index_length) s FROM information_schema.tables WHERE table_schema=? ORDER BY s DESC'); $st->execute([DB_NAME]); $tables=$st->fetchAll(); foreach($tables as $t) $total+=(int)$t['s']; }catch(Throwable $ex){}
$fmt=function($b){ $u=['B','KB','MB','GB']; $i=0; while($b>=1024&&$i<3){$b/=1024;$i++;} return round($b,1).' '.$u[$i]; };
$dirSize=0; $files=0; $up=__DIR__.'/../uploads/avatars';
if(is_dir($up)) foreach(new DirectoryIterator($up) as $f) if($f->isFile()){ $dirSize+=$f->getSize(); $files++; }
$dbv=''; try{ $dbv=(string)$pdo->query('SELECT VERSION()')->fetchColumn(); }catch(Throwable $ex){}
$info=[
  'إصدار PHP'=>PHP_VERSION,'قاعدة البيانات'=>$dbv,'خادم الويب'=>(string)($_SERVER['SERVER_SOFTWARE']??'—'),
  'حد الذاكرة'=>ini_get('memory_limit'),'أقصى حجم رفع'=>ini_get('upload_max_filesize'),'المنطقة الزمنية'=>date_default_timezone_get(),
  'وقت الخادم'=>date('Y-m-d H:i:s'),'HTTPS'=>!empty($_SERVER['HTTPS'])?'مفعّل':'غير مفعّل',
  'إضافة GD (الصور)'=>extension_loaded('gd')?'متوفرة':'غير متوفرة','إضافة cURL'=>extension_loaded('curl')?'متوفرة':'غير متوفرة',
];
?>
<div class="adm-head"><div><h1>معلومات النظام</h1><p class="muted">صحة الخادم وحجم البيانات وأدوات الصيانة.</p></div></div>

<div class="adm-grid-2">
  <section class="card" aria-labelledby="sy-info">
    <div class="card-head"><h2 id="sy-info">الخادم</h2></div>
    <div class="table-wrap"><table class="adm-table tbl"><tbody>
      <?php foreach($info as $k=>$v): ?><tr><th scope="row"><?=e($k)?></th><td dir="ltr"><?=e($v)?></td></tr><?php endforeach; ?>
    </tbody></table></div>
  </section>
  <section class="card" aria-labelledby="sy-db">
    <div class="card-head"><div><h2 id="sy-db">قاعدة البيانات</h2><p class="muted sm">الحجم الإجمالي: <b dir="ltr"><?=$fmt($total)?></b> — الصور الشخصية: <b dir="ltr"><?=$fmt($dirSize)?></b> (<?=ar_num($files)?> ملف)</p></div></div>
    <div class="table-wrap"><table class="adm-table tbl"><thead><tr><th>الجدول</th><th>الصفوف (تقريبي)</th><th>الحجم</th></tr></thead><tbody>
      <?php foreach($tables as $t): ?><tr><td dir="ltr"><?=e($t['n'])?></td><td><?=ar_num((int)$t['r'])?></td><td dir="ltr"><?=$fmt((int)$t['s'])?></td></tr><?php endforeach; ?>
    </tbody></table></div>
  </section>
</div>

<section class="card" aria-labelledby="sy-maint">
  <div class="card-head"><div><h2 id="sy-maint">صيانة</h2><p class="muted sm">عمليات آمنة لتحسين الأداء وتنظيف البيانات القديمة.</p></div></div>
  <div class="pad sys-actions">
    <form method="post"><?=csrf_field()?><input type="hidden" name="action" value="optimizedb"><button class="btn ghost sm">تحسين جداول قاعدة البيانات</button></form>
    <form method="post"><?=csrf_field()?><input type="hidden" name="action" value="purgelogsold"><button class="btn ghost sm">حذف سجل النشاط الأقدم من ٩٠ يومًا</button></form>
    <form method="post" onsubmit="return confirm('حذف الحسابات المعطّلة نهائيًا مع رسائلها؟')"><?=csrf_field()?><input type="hidden" name="action" value="purgedisabled"><button class="btn ghost sm">حذف الحسابات المعطّلة</button></form>
  </div>
</section>

<form method="post" class="settings-form"><?=csrf_field()?><input type="hidden" name="action" value="savereserved">
<section class="card" aria-labelledby="sy-res">
  <div class="card-head"><div><h2 id="sy-res">أسماء المستخدمين المحجوزة</h2><p class="muted sm">اسم في كل سطر. لن يتمكن أحد من التسجيل بها.</p></div></div>
  <div class="form pad"><textarea name="reserved_usernames" rows="6" dir="ltr" class="mono" maxlength="5000"><?=e(setting('reserved_usernames',"admin\nadministrator\nroot\nsupport\nasrar"))?></textarea>
  <div><button class="btn sm">حفظ القائمة</button></div></div>
</section>
</form>
