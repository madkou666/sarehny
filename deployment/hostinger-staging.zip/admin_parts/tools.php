<?php defined('IN_ADMIN') || exit;
$dbSize=(float)$pdo->query('SELECT COALESCE(SUM(data_length+index_length),0) FROM information_schema.tables WHERE table_schema=DATABASE()')->fetchColumn();
$fmtSize=$dbSize>1048576?ar_num(number_format($dbSize/1048576,2)).' م.ب':ar_num(number_format($dbSize/1024,1)).' ك.ب';
$hidden=$one('SELECT COUNT(*) FROM messages WHERE is_removed=1');
$exports=[
  ['users','المستخدمون','users','كل الحسابات مع البريد والحالة وعدد الرسائل.',$one('SELECT COUNT(*) FROM users')],
  ['messages','الرسائل','mail','نص كل الرسائل ومستلمها وتاريخها.',$one('SELECT COUNT(*) FROM messages')],
  ['reports','البلاغات','flag','كل البلاغات مع أسبابها وحالتها.',$one('SELECT COUNT(*) FROM reports')],
];
$backupLimit=admin_backup_limit_bytes();
$backupZipAvailable=class_exists('ZipArchive');
$info=[
  ['إصدار PHP',PHP_VERSION],
  ['إصدار قاعدة البيانات',$pdo->query('SELECT VERSION()')->fetchColumn()],
  ['حجم قاعدة البيانات',$fmtSize],
  ['وقت الخادم',date('Y-m-d H:i')],
  ['الحد الأقصى للرفع',ini_get('upload_max_filesize')],
  ['الذاكرة المتاحة',ini_get('memory_limit')],
];
?>
<div class="adm-head">
  <div><h1>التصدير والنسخ الاحتياطي</h1><p class="muted">صدّر بيانات الموقع أو أنشئ نسخة متكاملة لحسابات المستخدمين ورسائلهم ووسائطهم.</p></div>
</div>

<div class="export-grid">
  <?php foreach($exports as [$k,$l,$ic,$d,$n]): ?>
  <form method="post" class="card export-card" data-confirm="هل تريد تصدير بيانات <?=$l?> إلى ملف CSV؟"><?=csrf_field()?><input type="hidden" name="action" value="export"><input type="hidden" name="what" value="<?=$k?>">
    <span class="stat-icon violet"><?=icon($ic)?></span>
    <h2><?=$l?></h2><p class="muted sm"><?=$d?></p>
    <div class="export-foot"><span class="tag"><?=ar_num($n)?> سجل</span><button class="btn sm ghost"><?=icon('download')?> تصدير CSV</button></div>
  </form>
  <?php endforeach; ?>
</div>

<div class="adm-grid-2">
  <section class="card backup-card span-2" aria-labelledby="bk-h">
    <div class="card-head"><div><h2 id="bk-h">نسخة بيانات المستخدمين والرسائل</h2><p class="muted sm">أرشيف ZIP واحد يحفظ الحسابات وكلمات مرورها المشفّرة ورسائلها وبياناتها المرتبطة والصور الشخصية والتسجيلات الصوتية.</p></div></div>
    <div class="backup-actions">
      <form method="post" class="backup-action-card" data-confirm="سيتم تنزيل نسخة كاملة تتضمن بيانات الحسابات والرسائل والتسجيلات الصوتية. احفظ الملف في مكان آمن. هل تريد المتابعة؟"><?=csrf_field()?><input type="hidden" name="action" value="backup"><span class="backup-action-icon"><?=icon('download')?></span><div><b>تنزيل نسخة احتياطية</b><p class="muted sm">أنشئ ملفًا واحدًا واحفظه في مكان آمن. يمكنك رفع الملف نفسه بعد تثبيت الموقع.</p></div><button class="btn" <?=$backupZipAvailable?'':'disabled'?>><?=icon('database')?> تنزيل نسخة ZIP</button></form>
      <form method="post" action="admin-restore/index.php" enctype="multipart/form-data" class="backup-action-card backup-restore-form" onsubmit="return confirm('سيتم استبدال جميع حسابات المستخدمين ورسائلهم والبلاغات والوسائط الحالية بما في النسخة. سيتم تسجيل خروجك بعد الاستعادة. هل تريد المتابعة؟')"><?=csrf_field()?><input type="hidden" name="action" value="restore_backup"><span class="backup-action-icon restore"><?=icon('upload')?></span><div><b>استعادة نسخة محفوظة</b><p class="muted sm">ارفع ملف ZIP الذي نزّلته سابقًا؛ يجري التحقق من جميع السجلات والتسجيلات قبل الاستبدال.</p></div><label class="backup-file-field" for="backup-file">ملف النسخة الاحتياطية <input id="backup-file" type="file" name="backup_file" accept=".zip,application/zip" required <?=$backupZipAvailable?'':'disabled'?>></label><small class="muted">الحد الأقصى للنسخة: <b dir="ltr"><?=e(admin_backup_format_bytes($backupLimit))?></b> (قد تضع الاستضافة حدًا أقل)</small><label class="backup-ack"><input type="checkbox" name="confirm_restore" value="1" required><span>أوافق على استبدال حسابات ورسائل المستخدمين الحالية ببيانات النسخة.</span></label><button class="btn danger" <?=$backupZipAvailable?'':'disabled'?>><?=icon('upload')?> رفع واستعادة النسخة</button></form>
    </div>
    <div class="backup-notice" role="note"><b>تنبيه مهم:</b> الاستعادة تستبدل بيانات المستخدمين والرسائل والبلاغات وبيانات تحليلها واشتراكات الإشعارات، وتستعيد صورهم والتسجيلات الصوتية. لا تغيّر إعدادات الموقع أو محتواه. سجّل خروجك تلقائيًا بعدها لتسجيل الدخول بحساب موجود في النسخة.</div>
    <?php if(!$backupZipAvailable): ?><p class="backup-extension-warning" role="alert">إضافة ZIP الخاصة بـ PHP غير مفعّلة على الخادم؛ فعّلها لاستعمال النسخ الاحتياطي والاستعادة.</p><?php endif; ?>
  </section>

  <section class="card" aria-labelledby="sys-h">
    <div class="card-head"><h2 id="sys-h">معلومات النظام</h2><?=icon('server')?></div>
    <ul class="status-list"><?php foreach($info as [$l,$v]): ?><li><span><?=$l?></span><b dir="ltr"><?=e($v)?></b></li><?php endforeach; ?></ul>
  </section>

  <section class="card danger-zone span-2" aria-labelledby="dz-h">
    <div class="card-head"><div><h2 id="dz-h">منطقة الخطر</h2><p class="muted sm">إجراءات نهائية لا يمكن التراجع عنها.</p></div></div>
    <div class="dz-row">
      <div><b>حذف الرسائل المخفية نهائيًا</b><small class="muted">يوجد حاليًا <?=ar_num($hidden)?> رسالة مخفية.</small></div>
      <form method="post"><?=csrf_field()?><button class="btn sm danger" name="action" value="purgehidden" <?=$hidden?'':'disabled'?> data-confirm="حذف كل الرسائل المخفية نهائيًا؟"><?=icon('trash')?> حذف</button></form>
    </div>
  </section>
</div>
