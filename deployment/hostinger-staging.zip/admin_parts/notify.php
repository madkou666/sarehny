<?php defined('IN_ADMIN') || exit;
$subs=0; $users=0; try{ $subs=$one('SELECT COUNT(*) FROM push_subs'); $users=$one('SELECT COUNT(DISTINCT user_id) FROM push_subs'); }catch(Throwable $ex){}
$ok=function_exists('curl_init') && function_exists('openssl_pkey_derive'); $https=!empty($_SERVER['HTTPS']);
?>
<div class="adm-head"><div><h1>إشعارات الموبايل</h1><p class="muted">يصل المستخدم تنبيه على جواله فور وصول رسالة جديدة، حتى لو كان الموقع مغلقًا.</p></div></div>
<?php if(!$ok||!$https): ?><div class="alert err" role="alert"><span>
  <?=!$https?'الإشعارات تحتاج أن يعمل موقعك بشهادة HTTPS. ':''?><?=!$ok?'السيرفر يحتاج PHP 7.3 أو أحدث مع إضافتي OpenSSL و cURL.':''?></span></div><?php endif; ?>

<div class="adm-grid-2">
  <section class="card"><div class="pad"><small class="muted">أجهزة مشتركة</small><h2><?=ar_num($subs)?></h2></div></section>
  <section class="card"><div class="pad"><small class="muted">مستخدمون فعّلوا الإشعارات</small><h2><?=ar_num($users)?></h2></div></section>
</div>

<form method="post" class="settings-form"><?=csrf_field()?><input type="hidden" name="action" value="savenotify">
<section class="card"><div class="card-head"><h2>الإعدادات</h2></div><div class="form pad">
  <p class="muted" style="margin:0 0 8px">إشعارات الرسائل مفعّلة دائمًا لكل المستخدمين ولا يمكن إيقافها.</p>
  <label class="switch-row"><span><b>عرض جزء من نص الرسالة في الإشعار</b><small>عند الإيقاف يظهر نص عام فقط، وهو أفضل للخصوصية.</small></span><input type="checkbox" class="toggle" name="push_preview" value="1" <?=setting('push_preview','1')==='1'?'checked':''?>></label>
  <div><button class="btn sm">حفظ</button></div>
</div></section></form>

<form method="post" class="settings-form" onsubmit="return confirm('إرسال هذا الإشعار لكل المشتركين؟')"><?=csrf_field()?><input type="hidden" name="action" value="broadcast">
<section class="card"><div class="card-head"><div><h2>إشعار جماعي</h2><p class="muted sm">أرسل تنبيهًا لكل من فعّل الإشعارات (مثلًا: ميزة جديدة أو تحديث).</p></div></div><div class="form pad">
  <div class="field"><label for="b_title">العنوان</label><input id="b_title" name="title" maxlength="60" required></div>
  <div class="field"><label for="b_body">النص</label><textarea id="b_body" name="body" rows="2" maxlength="180" required></textarea></div>
  <div><button class="btn sm">إرسال للجميع</button></div>
</div></section></form>

<section class="card"><div class="card-head"><h2>ملاحظات</h2></div><div class="pad muted sm">
  <p>• أندرويد (Chrome): يعمل مباشرة بعد ضغط «تفعيل الإشعارات».</p>
  <p>• آيفون (iOS 16.4 أو أحدث): يجب أولًا إضافة الموقع للشاشة الرئيسية من زر المشاركة في Safari، ثم فتحه من الأيقونة وتفعيل الإشعارات.</p>
</div></section>
