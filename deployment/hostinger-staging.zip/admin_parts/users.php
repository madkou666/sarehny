<?php defined('IN_ADMIN') || exit;
$filters=['all'=>'الكل','active'=>'نشط','admin'=>'المديرون','verified'=>'موثّق','premium'=>'مشترك التحليل','disabled'=>'معطّل'];
if(!isset($filters[$f])) $f='all';
$where=['(u.username LIKE ? OR u.email LIKE ? OR u.display_name LIKE ?)']; $sq='%'.$q.'%'; $params=[$sq,$sq,$sq];
if($f==='active') $where[]='u.is_disabled=0'; if($f==='admin') $where[]='u.is_admin=1'; if($f==='disabled') $where[]='u.is_disabled=1'; if($f==='verified') $where[]='u.is_verified=1'; if($f==='premium') $where[]='u.insights_enabled=1';
$w=implode(' AND ',$where);
$usersSort=in_array($_GET['sort']??'',['newest','oldest','messages','activity'],true)?$_GET['sort']:'newest';
$sortSql=['newest'=>'u.id DESC','oldest'=>'u.id ASC','messages'=>'mc DESC,u.id DESC','activity'=>'u.last_active_at IS NULL ASC,u.last_active_at DESC,u.id DESC'][$usersSort];
$per=in_array((int)($_GET['per']??20),[10,20,50],true)?(int)($_GET['per']??20):20;
$total=$one("SELECT COUNT(*) FROM users u WHERE $w",$params);
$page=min($page,max(1,(int)ceil($total/$per)));
$s=$pdo->prepare("SELECT u.*,(SELECT COUNT(*) FROM messages m WHERE m.recipient_id=u.id) mc FROM users u WHERE $w ORDER BY $sortSql LIMIT $per OFFSET ".(($page-1)*$per));
$s->execute($params); $rows=$s->fetchAll();
$firstResult=$total?($page-1)*$per+1:0; $lastResult=min($page*$per,$total); $base=['t'=>'users','f'=>$f==='all'?'':$f,'q'=>$q,'sort'=>$usersSort==='newest'?'':$usersSort,'per'=>$per===20?'':$per];

$counts=['all'=>$one('SELECT COUNT(*) FROM users'),'active'=>$one('SELECT COUNT(*) FROM users WHERE is_disabled=0'),'admin'=>$one('SELECT COUNT(*) FROM users WHERE is_admin=1'),'verified'=>$one('SELECT COUNT(*) FROM users WHERE is_verified=1'),'premium'=>$one('SELECT COUNT(*) FROM users WHERE insights_enabled=1'),'disabled'=>$one('SELECT COUNT(*) FROM users WHERE is_disabled=1')];
$editId=(int)($_GET['edit']??0); $edit=null;
if($editId){ $s=$pdo->prepare('SELECT * FROM users WHERE id=?'); $s->execute([$editId]); $edit=$s->fetch(); }
?>
<div class="adm-head">
  <div><h1>المستخدمون</h1><p class="muted">إدارة الحسابات والصلاحيات وبيانات الدخول.</p></div>
</div>

<?php if($edit): ?>
<section class="card edit-card" aria-labelledby="edit-h">
  <div class="card-head"><div class="cell-user"><?=avatar_html($edit)?><div><h2 id="edit-h">تعديل: <?=e($edit['display_name'])?><?=verified_badge($edit)?></h2><small class="muted" dir="ltr">@<?=e($edit['username'])?></small></div></div>
    <a class="btn xs ghost" href="<?=e(admin_url(['t'=>'users']))?>"><?=icon('x')?> إلغاء</a></div>
  <form method="post" action="<?=e(admin_url(['t'=>'users']))?>" class="form pad">
    <?=csrf_field()?><input type="hidden" name="action" value="edituser"><input type="hidden" name="id" value="<?=(int)$edit['id']?>">
    <div class="grid-2">
      <div class="field"><label for="ed-name">الاسم الظاهر</label><input id="ed-name" name="display_name" required maxlength="80" value="<?=e($edit['display_name'])?>"></div>
      <div class="field"><label for="ed-email">البريد الإلكتروني</label><input id="ed-email" name="email" type="email" dir="ltr" required value="<?=e($edit['email'])?>"></div>
    </div>
    <div class="field"><label for="ed-pass">كلمة مرور جديدة</label><input id="ed-pass" name="password" type="password" dir="ltr" minlength="8" autocomplete="new-password" placeholder="اتركها فارغة للإبقاء على الحالية"><small class="hint">٨ أحرف على الأقل. سيتم استبدال كلمة المرور الحالية فورًا.</small></div>
    <div class="row-actions"><button class="btn"><?=icon('check')?> حفظ التغييرات</button></div>
  </form>
</section>
<?php endif; ?>

<div class="toolbar-adm">
  <nav class="chips" aria-label="تصفية المستخدمين">
    <?php foreach($filters as $k=>$l): ?><a href="<?=e(admin_url(['t'=>'users','f'=>$k==='all'?'':$k,'q'=>$q,'sort'=>$usersSort==='newest'?'':$usersSort,'per'=>$per===20?'':$per]))?>" class="<?=$f===$k?'on':''?>" <?=$f===$k?'aria-current="true"':''?>><?=$l?> <span><?=ar_num($counts[$k])?></span></a><?php endforeach; ?>
  </nav>
  <form class="search" role="search"><input type="hidden" name="t" value="users"><?php if($f!=='all'): ?><input type="hidden" name="f" value="<?=e($f)?>"><?php endif; ?><?php if($usersSort!=='newest'): ?><input type="hidden" name="sort" value="<?=e($usersSort)?>"><?php endif; ?><?php if($per!==20): ?><input type="hidden" name="per" value="<?=$per?>"><?php endif; ?><?=icon('search')?><input name="q" aria-label="بحث في المستخدمين" placeholder="ابحث بالاسم أو البريد أو اسم المستخدم" value="<?=e($q)?>"></form>
</div>

<form class="section-table-tools user-table-tools" method="get" action="admin.php" aria-label="ترتيب نتائج المستخدمين">
  <input type="hidden" name="t" value="users"><?php if($f!=='all'): ?><input type="hidden" name="f" value="<?=e($f)?>"><?php endif; ?><?php if($q!==''): ?><input type="hidden" name="q" value="<?=e($q)?>"><?php endif; ?>
  <label><span>ترتيب حسب</span><select name="sort"><option value="newest" <?=$usersSort==='newest'?'selected':''?>>الأحدث تسجيلًا</option><option value="oldest" <?=$usersSort==='oldest'?'selected':''?>>الأقدم تسجيلًا</option><option value="messages" <?=$usersSort==='messages'?'selected':''?>>الأكثر رسائل</option><option value="activity" <?=$usersSort==='activity'?'selected':''?>>الأحدث نشاطًا</option></select></label>
  <label><span>عدد النتائج</span><select name="per"><option value="10" <?=$per===10?'selected':''?>>١٠ في الصفحة</option><option value="20" <?=$per===20?'selected':''?>>٢٠ في الصفحة</option><option value="50" <?=$per===50?'selected':''?>>٥٠ في الصفحة</option></select></label>
  <button class="btn sm" type="submit"><?=icon('filter')?> تطبيق العرض</button>
</form>

<section class="card">
  <div class="card-head section-table-head"><div><h2>سجل المستخدمين</h2><p class="muted sm">عرض <?=ar_num($firstResult)?>–<?=ar_num($lastResult)?> من <?=ar_num(number_format($total))?> مستخدم<?=' · '.ar_num($per).' في الصفحة'?></p></div><form method="post" action="<?=e(admin_url(['t'=>'users']))?>"><?=csrf_field()?><input type="hidden" name="action" value="export"><input type="hidden" name="what" value="users"><input type="hidden" name="f" value="<?=$f==='all'?'':e($f)?>"><input type="hidden" name="q" value="<?=e($q)?>"><input type="hidden" name="sort" value="<?=e($usersSort)?>"><button class="btn xs ghost"><?=icon('download')?> تصدير النتائج CSV</button></form></div>
  <?php if(!$rows): ?><div class="empty flat"><span class="empty-icon"><?=icon('users')?></span><h2>لا يوجد مستخدمون مطابقون</h2><p>جرّب كلمة بحث أو تصفية مختلفة.</p></div><?php else: ?>
  <div class="table-wrap"><table class="adm-table users-adm-table">
    <thead><tr><th scope="col">المستخدم</th><th scope="col">البريد الإلكتروني</th><th scope="col"<?=$usersSort==='messages'?' aria-sort="descending"':''?>>عدد الرسائل</th><th scope="col">حالة الحساب</th><th scope="col">الصلاحيات والميزات</th><th scope="col"<?=$usersSort==='activity'?' aria-sort="descending"':''?>>آخر نشاط</th><th scope="col"<?=$usersSort==='newest'?' aria-sort="descending"':($usersSort==='oldest'?' aria-sort="ascending"':'')?>>تاريخ التسجيل</th><th scope="col"><span class="sr-only">إجراءات</span></th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): $self=$r['id']==$me['id']; ?><tr class="user-table-row<?=$r['is_disabled']?' is-disabled':''?><?=$r['is_admin']?' is-admin':''?>">
      <td><div class="cell-user"><?=avatar_html($r,'sm')?><div><b><?=e($r['display_name'])?><?=$self?' <span class="tag gray">أنت</span>':''?></b><small dir="ltr">@<?=e($r['username'])?></small></div></div></td>
      <td dir="ltr" class="mono"><?=e($r['email'])?></td>
      <td class="user-message-count"><span class="tag"><?=ar_num(number_format($r['mc']))?></span></td>
      <td class="user-account-status"><?= $r['is_disabled']?'<span class="tag red">معطّل</span>':'<span class="tag green">نشط</span>' ?></td>
      <td class="user-access-cell"><div class="user-access-list"><?php if($r['is_admin']): ?><span class="tag violet">مدير</span><?php else: ?><span class="tag gray">عضو</span><?php endif; ?><?php if($r['is_verified']): ?><span class="tag blue">موثّق</span><?php endif; ?><?php if(insights_active($r)): ?><span class="tag green">تحليل</span><?php endif; ?></div></td>
      <td class="user-last-active"><?php if($r['last_active_at']): ?><time datetime="<?=e($r['last_active_at'])?>" title="<?=e($r['last_active_at'])?>"><?=ago($r['last_active_at'])?></time><?php else: ?><span class="muted" title="لم يسجل نشاط بعد">—</span><?php endif; ?></td>
      <td class="muted"><time datetime="<?=e($r['created_at'])?>" title="<?=e($r['created_at'])?>"><?=ago($r['created_at'])?></time></td>
      <td><div class="row-actions end">
        <a class="btn xs ghost" href="<?=e(admin_url(['t'=>'users','edit'=>(int)$r['id']]))?>" aria-label="تعديل <?=e($r['display_name'])?>"><?=icon('edit')?></a>
        <a class="btn xs ghost" href="/<?=e(rawurlencode($r['username']))?>" target="_blank" rel="noopener" aria-label="فتح صفحة <?=e($r['display_name'])?>"><?=icon('external')?></a>
        <?php if(insights_active($r)): ?><form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><button class="btn xs ghost" name="action" value="insights_off" title="<?=$r['insights_until']?'ينتهي '.e($r['insights_until']):'بلا انتهاء'?>">إيقاف التحليل</button></form>
        <?php else: ?><form method="post" class="inline ins-form"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><select name="days" aria-label="مدة الاشتراك" class="ins-days"><option value="30">شهر</option><option value="90">٣ أشهر</option><option value="365">سنة</option><option value="0">دائم</option></select><button class="btn xs verify-btn" name="action" value="insights_on">تفعيل التحليل</button></form><?php endif; ?>
        <form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><button class="btn xs <?=$r['is_verified']?'ghost':'verify-btn'?>" name="action" value="<?=$r['is_verified']?'unverify':'verify'?>"><?=$r['is_verified']?'إلغاء التوثيق':'توثيق ✓'?></button></form>
        <?php if(!$self): ?>
        <form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>">
          <?php if(!$r['is_disabled']): ?><button class="btn xs ghost" name="action" value="<?=$r['is_admin']?'unadmin':'admin'?>"><?=$r['is_admin']?'سحب الإدارة':'ترقية لمدير'?></button><?php endif; ?>
          <button class="btn xs <?=$r['is_disabled']?'ghost':'danger-soft'?>" name="action" value="<?=$r['is_disabled']?'enable':'disable'?>"><?=$r['is_disabled']?'تفعيل':'تعطيل'?></button>
          <button class="btn xs danger-soft" name="action" value="deluser" data-confirm="حذف هذا المستخدم وكل رسائله نهائيًا؟ لا يمكن التراجع." aria-label="حذف <?=e($r['display_name'])?>"><?=icon('trash')?></button>
        </form>
        <?php endif; ?>
      </div></td>
    </tr><?php endforeach; ?>
    </tbody></table></div>
  <?=pager($total,$per,$page,$base)?>
  <?php endif; ?>
</section>
