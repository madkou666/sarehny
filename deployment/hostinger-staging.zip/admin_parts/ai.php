<?php
if(!defined('IN_ADMIN')) exit;
require_once __DIR__.'/../ai_module.php';
ai_ensure_schema();
$defaults=ai_default_settings();
$stats=ai_admin_stats();
$providers=ai_provider_definitions();
$primary=ai_primary_provider_id();
$fallbacks=ai_fallback_provider_ids();
$recent=$pdo->query('SELECT provider,model,status,error_code,provider_status,cost_usd,created_at FROM ai_analysis_usage ORDER BY id DESC LIMIT 15')->fetchAll();
$settings=[]; foreach($defaults as $key=>$default) $settings[$key]=ai_setting_value($key,$default);
$providerState=[];
foreach($providers as $id=>$provider){
  $environment=getenv($provider['env']);
  $providerState[$id]=[
    'enabled'=>ai_provider_enabled($id),
    'configured'=>ai_api_key($id)!=='',
    'environment'=>is_string($environment)&&trim($environment)!=='',
    'model'=>ai_model_id($id),
    'test_status'=>(string)ai_setting_value('provider_'.$id.'_last_test_status',''),
    'tested_at'=>(string)ai_setting_value('provider_'.$id.'_last_test_at',''),
  ];
}
?>
<div class="adm-head ai-admin-head">
  <div><h1>مزودو الذكاء الاصطناعي</h1><p class="muted">إدارة مزودي التحليل، النماذج، التحويل الاحتياطي، والخصوصية وحدود الاستخدام.</p></div>
  <span class="ai-admin-state <?=$settings['enabled']==='1'?'on':''?>"><i></i><?=$settings['enabled']==='1'?'التحليل مفعّل':'التحليل متوقف'?></span>
</div>

<section class="ai-admin-stats" aria-label="إحصائيات تحليل الذكاء الاصطناعي">
  <?php foreach([['today','التحليلات اليوم','طلب ناجح'],['month','هذا الشهر','طلب ناجح'],['total','إجمالي التحليلات','طلب ناجح'],['failed','الطلبات الفاشلة','محاولة فاشلة']] as [$key,$label,$note]): ?>
  <article class="ai-admin-stat"><span><?=e($label)?></span><strong><?=ar_num($stats[$key])?></strong><small><?=e($note)?></small></article>
  <?php endforeach; ?>
</section>

<form method="post" action="?t=ai" class="ai-admin-form" id="ai-admin-form">
  <?=csrf_field()?>
  <input type="hidden" name="action" value="save"><input type="hidden" name="enabled_touched" value="">
  <section class="card ai-admin-card" aria-labelledby="ai-admin-activation">
    <div class="card-head"><div><h2 id="ai-admin-activation">التشغيل واختيار المزود</h2><p class="muted sm">تُرسل الرسائل المنقّحة إلى المزود الأساسي أو مزود احتياطي مفعّل فقط. مفاتيح API مشفّرة في قاعدة البيانات ولا تُعرض في المتصفح.</p></div></div>
    <div class="form pad">
      <label class="switch-row"><span><b>تفعيل تحليل AI</b><small>مفتاح رئيسي لإيقاف صفحة التحليل وواجهة API فورًا دون حذف الإعدادات.</small></span><input type="checkbox" class="toggle" name="enabled" value="1" onchange="this.form.enabled_touched.value='1'" <?=$settings['enabled']==='1'?'checked':''?>></label>
      <div class="ai-routing-grid">
        <div class="field"><label for="ai-primary-provider">المزود الأساسي</label><select id="ai-primary-provider" name="primary_provider"><?php foreach($providers as $id=>$provider): ?><option value="<?=e($id)?>" <?=$primary===$id?'selected':''?>><?=e($provider['label'])?></option><?php endforeach; ?></select><small class="hint">المزود الذي يبدأ تحليل الشخصية.</small></div>
        <div class="field"><label for="ai-fallback-providers">المزودون الاحتياطيون</label><select id="ai-fallback-providers" name="fallback_providers[]" multiple size="4"><?php foreach($providers as $id=>$provider): ?><option value="<?=e($id)?>" <?=in_array($id,$fallbacks,true)?'selected':''?>><?=e($provider['label'])?></option><?php endforeach; ?></select><small class="hint">يمكن اختيار أكثر من مزود؛ يُجرّبون بالترتيب المبيّن عند نفاد الحصة أو التعذّر المؤقت.</small></div>
      </div>
    </div>
  </section>

  <section class="ai-provider-grid" aria-label="إعدادات مزودي الذكاء الاصطناعي">
    <?php foreach($providers as $id=>$provider): $state=$providerState[$id]; $field='provider_api_key['.$id.']'; $modelField='provider_model['.$id.']'; ?>
    <article class="card ai-admin-card ai-provider-card" data-provider-card="<?=e($id)?>">
      <div class="card-head ai-provider-head"><div><h2><?=e($provider['label'])?></h2><p class="muted sm">واجهة مستقلة ومصادقة خاصة بهذا المزود.</p></div><span class="ai-provider-status <?=e($state['test_status']==='connected'?'is-connected':($state['test_status']==='failed'?'is-failed':($state['configured']?'is-configured':'is-missing')))?>" data-provider-state title="<?=e($state['tested_at']?'آخر اختبار: '.$state['tested_at']:'لم يختبر الاتصال بعد')?>"><?= $state['test_status']==='connected'?'متصل':($state['test_status']==='failed'?'فشل آخر اختبار':($state['configured']?'مفتاح مضبوط':'غير مضبوط')) ?></span></div>
      <div class="form pad">
        <label class="switch-row"><span><b>تفعيل <?=e($provider['label'])?></b><small>يمكن إيقاف المزود دون حذف المفتاح أو النموذج.</small></span><input type="hidden" name="provider_enabled[<?=e($id)?>]" value="0"><input type="checkbox" class="toggle" name="provider_enabled[<?=e($id)?>]" value="1" <?=$state['enabled']?'checked':''?>></label>
        <div class="field"><label for="ai-key-<?=e($id)?>">API Key</label><input id="ai-key-<?=e($id)?>" type="password" name="<?=e($field)?>" dir="ltr" autocomplete="new-password" spellcheck="false" maxlength="512" placeholder="<?=$state['environment']?'المفتاح مضبوط عبر بيئة الخادم':($state['configured']?'مفتاح محفوظ — اتركه فارغًا للإبقاء عليه':'أدخل مفتاح '.$provider['label'])?>"><small class="hint"><?=$state['environment']?'المفتاح المعرّف في الخادم له الأولوية.':($state['configured']?'لا يظهر المفتاح المحفوظ مرة أخرى. اترك الحقل فارغًا للإبقاء عليه.':'يُحفظ مشفّرًا على الخادم ولا يُرسل إلى المتصفح.')?></small></div>
        <?php if($state['configured']&&!$state['environment']): ?><label class="check-inline ai-clear-key"><input type="checkbox" name="clear_provider_key[<?=e($id)?>]" value="1"> حذف المفتاح المحفوظ</label><?php endif; ?>
        <div class="ai-model-line"><div class="field"><label for="ai-model-<?=e($id)?>">Model</label><input id="ai-model-<?=e($id)?>" name="<?=e($modelField)?>" list="ai-model-options-<?=e($id)?>" dir="ltr" required maxlength="160" value="<?=e($state['model'])?>"><datalist id="ai-model-options-<?=e($id)?>"><option value="<?=e($provider['default_model'])?>"></option></datalist><small class="hint">اختبر المفتاح لجلب النماذج والتحقق منها، أو أدخل معرّفًا يدويًا.</small></div><button type="button" class="btn ghost ai-test-button" data-provider-test="<?=e($id)?>">اختبار الاتصال وتحميل النماذج</button></div>
        <p class="ai-test-status" data-provider-message role="status" aria-live="polite"></p>
      </div>
    </article>
    <?php endforeach; ?>
  </section>

  <section class="card ai-admin-card" aria-labelledby="ai-admin-limits">
    <div class="card-head"><div><h2 id="ai-admin-limits">حدود الاستخدام</h2><p class="muted sm">تُطبّق على كل مستخدم مسجّل، ولا تُحتسب المحاولة إلا عند نجاح التحليل.</p></div></div>
    <div class="form pad grid-2">
      <div class="field"><label for="ai-limit-count">عدد التحليلات المسموح بها</label><input id="ai-limit-count" name="limit_count" type="number" min="1" max="100" dir="ltr" value="<?=e($settings['limit_count'])?>"><small class="hint">لكل مستخدم خلال النافذة المحددة أدناه.</small></div>
      <div class="field"><label for="ai-window-hours">مدة احتساب الرصيد (ساعة)</label><input id="ai-window-hours" name="window_hours" type="number" min="1" max="720" dir="ltr" value="<?=e($settings['window_hours'])?>"></div>
      <div class="field"><label for="ai-max-messages">الحد الأقصى لعدد الرسائل</label><input id="ai-max-messages" name="max_messages" type="number" min="1" max="50" dir="ltr" value="<?=e($settings['max_messages'])?>"></div>
      <div class="field"><label for="ai-max-chars">الحد الأقصى لطول كل رسالة</label><input id="ai-max-chars" name="max_chars" type="number" min="100" max="5000" dir="ltr" value="<?=e($settings['max_chars'])?>"></div>
      <div class="field"><label for="ai-max-input-chars">الحد الإجمالي لطول الرسائل</label><input id="ai-max-input-chars" name="max_input_chars" type="number" min="500" max="100000" dir="ltr" value="<?=e($settings['max_input_chars'])?>"><small class="hint">إجمالي الأحرف المنقّحة المرسلة في الطلب الواحد.</small></div>
      <div class="field"><label for="ai-max-result-chars">الحد الأقصى لطول النتيجة</label><input id="ai-max-result-chars" name="max_result_chars" type="number" min="300" max="12000" dir="ltr" value="<?=e($settings['max_result_chars'])?>"></div>
      <div class="field"><label for="ai-timeout-seconds">مهلة الاتصال (ثانية)</label><input id="ai-timeout-seconds" name="timeout_seconds" type="number" min="5" max="120" dir="ltr" value="<?=e($settings['timeout_seconds'])?>"></div>
      <div class="field"><label for="ai-cooldown-hours">مدة الانتظار بين التحليلات (ساعة)</label><input id="ai-cooldown-hours" name="cooldown_hours" type="number" min="0" max="720" dir="ltr" value="<?=e($settings['cooldown_hours'])?>"><small class="hint">ضع ٠ لإلغاء الانتظار الإضافي؛ يظل حد الفترة مطبّقًا.</small></div>
      <div class="field ai-limit-message"><label for="ai-limit-message">رسالة انتهاء الحد المجاني</label><textarea id="ai-limit-message" name="limit_message" rows="3" maxlength="500"><?=e($settings['limit_message'])?></textarea></div>
    </div>
  </section>

  <section class="card ai-admin-card" aria-labelledby="ai-admin-privacy">
    <div class="card-head"><div><h2 id="ai-admin-privacy">الخصوصية وPrompt التحليل</h2><p class="muted sm">تُزال بيانات الاتصال ومعرّفات الحساب الشائعة قبل إرسال النصوص إلى المزود المحدد.</p></div></div>
    <div class="form pad">
      <label class="switch-row"><span><b>حفظ نتائج التحليل</b><small>عند الإيقاف تُحفظ بيانات الطلب التشغيلية فقط دون محتوى النتيجة.</small></span><input type="checkbox" class="toggle" name="save_results" value="1" <?=$settings['save_results']==='1'?'checked':''?>></label>
      <div class="field"><label for="ai-prompt">Prompt قابل للتعديل</label><textarea id="ai-prompt" name="prompt" rows="8" maxlength="8000" required><?=e($settings['prompt'])?></textarea><small class="hint">مخطط النتيجة ثابت، وتُضاف تعليمات حماية ثابتة من الخادم بعد هذا النص.</small></div>
    </div>
  </section>
  <div class="sticky-save"><button class="btn lg" type="submit"><?=icon('check')?> حفظ إعدادات مزودي الذكاء الاصطناعي</button></div>
</form>

<section class="card ai-admin-card ai-admin-models" aria-labelledby="ai-models-title"><div class="card-head"><div><h2 id="ai-models-title">النماذج المستخدمة</h2><p class="muted sm">أحدث النماذج التي أكملت تحليلًا بنجاح.</p></div></div>
  <?php if($stats['models']): ?><div class="ai-model-list"><?php foreach($stats['models'] as $model): ?><div><span class="ai-history-provider"><?=e($providers[$model['provider']]['label']??'غير محدد')?></span><code dir="ltr"><?=e($model['model'])?></code><span><?=ar_num($model['total'])?> تحليل</span></div><?php endforeach; ?></div><?php else: ?><p class="ai-empty">لا توجد تحليلات مكتملة بعد.</p><?php endif; ?>
</section>

<section class="card ai-admin-card ai-admin-history" aria-labelledby="ai-history-title"><div class="card-head"><div><h2 id="ai-history-title">سجل استخدام التحليل</h2><p class="muted sm">آخر ١٥ محاولة، دون نصوص الرسائل أو نتائج المستخدمين أو مفاتيح API.</p></div></div>
  <?php if($recent): ?><div class="ai-history-scroll"><table class="ai-history-table"><thead><tr><th>التاريخ</th><th>المزود</th><th>النموذج</th><th>الحالة</th><th>HTTP</th><th>التكلفة</th><th>رمز الخطأ</th></tr></thead><tbody><?php foreach($recent as $entry): ?><tr><td><?=e($entry['created_at'])?></td><td><?=e($providers[$entry['provider']]['label']??'—')?></td><td><code dir="ltr"><?=e($entry['model'])?></code></td><td><span class="ai-status-chip <?=e($entry['status'])?>"><?=e(['success'=>'نجح','failed'=>'فشل','pending'=>'قيد المعالجة'][$entry['status']]??$entry['status'])?></span></td><td><?=e($entry['provider_status']?:'—')?></td><td><?= $entry['cost_usd']!==null?e(number_format((float)$entry['cost_usd'],6)).' USD':'—' ?></td><td><?=e($entry['error_code']?:'—')?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><p class="ai-empty">لم تُسجّل محاولات حتى الآن.</p><?php endif; ?>
</section>
<script src="ai-admin.js?v=8" defer></script>
<script>
document.addEventListener('change',function(event){if(event.target&&event.target.id==='ai-primary-provider'){var selected=event.target.value;document.querySelectorAll('#ai-fallback-providers option').forEach(function(option){option.disabled=option.value===selected;if(option.disabled)option.selected=false;});}});
</script>
