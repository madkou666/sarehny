<?php defined('IN_ADMIN') || exit;
$groupsMap=['user'=>'المستخدمون','msg'=>'الرسائل','report'=>'البلاغات','word'=>'فلتر الكلمات','ban'=>'الحظر','settings'=>'الإعدادات','announce'=>'الإعلانات'];
if($f!=='' && !isset($groupsMap[$f])) $f='';
$where=$f!==''?'l.action LIKE ?':'1=1'; $params=$f!==''?[$f.'.%']:[]; $per=30;
$total=$one("SELECT COUNT(*) FROM admin_logs l WHERE $where",$params);
$s=$pdo->prepare("SELECT l.*,u.display_name,u.username,u.avatar FROM admin_logs l LEFT JOIN users u ON u.id=l.admin_id WHERE $where ORDER BY l.id DESC LIMIT $per OFFSET ".(($page-1)*$per));
$s->execute($params); $rows=$s->fetchAll();
$toneOf=function($a){
  if(preg_match('/delete|clear|purge/',$a) || in_array($a,['ban.add','user.disable'],true)) return 'red';
  if(preg_match('/^(settings|announce|user\.admin)/',$a)) return 'violet';
  return 'gray';
};
?>
<div class="adm-head">
  <div><h1>سجل النشاط</h1><p class="muted">كل إجراء إداري يُسجَّل هنا مع اسم المدير ووقت التنفيذ.</p></div>
  <?php if($total): ?><form method="post"><?=csrf_field()?><button class="btn sm danger-soft" name="action" value="clearlogs" data-confirm="مسح سجل النشاط بالكامل؟"><?=icon('trash')?> مسح السجل</button></form><?php endif; ?>
</div>

<div class="toolbar-adm">
  <nav class="chips" aria-label="تصفية السجل">
    <a href="<?=e(admin_url(['t'=>'logs']))?>" class="<?=$f===''?'on':''?>">الكل</a>
    <?php foreach($groupsMap as $k=>$l): ?><a href="<?=e(admin_url(['t'=>'logs','f'=>$k]))?>" class="<?=$f===$k?'on':''?>"><?=$l?></a><?php endforeach; ?>
  </nav>
</div>

<section class="card">
  <?php if(!$rows): ?>
    <div class="empty flat"><span class="empty-icon"><?=icon('activity')?></span><h2>لا يوجد نشاط</h2><p>ستظهر هنا الإجراءات الإدارية فور تنفيذها.</p></div>
  <?php else: ?>
  <div class="table-wrap"><table class="adm-table">
    <thead><tr><th scope="col">الإجراء</th><th scope="col">التفاصيل</th><th scope="col">المدير</th><th scope="col">الوقت</th></tr></thead>
    <tbody>
    <?php foreach($rows as $l): ?><tr>
      <td><span class="tag <?=$toneOf($l['action'])?>"><?=e($actionLabels[$l['action']]??$l['action'])?></span></td>
      <td><?=e($l['details']?:'—')?></td>
      <td><?php if($l['display_name']): ?><div class="cell-user"><?=avatar_html($l,'xs')?><span><?=e($l['display_name'])?></span></div><?php else: ?><span class="muted">حساب محذوف</span><?php endif; ?></td>
      <td class="muted"><time datetime="<?=e($l['created_at'])?>" title="<?=e($l['created_at'])?>"><?=ago($l['created_at'])?></time></td>
    </tr><?php endforeach; ?>
    </tbody></table></div>
  <?=pager($total,$per,$page,['t'=>'logs','f'=>$f])?>
  <?php endif; ?>
</section>
