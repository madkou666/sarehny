<?php defined('IN_ADMIN') || exit; $logo=logo_url(); ?>
<div class="adm-head"><div><h1>الشعار والهوية</h1><p class="muted">غيّر شعار الموقع ووصفه وروابط حساباتك على مواقع التواصل.</p></div></div>

<section class="card" aria-labelledby="id-logo">
  <div class="card-head"><div><h2 id="id-logo">شعار الموقع</h2><p class="muted sm">يظهر في أعلى الموقع وفي لوحة التحكم، ويُستخدم أيقونةً للمتصفح وللإشعارات وعند إضافة الموقع للشاشة الرئيسية. يفضّل صورة PNG مربعة بخلفية شفافة (512×512).</p></div></div>
  <div class="pad logo-box">
    <div class="logo-preview"><?php if($logo): ?><img src="<?=e($logo)?>" alt="الشعار الحالي"><?php else: ?><span class="brand-mark"><?=icon('lock')?></span><small class="muted">الشعار الافتراضي</small><?php endif; ?></div>
    <div class="logo-actions">
      <form method="post" enctype="multipart/form-data"><?=csrf_field()?><input type="hidden" name="action" value="savelogo">
        <input type="file" name="logo" accept="image/png,image/jpeg,image/webp" required>
        <button class="btn sm">رفع الشعار</button></form>
      <?php if($logo): ?><form method="post" onsubmit="return confirm('حذف الشعار والعودة للافتراضي؟')"><?=csrf_field()?><input type="hidden" name="action" value="removelogo"><button class="btn sm ghost">حذف الشعار</button></form><?php endif; ?>
    </div>
  </div>
</section>

<form method="post" class="settings-form"><?=csrf_field()?><input type="hidden" name="action" value="saveidentity">
  <section class="card" aria-labelledby="id-look">
    <div class="card-head"><div><h2 id="id-look">عرض الشعار</h2></div></div>
    <div class="form pad">
      <div class="field"><label for="logo_height">ارتفاع الشعار: <b id="lh" dir="ltr"><?=(int)setting('logo_height','34')?>px</b></label><input id="logo_height" type="range" name="logo_height" min="20" max="64" value="<?=(int)setting('logo_height','34')?>" oninput="document.getElementById('lh').textContent=this.value+'px'"></div>
      <label class="switch-row"><span><b>إخفاء اسم الموقع بجانب الشعار</b><small>مفيد إذا كان الشعار يحتوي على الاسم مكتوبًا.</small></span><input type="checkbox" class="toggle" name="logo_hide_name" value="1" <?=setting('logo_hide_name','0')==='1'?'checked':''?>></label>
      <div class="field"><label for="site_description">وصف الموقع (يظهر في نتائج جوجل)</label><textarea id="site_description" name="site_description" rows="2" maxlength="300"><?=e(setting('site_description',''))?></textarea></div>
    </div>
  </section>
  <section class="card" aria-labelledby="id-soc">
    <div class="card-head"><div><h2 id="id-soc">حسابات التواصل</h2><p class="muted sm">اكتب اسم المستخدم أو الرابط الكامل. تظهر في أسفل الموقع، واترك الحقل فارغًا لإخفائه.</p></div></div>
    <div class="form pad color-grid">
      <?php foreach(social_links() as $k=>[$l]): ?><div class="field"><label for="soc_<?=$k?>"><?=e($l)?></label><input id="soc_<?=$k?>" name="social_<?=$k?>" dir="ltr" value="<?=e(setting('social_'.$k,''))?>" placeholder="@username"></div><?php endforeach; ?>
    </div>
  </section>
  <div class="sticky-save"><button class="btn">حفظ الهوية</button></div>
</form>
