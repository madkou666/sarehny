<?php defined('IN_ADMIN') || exit;
$toggles=[
  'allow_register'=>['السماح بالتسجيل','عند الإيقاف لن يتمكن الزوار من إنشاء حسابات جديدة.','1'],
  'messages_open'=>['استقبال الرسائل','عند الإيقاف لن يتمكن أحد من إرسال رسائل مجهولة.','1'],
  'precise_location'=>['طلب الموقع الجغرافي الدقيق','عند التفعيل يظهر طلب إذن الموقع عند ضغط الزائر على إرسال الرسالة. عند الإيقاف تُرسل الرسالة بدون طلب الموقع.','1'],
  'maintenance'=>['وضع الصيانة','يُغلق الموقع أمام الزوار والمستخدمين، ويبقى متاحًا للمديرين فقط.','0'],
];
?>
<div class="adm-head">
  <div><h1>الإعدادات</h1><p class="muted">تحكّم في هوية الموقع وطريقة عمله.</p></div>
</div>

<form method="post" class="settings-form" data-theme-form><?=csrf_field()?><input type="hidden" name="action" value="savesettings">
  <section class="card" aria-labelledby="s-general">
    <div class="card-head"><div><h2 id="s-general">عام</h2><p class="muted sm">المعلومات الأساسية للموقع.</p></div></div>
    <div class="form pad">
      <div class="field"><label for="site_name">اسم الموقع</label><input id="site_name" name="site_name" maxlength="60" value="<?=e(setting('site_name',''))?>" placeholder="<?=e(SITE_NAME)?>"><small class="hint">اتركه فارغًا لاستخدام الاسم الافتراضي من ملف الإعداد: <?=e(SITE_NAME)?></small></div>
    </div>
  </section>

  <section class="card" aria-labelledby="s-colors">
    <div class="card-head"><div><h2 id="s-colors">ألوان الموقع</h2><p class="muted sm">تسري على الموقع ولوحة التحكم بعد الحفظ.</p></div><button type="button" class="btn xs ghost" data-reset-colors>استعادة الألوان الأصلية</button></div>
    <div class="pad color-grid">
      <?php foreach(theme_fields() as $key=>[$label,$default]): ?>
      <div class="field color-field"><label for="theme_<?=e($key)?>"><?=e($label)?></label>
        <div class="color-control"><input id="theme_<?=e($key)?>" type="color" name="theme_<?=e($key)?>" value="<?=e(theme_color($key))?>" data-theme-color="<?=e($key)?>" data-default-color="<?=e($default)?>"><span class="color-value" dir="ltr"><?=e(strtoupper(theme_color($key)))?></span></div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="card" aria-labelledby="s-access">
    <div class="card-head"><div><h2 id="s-access">الوصول والتشغيل</h2><p class="muted sm">افتح أو أغلق أجزاء الموقع.</p></div></div>
    <div class="form pad">
      <?php foreach($toggles as $k=>[$l,$d,$def]): ?>
      <label class="switch-row"><span><b><?=$l?></b><small><?=$d?></small></span><input type="checkbox" class="toggle" name="<?=$k?>" value="1" <?=setting($k,$def)==='1'?'checked':''?>></label>
      <?php endforeach; ?>
      <div class="field"><label for="maintenance_msg">رسالة الصيانة</label><input id="maintenance_msg" name="maintenance_msg" maxlength="300" value="<?=e(setting('maintenance_msg',''))?>" placeholder="نعمل على تحسين الموقع، سنعود قريبًا."></div>
    </div>
  </section>

  <section class="card" aria-labelledby="s-social">
    <div class="card-head"><div><h2 id="s-social">تسجيل الدخول الاجتماعي</h2><p class="muted sm">اسمح للمستخدمين بالدخول وإنشاء الحساب بضغطة واحدة عبر Google و Facebook.</p></div></div>
    <div class="pad oauth-grid">
      <?php $steps=['google'=>'في Google Cloud Console: APIs &amp; Services ← Credentials ← Create OAuth client ID (Web application)، ثم الصق رابط الرجوع في Authorized redirect URIs.','facebook'=>'في Meta for Developers: أنشئ تطبيقًا بحالة الاستخدام «Authenticate and request data from users with Facebook Login» ← Facebook Login ← Settings، ثم الصق رابط الرجوع كما هو حرفيًا (مع ?p=facebook) في Valid OAuth Redirect URIs. لطلب البريد: Use cases ← Customize ← Permissions ← أضف email ثم فعّل الخيار أعلاه. اجعل التطبيق في وضع Live.'];
      foreach(oauth_providers() as $op=>$oc): $on=oauth_enabled($op); $hasSec=setting($op.'_client_secret','')!==''; ?>
      <div class="oauth-card">
        <div class="oauth-top"><b><?=e($oc['name'])?></b><span class="oauth-status <?=$on?'on':''?>"><?=$on?'مفعّل':'غير مفعّل'?></span></div>
        <label class="switch-row"><span><b>تفعيل الدخول عبر <?=e($oc['name'])?></b><small>يظهر الزر في صفحة الدخول والتسجيل بعد إدخال المفاتيح.</small></span><input type="checkbox" class="toggle" name="<?=$op?>_enabled" value="1" <?=setting($op.'_enabled','0')==='1'?'checked':''?>></label>
        <div class="field"><label for="<?=$op?>_cid"><?=$op==='google'?'Client ID':'App ID'?></label><input id="<?=$op?>_cid" name="<?=$op?>_client_id" dir="ltr" autocomplete="off" value="<?=e(setting($op.'_client_id',''))?>"></div>
        <div class="field"><label for="<?=$op?>_sec"><?=$op==='google'?'Client Secret':'App Secret'?></label><input id="<?=$op?>_sec" name="<?=$op?>_client_secret" type="password" dir="ltr" autocomplete="new-password" placeholder="<?=$hasSec?'•••••••• محفوظ — اتركه فارغًا للإبقاء عليه':'الصق المفتاح السري'?>">
          <?php if($hasSec): ?><label class="check-inline"><input type="checkbox" name="<?=$op?>_clear_secret" value="1"> حذف المفتاح المحفوظ</label><?php endif; ?></div>
        <?php if($op==='facebook'): ?><label class="switch-row"><span><b>طلب البريد الإلكتروني (email)</b><small>فعّله فقط بعد إضافة صلاحية email في Use cases داخل Meta، وإلا سيظهر خطأ Invalid Scopes: email. عند إيقافه يُطلب من المستخدم إدخال بريده بعد الموافقة.</small></span><input type="checkbox" class="toggle" name="facebook_email_scope" value="1" <?=setting('facebook_email_scope','0')==='1'?'checked':''?>></label><?php endif; ?>
        <div class="field"><label>رابط الرجوع (Redirect URI)</label><div class="copy-row"><input readonly dir="ltr" value="<?=e(oauth_redirect_uri($op))?>" onclick="this.select()"><button type="button" class="btn xs ghost" onclick="navigator.clipboard.writeText(this.previousElementSibling.value);this.textContent='تم النسخ'">نسخ</button></div></div>
        <p class="muted sm oauth-help"><?=$steps[$op]?> <a href="<?=e($oc['console'])?>" target="_blank" rel="noopener">فتح لوحة <?=e($oc['name'])?></a></p>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="card" aria-labelledby="s-ads">
    <div class="card-head"><div><h2 id="s-ads">إعلانات Google AdSense</h2><p class="muted sm">اربح من موقعك بعرض إعلانات جوجل في أماكن مدروسة لا تزعج الزوار.</p></div><span class="oauth-status <?=setting('ads_enabled','0')==='1'?'on':''?>"><?=setting('ads_enabled','0')==='1'?'مفعّل':'غير مفعّل'?></span></div>
    <div class="form pad">
      <label class="switch-row"><span><b>تفعيل الإعلانات</b><small>تشغيل أو إيقاف كل الإعلانات بضغطة واحدة. لا تظهر أبدًا في لوحة الإدارة.</small></span><input type="checkbox" class="toggle" name="ads_enabled" value="1" <?=setting('ads_enabled','0')==='1'?'checked':''?>></label>
      <label class="switch-row"><span><b>إخفاء الإعلانات عن المستخدمين المسجلين</b><small>تظهر للزوار فقط، تجربة أنظف لأصحاب الحسابات.</small></span><input type="checkbox" class="toggle" name="ads_hide_users" value="1" <?=setting('ads_hide_users','0')==='1'?'checked':''?>></label>
      <div class="field"><label for="ads_pub">معرّف الناشر (Publisher ID)</label><div class="copy-row"><span class="btn xs ghost" dir="ltr" style="pointer-events:none">ca-pub-</span><input id="ads_pub" name="ads_pub" dir="ltr" inputmode="numeric" autocomplete="off" value="<?=e(ads_pub())?>" placeholder="1234567890123456"></div><small class="hint">تجده في AdSense ← الحساب ← معلومات الحساب. يكفي لتفعيل الإعلانات التلقائية وربط الموقع وإنشاء ملف ads.txt.</small></div>
      <div class="field"><label for="ads_top">إعلان أعلى الصفحة</label><textarea id="ads_top" name="ads_top" dir="ltr" rows="5" spellcheck="false" placeholder='&lt;ins class="adsbygoogle" ...&gt;&lt;/ins&gt;&lt;script&gt;(adsbygoogle = window.adsbygoogle || []).push({});&lt;/script&gt;'><?=e(setting('ads_top',''))?></textarea><small class="hint">يظهر تحت شريط القائمة في كل الصفحات. اتركه فارغًا لإخفائه.</small></div>
      <div class="field"><label for="ads_content">إعلان داخل المحتوى</label><textarea id="ads_content" name="ads_content" dir="ltr" rows="5" spellcheck="false" placeholder='&lt;ins class="adsbygoogle" ...&gt;&lt;/ins&gt;&lt;script&gt;(adsbygoogle = window.adsbygoogle || []).push({});&lt;/script&gt;'><?=e(setting('ads_content',''))?></textarea><small class="hint">يظهر وسط الصفحة الرئيسية وصفحة إرسال الرسالة. اتركه فارغًا لإخفائه.</small></div>
      <div class="field"><label for="ads_bottom">إعلان أسفل الصفحة</label><textarea id="ads_bottom" name="ads_bottom" dir="ltr" rows="5" spellcheck="false" placeholder='&lt;ins class="adsbygoogle" ...&gt;&lt;/ins&gt;&lt;script&gt;(adsbygoogle = window.adsbygoogle || []).push({});&lt;/script&gt;'><?=e(setting('ads_bottom',''))?></textarea><small class="hint">يظهر قبل التذييل في كل الصفحات. اتركه فارغًا لإخفائه.</small></div>
      <div class="field"><label for="ads_head_code">كود إضافي داخل head (اختياري)</label><textarea id="ads_head_code" name="ads_head_code" dir="ltr" rows="3" spellcheck="false"><?=e(setting('ads_head_code',''))?></textarea><small class="hint">لأي كود تحقق أو سكربت إضافي. لا تكرر سكربت adsbygoogle.js فهو يُضاف تلقائيًا.</small></div>
      <div class="field"><label>ملف ads.txt</label><div class="copy-row"><input readonly dir="ltr" value="<?=e(base_url().'/ads.txt')?>" onclick="this.select()"><a class="btn xs ghost" href="ads.txt" target="_blank" rel="noopener">فتح</a></div><small class="hint">يُنشأ تلقائيًا من معرّف الناشر — تحتاجه AdSense لتأكيد ملكية الإعلانات.</small></div>
      <p class="muted sm">الخطوات: سجّل في <a href="https://adsense.google.com" target="_blank" rel="noopener">Google AdSense</a> وأضف موقعك ← الصق معرّف الناشر هنا وفعّل الإعلانات واحفظ ← ارجع لـ AdSense واضغط «تحقق» ← بعد الموافقة أنشئ وحدات إعلانية من «الإعلانات ← حسب الوحدة الإعلانية» والصق كود كل وحدة في المكان المناسب.</p>
    </div>
  </section>

  <section class="card" aria-labelledby="s-seo">
    <div class="card-head"><div><h2 id="s-seo">الظهور في بحث جوجل (Search Console)</h2><p class="muted sm">اربط موقعك بأدوات مشرفي المواقع ليظهر في نتائج البحث.</p></div></div>
    <div class="form pad">
      <label class="switch-row"><span><b>السماح لمحركات البحث بأرشفة الموقع</b><small>عند الإيقاف تُضاف علامة noindex ولن يظهر الموقع في جوجل.</small></span><input type="checkbox" class="toggle" name="seo_index" value="1" <?=setting('seo_index','1')==='1'?'checked':''?>></label>
      <div class="field"><label for="gsc_verify">كود تحقق Google Search Console</label><input id="gsc_verify" name="gsc_verify" dir="ltr" autocomplete="off" value="<?=e(setting('gsc_verify',''))?>" placeholder='&lt;meta name="google-site-verification" content="..."&gt;'><small class="hint">الصق وسم الميتا كاملًا أو الكود فقط، وسيُضاف تلقائيًا لكل صفحات الموقع.</small></div>
      <div class="field"><label for="bing_verify">كود تحقق Bing (اختياري)</label><input id="bing_verify" name="bing_verify" dir="ltr" autocomplete="off" value="<?=e(setting('bing_verify',''))?>"></div>
      <div class="field"><label>رابط خريطة الموقع (Sitemap)</label><div class="copy-row"><input readonly dir="ltr" value="<?=e(base_url().'/sitemap.xml')?>" onclick="this.select()"><button type="button" class="btn xs ghost" onclick="navigator.clipboard.writeText(this.previousElementSibling.value);this.textContent='تم النسخ'">نسخ</button></div></div>
      <p class="muted sm">الخطوات: افتح <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Google Search Console</a> ← إضافة موقع ← اختر «بادئة عنوان URL» واكتب <b dir="ltr"><?=e(base_url())?>/</b> ← اختر طريقة «علامة HTML» وانسخ الوسم ← الصقه هنا واحفظ ← ارجع واضغط «تحقق» ← من قائمة «خرائط الموقع» أضف <b dir="ltr">sitemap.xml</b>.</p>
    </div>
  </section>

  <section class="card" aria-labelledby="s-limits">
    <div class="card-head"><div><h2 id="s-limits">حدود الرسائل</h2><p class="muted sm">حماية من الإزعاج والرسائل الطويلة.</p></div></div>
    <div class="form pad grid-2">
      <div class="field"><label for="max_len">الحد الأقصى لطول الرسالة (حرف)</label><input id="max_len" name="max_len" type="number" min="50" max="5000" dir="ltr" value="<?=e(setting('max_len','1000'))?>"></div>
      <div class="field"><label for="rate_limit">عدد الرسائل المسموح كل ١٠ دقائق لكل مرسل</label><input id="rate_limit" name="rate_limit" type="number" min="1" max="100" dir="ltr" value="<?=e(setting('rate_limit','10'))?>"></div>
    </div>
  </section>

  <div class="sticky-save"><button class="btn lg"><?=icon('check')?> حفظ الإعدادات</button></div>
</form>
