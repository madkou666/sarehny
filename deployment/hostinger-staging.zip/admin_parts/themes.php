<?php defined('IN_ADMIN') || exit;
$current=[]; foreach(theme_fields() as $k=>$f) $current[$k]=theme_color($k);
$activeKey=''; foreach(admin_theme_presets() as $k=>[$n,$c]) if($c===$current){ $activeKey=$k; break; }
?>
<div class="adm-head">
  <div><h1>القوالب والمظهر</h1><p class="muted">اختر قالبًا جاهزًا بضغطة واحدة، أو خصّص الخط والزوايا، واسمح للزوار باختيار مظهرهم.</p></div>
</div>

<section class="card" aria-labelledby="th-gallery">
  <div class="card-head"><div><h2 id="th-gallery">القوالب الأساسية</h2><p class="muted sm">قوالب الموقع المعتادة، ويظل مبدّل الزوار مقتصرًا عليها.</p></div></div>
  <div class="pad theme-gallery">
    <?php foreach(theme_presets() as $k=>[$name,$c]): $on=$k===$activeKey; ?>
    <form method="post" class="theme-card<?=$on?' on':''?>" style="--tb:<?=$c['bg']?>;--ts:<?=$c['surface']?>;--tr:<?=$c['raised']?>;--ti:<?=$c['ink']?>;--tm:<?=$c['muted']?>;--tbo:<?=$c['border']?>;--tp:<?=$c['primary']?>;--tsec:<?=$c['secondary']?>">
      <?=csrf_field()?><input type="hidden" name="action" value="applytheme"><input type="hidden" name="preset" value="<?=e($k)?>">
      <div class="theme-prev" aria-hidden="true">
        <div class="tp-bar"><span></span><span></span><span></span></div>
        <div class="tp-body"><div class="tp-card"><i></i><i class="s"></i><b></b></div><div class="tp-card"><i></i><i class="s"></i><b class="sec"></b></div></div>
      </div>
      <div class="theme-meta">
        <div><b><?=e($name)?></b><div class="theme-dots"><?php foreach(['bg','surface','primary','secondary','ink'] as $d): ?><span style="background:<?=$c[$d]?>"></span><?php endforeach; ?></div></div>
        <?php if($on): ?><span class="adm-pill">مفعّل</span><?php else: ?><button class="btn xs">تطبيق</button><?php endif; ?>
      </div>
    </form>
    <?php endforeach; ?>
  </div>
</section>

<section class="card" aria-labelledby="th-admin-gallery">
  <div class="card-head"><div><h2 id="th-admin-gallery">ألوان احترافية جديدة <span class="adm-pill">10 قوالب إدارية</span></h2><p class="muted sm">هذه الخيارات تظهر للمشرفين فقط ولا تظهر في مبدّل المظهر للزوار. تطبيق أحدها يحدّث ألوان الموقع العامة ولوحة التحكم.</p></div></div>
  <div class="pad theme-gallery">
    <?php foreach(admin_only_theme_presets() as $k=>[$name,$c]): $on=$k===$activeKey; ?>
    <form method="post" class="theme-card<?=$on?' on':''?>" style="--tb:<?=$c['bg']?>;--ts:<?=$c['surface']?>;--tr:<?=$c['raised']?>;--ti:<?=$c['ink']?>;--tm:<?=$c['muted']?>;--tbo:<?=$c['border']?>;--tp:<?=$c['primary']?>;--tsec:<?=$c['secondary']?>">
      <?=csrf_field()?><input type="hidden" name="action" value="applytheme"><input type="hidden" name="preset" value="<?=e($k)?>">
      <div class="theme-prev" aria-hidden="true">
        <div class="tp-bar"><span></span><span></span><span></span></div>
        <div class="tp-body"><div class="tp-card"><i></i><i class="s"></i><b></b></div><div class="tp-card"><i></i><i class="s"></i><b class="sec"></b></div></div>
      </div>
      <div class="theme-meta">
        <div><b><?=e($name)?></b><div class="theme-dots"><?php foreach(['bg','surface','primary','secondary','ink'] as $d): ?><span style="background:<?=$c[$d]?>"></span><?php endforeach; ?></div></div>
        <?php if($on): ?><span class="adm-pill">مفعّل</span><?php else: ?><button class="btn xs">تطبيق</button><?php endif; ?>
      </div>
    </form>
    <?php endforeach; ?>
  </div>
</section>

<form method="post" class="settings-form"><?=csrf_field()?><input type="hidden" name="action" value="saveappearance">
  <section class="card" aria-labelledby="th-look">
    <div class="card-head"><div><h2 id="th-look">الخط والشكل</h2><p class="muted sm">يسري على كل صفحات الموقع.</p></div></div>
    <div class="form pad">
      <div class="field"><label for="site_font">خط الموقع</label>
        <select id="site_font" name="site_font"><?php foreach(font_options() as $v=>$l): ?><option value="<?=e($v)?>" <?=site_font()===$v?'selected':''?> style="font-family:'<?=e($v)?>'"><?=e($l)?></option><?php endforeach; ?></select></div>
      <div class="field"><label for="ui_radius">استدارة الزوايا: <b id="radius-val" dir="ltr"><?=(int)setting('ui_radius','8')?>px</b></label>
        <input id="ui_radius" type="range" name="ui_radius" min="0" max="24" value="<?=(int)setting('ui_radius','8')?>" oninput="document.getElementById('radius-val').textContent=this.value+'px';document.documentElement.style.setProperty('--radius',this.value+'px')"></div>
      <label class="switch-row"><span><b>السماح للزوار باختيار المظهر</b><small>يظهر زر «المظهر» في الشريط العلوي يتيح لكل زائر اختيار قالب يُحفظ على جهازه.</small></span><input type="checkbox" class="toggle" name="theme_switcher" value="1" <?=setting('theme_switcher','1')==='1'?'checked':''?>></label>
    </div>
  </section>
  <section class="card" aria-labelledby="th-code">
    <div class="card-head"><div><h2 id="th-code">أكواد مخصصة</h2><p class="muted sm">للمستخدمين المتقدمين: تُضاف لكل صفحات الموقع العامة (لا تؤثر على لوحة التحكم).</p></div></div>
    <div class="form pad">
      <div class="field"><label for="custom_css">CSS مخصص</label><textarea id="custom_css" name="custom_css" rows="6" dir="ltr" class="mono" maxlength="20000" placeholder=".hero h1{letter-spacing:-1px}"><?=e(setting('custom_css',''))?></textarea></div>
      <div class="field"><label for="custom_head">كود داخل &lt;head&gt;</label><textarea id="custom_head" name="custom_head" rows="4" dir="ltr" class="mono" maxlength="20000" placeholder="<!-- Google Analytics, Meta Pixel... -->"><?=e(setting('custom_head',''))?></textarea></div>
      <div class="field"><label for="custom_footer">كود قبل نهاية الصفحة</label><textarea id="custom_footer" name="custom_footer" rows="4" dir="ltr" class="mono" maxlength="20000" placeholder="<script>...</script>"><?=e(setting('custom_footer',''))?></textarea></div>
    </div>
  </section>
  <div class="sticky-save"><button class="btn">حفظ المظهر</button></div>
</form>
