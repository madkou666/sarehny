<?php defined('IN_ADMIN') || exit; ?>
<div class="adm-head"><div><h1>الدعم الفني المباشر</h1><p class="muted">محادثات الزوار والمستخدمين لحظيًا. تتحدث القائمة تلقائيًا كل بضع ثوانٍ.</p></div>
<form method="post" class="sup-toggle"><?=csrf_field()?><input type="hidden" name="action" value="support_toggle"><button class="btn sm <?=setting('support_enabled','1')==='1'?'ghost':''?>"><?=setting('support_enabled','1')==='1'?'إيقاف الشات في الموقع':'تفعيل الشات في الموقع'?></button></form></div>
<style>
.sup-wrap{display:grid;grid-template-columns:320px 1fr;gap:16px;min-height:560px}
.sup-list{display:flex;flex-direction:column;overflow:hidden}
.sup-filters{display:flex;gap:6px;padding:10px 12px;border-bottom:1px solid var(--border)}
.sup-filters button{flex:1;border:1px solid var(--border);background:transparent;color:var(--ink);border-radius:8px;padding:6px;cursor:pointer;font:inherit;font-size:13px}
.sup-tools{display:grid;gap:9px;padding:10px 12px;border-bottom:1px solid var(--border)}
.sup-search{width:100%;min-height:38px;padding:8px 10px;border:1px solid var(--border-2);border-radius:8px;background:var(--bg);color:var(--ink);font:inherit;font-size:13px}
.sup-unread{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:12px;cursor:pointer}
.sup-unread input{accent-color:var(--primary)}
.sup-th[hidden]{display:none}
.sup-form button[disabled]{opacity:.55;cursor:wait}
.sup-filters button.on{background:var(--primary);color:var(--on-primary,var(--surface));border-color:var(--primary)}
.sup-threads{overflow:auto;max-height:520px}
.sup-th{display:block;width:100%;text-align:start;padding:12px 14px;border:0;border-bottom:1px solid var(--border);background:transparent;color:var(--ink);cursor:pointer;font:inherit}
.sup-th:hover,.sup-th.on{background:var(--primary-50)}
.sup-th b{display:flex;justify-content:space-between;gap:8px;font-size:14px}
.sup-th small{display:block;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:3px}
.sup-badge{background:var(--red);color:#fff;border-radius:99px;font-size:11px;padding:1px 7px}
.sup-chat{display:flex;flex-direction:column;overflow:hidden}
.sup-msgs{flex:1;overflow:auto;padding:16px;display:flex;flex-direction:column;gap:8px;max-height:440px;min-height:300px}
.sup-m{max-width:75%;padding:9px 13px;border-radius:14px;white-space:pre-wrap;word-break:break-word;font-size:14px;line-height:1.6}
.sup-m small{display:block;opacity:.65;font-size:11px;margin-top:3px}
.sup-m.user{align-self:flex-start;background:var(--bg);border:1px solid var(--border)}
.sup-m.admin{align-self:flex-end;background:var(--primary);color:var(--on-primary,var(--surface))}
.sup-form{display:flex;gap:8px;padding:12px;border-top:1px solid var(--border)}
.sup-form textarea{flex:1;resize:none;height:46px;border:1px solid var(--border);border-radius:10px;padding:10px;font:inherit;background:var(--surface);color:var(--ink)}
.sup-empty{margin:auto;color:var(--muted);text-align:center;padding:40px}
@media(max-width:860px){.sup-wrap{grid-template-columns:1fr}}
</style>
<div class="sup-wrap">
  <section class="card sup-list">
    <div class="sup-filters"><button data-f="open" class="on">المفتوحة</button><button data-f="closed">المغلقة</button><button data-f="all">الكل</button></div>
    <div class="sup-tools"><input class="sup-search" id="supSearch" type="search" aria-label="البحث في المحادثات" placeholder="ابحث باسم الزائر أو محتوى الرسالة"><label class="sup-unread"><input type="checkbox" id="supUnread"> المحادثات غير المقروءة فقط</label></div>
    <div class="sup-threads" id="supThreads"><div class="sup-empty">جارٍ التحميل…</div><div class="sup-empty" id="supNoMatches" hidden>لا توجد محادثات مطابقة للبحث.</div></div>
  </section>
  <section class="card sup-chat">
    <div class="card-head"><h2 id="supTitle">اختر محادثة</h2><div id="supActs" style="display:none;gap:6px"><button class="btn xs ghost" id="supClose">إغلاق</button><button class="btn xs ghost" id="supDel">حذف</button></div></div>
    <div class="sup-msgs" id="supMsgs"><div class="sup-empty">اختر محادثة من القائمة للرد عليها.</div></div>
    <form class="sup-form" id="supForm" style="display:none"><textarea id="supInput" maxlength="2000" placeholder="اكتب ردك… (Enter للإرسال)"></textarea><button class="btn">إرسال</button></form>
  </section>
</div>
<script>
(function(){
  var CSRF=<?=json_encode(csrf())?>,f='open',cur=0,last=0,status='open',busy=false;
  var $=function(i){return document.getElementById(i)};
  function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML}
  function api(a,p,post){var u='support.php?a='+a+(p?'&'+p:'');var o={credentials:'same-origin',headers:{'X-CSRF':CSRF}};if(post){post.append('csrf',CSRF);o.method='POST';o.body=post}return fetch(u,o).then(function(r){return r.json()})}
  function filterThreads(){var query=$('supSearch').value.trim().toLocaleLowerCase('ar'),unreadOnly=$('supUnread').checked,visible=0;document.querySelectorAll('.sup-th').forEach(function(thread){var matches=thread.textContent.toLocaleLowerCase('ar').indexOf(query)!==-1,unread=+thread.dataset.unread>0;thread.hidden=!matches||(unreadOnly&&!unread);if(!thread.hidden)visible++});var empty=$('supNoMatches');if(empty)empty.hidden=visible>0||!document.querySelector('.sup-th')}
  function loadThreads(){api('admin_threads','f='+f).then(function(d){if(!d.ok)return;var h='';d.threads.forEach(function(t){h+='<button class="sup-th'+(t.id==cur?' on':'')+'" data-id="'+t.id+'" data-unread="'+(+t.unread_admin||0)+'"><b><span>'+esc(t.name)+(t.username?' <small style="display:inline">@'+esc(t.username)+'</small>':'')+'</span>'+(t.unread_admin>0?'<span class="sup-badge">'+t.unread_admin+'</span>':'')+'</b><small>'+esc(t.last_body||'')+'</small><small>'+esc(t.last_at)+(t.status=='closed'?' · مغلقة':'')+'</small></button>'});$('supThreads').innerHTML=h||'<div class="sup-empty">لا توجد محادثات</div>';filterThreads();document.title=(d.unread?'('+d.unread+') ':'')+'الدعم الفني'})}
  $('supSearch').addEventListener('input',filterThreads);$('supUnread').addEventListener('change',filterThreads);
  function render(ms){var box=$('supMsgs');if(!last)box.innerHTML='';ms.forEach(function(m){last=Math.max(last,+m.id);var el=document.createElement('div');el.className='sup-m '+m.sender;el.innerHTML=esc(m.body)+'<small>'+esc(m.created_at)+'</small>';box.appendChild(el)});if(ms.length)box.scrollTop=box.scrollHeight}
  function loadThread(){if(!cur||busy)return;api('admin_thread','id='+cur+'&after='+last).then(function(d){if(!d.ok)return;var t=d.thread;status=t.status;$('supTitle').textContent=t.name+(t.email?' · '+t.email:'');$('supClose').textContent=t.status=='closed'?'إعادة فتح':'إغلاق';render(d.messages);if(!last)$('supMsgs').innerHTML='<div class="sup-empty">لا توجد رسائل</div>'})}
  document.querySelector('.sup-filters').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;f=b.dataset.f;this.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b)});loadThreads()});
  $('supThreads').addEventListener('click',function(e){var b=e.target.closest('.sup-th');if(!b)return;cur=+b.dataset.id;last=0;$('supMsgs').innerHTML='';$('supForm').style.display='flex';$('supActs').style.display='flex';loadThread();loadThreads();$('supInput').focus()});
  $('supForm').addEventListener('submit',function(e){e.preventDefault();var v=$('supInput').value.trim();if(!v||busy)return;busy=true;var send=$('supForm').querySelector('button');send.disabled=true;var fd=new FormData();fd.append('body',v);api('admin_reply','id='+cur+'&after='+last,fd).then(function(d){busy=false;send.disabled=false;if(d.ok){$('supInput').value='';render(d.messages);loadThreads()}else alert(d.error)}).catch(function(){busy=false;send.disabled=false})});
  $('supInput').addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){if(e.isComposing||e.keyCode===229)return;e.preventDefault();$('supForm').requestSubmit()}});
  $('supClose').onclick=function(){api(status=='closed'?'admin_open':'admin_close','id='+cur,new FormData()).then(function(){loadThread();loadThreads()})};
  $('supDel').onclick=function(){if(!confirm('حذف المحادثة نهائيًا؟'))return;api('admin_delete','id='+cur,new FormData()).then(function(){cur=0;last=0;$('supMsgs').innerHTML='<div class="sup-empty">تم الحذف</div>';$('supForm').style.display='none';$('supActs').style.display='none';loadThreads()})};
  loadThreads();setInterval(loadThreads,5000);setInterval(loadThread,3000);
})();
</script>
