<?php defined('IN_ADMIN') || exit;
$per=20; $total=$one('SELECT COUNT(*) FROM sender_bans');
$rows=$pdo->query('SELECT b.*,u.display_name admin_name,(SELECT COUNT(*) FROM messages m WHERE m.sender_ip_hash=b.ip_hash) mc FROM sender_bans b LEFT JOIN users u ON u.id=b.created_by ORDER BY b.created_at DESC LIMIT '.$per.' OFFSET '.(($page-1)*$per))->fetchAll();
?>
<div class="adm-head">
  <div><h1>المرسلون المحظورون</h1><p class="muted">المرسلون الممنوعون من إرسال رسائل جديدة. يتم الحظر من قسم الرسائل أو البلاغات.</p></div>
</div>

<div class="note-box"><?=icon('lock')?><p>لحماية الخصوصية لا يتم تخزين عناوين IP الحقيقية؛ يُحفظ فقط بصمة مشفّرة (SHA-256) لا يمكن عكسها، وتُستخدم لمنع المرسل نفسه من الإرسال مجددًا.</p></div>

<section class="card">
  <?php if(!$rows): ?>
    <div class="empty flat"><span class="empty-icon"><?=icon('shield')?></span><h2>لا يوجد مرسلون محظورون</h2><p>يمكنك حظر مرسل من زر &laquo;حظر المرسل&raquo; في قسم الرسائل.</p></div>
  <?php else: ?>
  <div class="table-wrap"><table class="adm-table">
    <thead><tr><th scope="col">البصمة</th><th scope="col">السبب</th><th scope="col">رسائله</th><th scope="col">بواسطة</th><th scope="col">التاريخ</th><th scope="col"><span class="sr-only">إجراءات</span></th></tr></thead>
    <tbody>
    <?php foreach($rows as $b): ?><tr>
      <td class="mono" dir="ltr" title="<?=e($b['ip_hash'])?>"><?=e(substr($b['ip_hash'],0,16))?>…</td>
      <td><?=e($b['note']??'—')?></td>
      <td><?=ar_num($b['mc'])?></td>
      <td><?=e($b['admin_name']??'—')?></td>
      <td class="muted"><?=ago($b['created_at'])?></td>
      <td><form method="post" class="row-actions end"><?=csrf_field()?><input type="hidden" name="hash" value="<?=e($b['ip_hash'])?>"><button class="btn xs ghost" name="action" value="unban" data-confirm="رفع الحظر عن هذا المرسل؟"><?=icon('check')?> رفع الحظر</button></form></td>
    </tr><?php endforeach; ?>
    </tbody></table></div>
  <?=pager($total,$per,$page,['t'=>'bans'])?>
  <?php endif; ?>
</section>
