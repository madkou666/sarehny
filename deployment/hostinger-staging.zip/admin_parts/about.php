<?php defined('IN_ADMIN') || exit; ?>
<div class="adm-head"><div><h1>حول أسرار</h1><p class="muted">محتوى صفحة التعريف بالموقع.</p></div><a class="btn sm ghost" href="about.php" target="_blank" rel="noopener">عرض الصفحة</a></div>
<section class="card"><div class="card-head"><h2>تحرير الصفحة</h2></div><form method="post" class="form pad"><?=csrf_field()?><input type="hidden" name="action" value="saveabout">
<div class="field"><label for="about_title">العنوان</label><input id="about_title" name="about_title" maxlength="180" required value="<?=e(setting('about_title','مساحة تجعل الصراحة أسهل'))?>"></div>
<div class="field"><label for="about_intro">المقدمة</label><textarea id="about_intro" name="about_intro" maxlength="600" rows="3" required><?=e(setting('about_intro','أسرار مساحة لمشاركة الكلمات الصادقة. أنشئ رابطًا خاصًا بك واستقبل رسائل من الآخرين دون ظهور أسمائهم لك.'))?></textarea></div>
<div class="field"><label for="about_body">تفاصيل إضافية</label><textarea id="about_body" name="about_body" maxlength="8000" rows="9" placeholder="اكتب قصتك أو رسالة الموقع هنا. كل سطر جديد يظهر كفقرة منفصلة."><?=e(setting('about_body',''))?></textarea></div>
<button class="btn"><?=icon('check')?> حفظ الصفحة</button></form></section>
