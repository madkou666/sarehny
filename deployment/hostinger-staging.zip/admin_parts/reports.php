<?php defined('IN_ADMIN') || exit;
$filters=['pending'=>'معلّقة','removed'=>'تم الإخفاء','dismissed'=>'مرفوضة','all'=>'الكل'];
if(!isset($filters[$f])) $f='pending';
$params=[]; $where=[];
if($f!=='all'){$where[]='r.status=?';$params[]=$f;}
if($q!==''){$where[]='(m.body LIKE ? OR r.details LIKE ? OR u.username LIKE ? OR ru.username LIKE ?)';$sq='%'.$q.'%';array_push($params,$sq,$sq,$sq,$sq);}
$condition=$where?implode(' AND ',$where):'1=1'; $per=15;
$joins=' FROM reports r JOIN messages m ON m.id=r.message_id JOIN users u ON u.id=r.reporter_id JOIN users ru ON ru.id=m.recipient_id';
$total=$one('SELECT COUNT(*)'.$joins.' WHERE '.$condition,$params);
$s=$pdo->prepare("SELECT r.*,m.body,m.sender_ip_hash,u.username rep,ru.username recip,ad.display_name reviewer,COALESCE(pc.pending_total,0) pending_total $joins LEFT JOIN users ad ON ad.id=r.reviewed_by LEFT JOIN (SELECT message_id,COUNT(*) pending_total FROM reports WHERE status='pending' GROUP BY message_id) pc ON pc.message_id=r.message_id WHERE $condition ORDER BY CASE WHEN r.status='pending' THEN COALESCE(pc.pending_total,0) ELSE 0 END DESC,r.id DESC LIMIT $per OFFSET ".(($page-1)*$per));
$s->execute($params); $rows=$s->fetchAll();
$counts=[]; foreach(['pending','removed','dismissed'] as $k) $counts[$k]=$one('SELECT COUNT(*) FROM reports WHERE status=?',[$k]); $counts['all']=array_sum($counts);
$pendingMessages=$one("SELECT COUNT(DISTINCT message_id) FROM reports WHERE status='pending'");
$repeatedMessages=$one("SELECT COUNT(*) FROM (SELECT message_id FROM reports WHERE status='pending' GROUP BY message_id HAVING COUNT(*)>1) repeated");
$oldestPending=$pdo->query("SELECT created_at FROM reports WHERE status='pending' ORDER BY created_at ASC,id ASC LIMIT 1")->fetchColumn();
$st=['pending'=>['معلّق','amber'],'dismissed'=>['مرفوض','gray'],'removed'=>['تم الإخفاء','red']];
$base=['t'=>'reports','f'=>$f==='pending'?'':$f,'q'=>$q];
?>
<div class="adm-head">
  <div><span class="message-eyebrow"><?=icon('flag')?> مركز مراجعة البلاغات</span><h1>البلاغات</h1><p class="muted">رتّب البلاغات بحسب تكرارها، وراجع النتائج أو صدّرها ضمن تصنيفك الحالي.</p></div>
  <div class="report-head-actions">
    <form method="post"><?=csrf_field()?><input type="hidden" name="action" value="export"><input type="hidden" name="what" value="reports"><input type="hidden" name="f" value="<?=e($f)?>"><input type="hidden" name="q" value="<?=e($q)?>"><button class="btn sm ghost"><?=icon('download')?> تصدير النتائج CSV</button></form>
    <?php if($counts['removed']+$counts['dismissed']): ?>
    <form method="post"><?=csrf_field()?><button class="btn sm ghost" name="action" value="purgereports" data-confirm="حذف كل البلاغات المغلقة (المرفوضة والمقبولة)؟"><?=icon('trash')?> تنظيف البلاغات المغلقة</button></form>
    <?php endif; ?>
  </div>
</div>

<div class="message-stats report-stats" aria-label="ملخص مراجعة البلاغات">
  <div class="message-stat-card"><span class="message-stat-icon tone-red"><?=icon('flag')?></span><span class="message-stat-copy"><span>بلاغات تنتظر المراجعة</span><b><?=ar_num(number_format($counts['pending']))?></b></span></div>
  <div class="message-stat-card"><span class="message-stat-icon tone-blue"><?=icon('message')?></span><span class="message-stat-copy"><span>رسائل تحتاج إلى مراجعة</span><b><?=ar_num(number_format($pendingMessages))?></b></span></div>
  <div class="message-stat-card"><span class="message-stat-icon tone-amber"><?=icon('filter')?></span><span class="message-stat-copy"><span>رسائل ببلاغات متكررة</span><b><?=ar_num(number_format($repeatedMessages))?></b></span></div>
  <div class="message-stat-card"><span class="message-stat-icon tone-violet"><?=icon('clock')?></span><span class="message-stat-copy"><span>أقدم بلاغ معلّق</span><b class="report-oldest-value"><?=$oldestPending?e(ago($oldestPending)):'لا توجد بلاغات'?></b></span></div>
</div>

<div class="toolbar-adm">
  <nav class="chips" aria-label="تصفية البلاغات">
    <?php foreach($filters as $k=>$l): ?><a href="<?=e(admin_url(array_merge($base,['f'=>$k==='pending'?'':$k,'p'=>''])))?>" class="<?=$f===$k?'on':''?>" <?=$f===$k?'aria-current="true"':''?>><?=$l?> <span><?=ar_num($counts[$k])?></span></a><?php endforeach; ?>
  </nav>
  <form class="search" role="search"><input type="hidden" name="t" value="reports"><?php if($f!=='pending'): ?><input type="hidden" name="f" value="<?=e($f)?>"><?php endif; ?><?=icon('search')?><input name="q" aria-label="بحث في البلاغات" placeholder="ابحث في الرسالة أو اسم المستخدم" value="<?=e($q)?>"></form>
</div>

<?php if(!$rows): ?>
  <div class="empty"><span class="empty-icon"><?=icon('shield')?></span><h2>لا توجد بلاغات مطابقة</h2><p><?=$q!==''?'جرّب كلمات بحث مختلفة أو غيّر حالة البلاغ.':($f==='pending'?'كل شيء هادئ حاليًا، لا توجد بلاغات بانتظار المراجعة.':'لا توجد بلاغات في هذا التصنيف.')?></p></div>
<?php else: ?>
<form method="post" id="reports-bulk-form" hidden><?=csrf_field()?><input type="hidden" name="action" value="bulkreports"></form>
<div class="list-head reports-bulk-toolbar">
  <label class="check"><input type="checkbox" data-check-all aria-label="تحديد كل البلاغات في هذه الصفحة"><span>تحديد بلاغات الصفحة <span class="muted sm">(<?=ar_num(count($rows))?>)</span></span></label>
  <div class="bulk-bar" id="reports-bulk-bar" aria-live="polite">
    <span class="muted sm">المحدد: <b id="reports-bulk-count">0</b></span>
    <button class="btn xs danger-soft" form="reports-bulk-form" name="bulk_op" value="remove" data-confirm="قبول البلاغات المحددة وإخفاء الرسائل المرتبطة بها؟"><?=icon('eye-off')?> قبول وإخفاء</button>
    <button class="btn xs ghost" form="reports-bulk-form" name="bulk_op" value="dismiss" data-confirm="رفض البلاغات المحددة؟"><?=icon('x')?> رفض البلاغات</button>
  </div>
</div>
<div class="list report-list">
  <?php foreach($rows as $r): ?>
  <article class="card report-card<?=$r['status']==='pending'?' pending':''?>">
    <?php if($r['status']==='pending'): ?><label class="report-select"><input type="checkbox" name="ids[]" value="<?=(int)$r['id']?>" form="reports-bulk-form" aria-label="تحديد البلاغ رقم <?=ar_num((int)$r['id'])?>"><span>تحديد البلاغ</span></label><?php endif; ?>
    <div class="item-meta">
      <span class="tag <?=$st[$r['status']][1]?>"><?=$st[$r['status']][0]?></span>
      <span class="tag"><?=e($reasons[$r['reason']]??$r['reason'])?></span>
      <?php if($r['status']==='pending'&&(int)$r['pending_total']>1): ?><span class="tag amber report-repeat-tag"><?=ar_num((int)$r['pending_total'])?> بلاغات على الرسالة نفسها</span><?php endif; ?>
      <span class="muted sm">من <span dir="ltr">@<?=e($r['rep'])?></span> بخصوص رسالة إلى <span dir="ltr">@<?=e($r['recip'])?></span> · <?=ago($r['created_at'])?></span>
    </div>
    <blockquote class="quote"><?=e($r['body'])?></blockquote>
    <?php if($r['details']): ?><p class="muted sm">تفاصيل البلاغ: <?=e($r['details'])?></p><?php endif; ?>
    <?php if($r['status']==='pending'): ?>
    <form method="post" class="row-actions"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>">
      <button class="btn sm danger" name="action" value="remove"><?=icon('eye-off')?> قبول وإخفاء الرسالة</button>
      <button class="btn sm ghost" name="action" value="dismiss"><?=icon('x')?> رفض البلاغ</button>
    </form>
    <?php if($r['sender_ip_hash']): ?>
    <form method="post" class="row-actions" action="<?=e(admin_url($base))?>"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['message_id']?>"><input type="hidden" name="note" value="بسبب بلاغ #<?=(int)$r['id']?>">
      <button class="btn xs ghost" name="action" value="bansender" data-confirm="حظر مرسل هذه الرسالة من إرسال أي رسائل جديدة؟"><?=icon('ban')?> حظر المرسل أيضًا</button>
    </form>
    <?php endif; ?>
    <?php else: ?>
      <p class="muted sm">تمت المراجعة بواسطة <?=e($r['reviewer']??'—')?><?=$r['reviewed_at']?' · '.ago($r['reviewed_at']):''?></p>
    <?php endif; ?>
  </article>
  <?php endforeach; ?>
</div>
<?=pager($total,$per,$page,$base)?>
<?php endif; ?>
