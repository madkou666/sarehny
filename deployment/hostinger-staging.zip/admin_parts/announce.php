<?php defined('IN_ADMIN') || exit;
$type=setting('ann_type','info'); $types=['info'=>['معلومة','megaphone'],'success'=>['إيجابي','check'],'warning'=>['تنبيه','alert']];
?>
<div class="adm-head">
  <div><h1>الإعلانات</h1><p class="muted">اعرض شريط إعلان يظهر أعلى كل صفحات الموقع لجميع الزوار.</p></div>
  <?=setting('ann_active','0')==='1'?'<span class="tag violet lg">الإعلان ظاهر الآن</span>':'<span class="tag gray lg">لا يوجد إعلان ظاهر</span>'?>
</div>

<section class="card">
  <form method="post" class="form pad"><?=csrf_field()?><input type="hidden" name="action" value="saveann">
    <div class="field"><label for="ann_text">نص الإعلان</label>
      <div class="textarea-wrap"><textarea id="ann_text" name="ann_text" rows="3" maxlength="300" data-count="ann-cnt" placeholder="مثال: تم إطلاق ميزة جديدة! جرّبها الآن."><?=e(setting('ann_text',''))?></textarea><span class="counter" id="ann-cnt" dir="ltr">0 / 300</span></div></div>
    <fieldset class="field"><legend>نوع الإعلان</legend>
      <div class="radio-cards">
        <?php foreach($types as $k=>[$l,$ic]): ?>
        <label class="radio-card <?=$k?>"><input type="radio" name="ann_type" value="<?=$k?>" <?=$type===$k?'checked':''?>><?=icon($ic)?><span><?=$l?></span></label>
        <?php endforeach; ?>
      </div>
    </fieldset>
    <label class="switch-row"><span><b>إظهار الإعلان</b><small>عند التفعيل سيظهر الشريط في كل صفحات الموقع.</small></span>
      <input type="checkbox" class="toggle" name="ann_active" value="1" <?=setting('ann_active','0')==='1'?'checked':''?>></label>
    <div class="field"><span class="label">معاينة</span>
      <div id="ann-preview" class="announce <?=e($type)?>"><div class="announce-in"><?=icon('megaphone')?><span id="ann-preview-text"></span></div></div></div>
    <div class="row-actions"><button class="btn"><?=icon('check')?> حفظ الإعلان</button></div>
  </form>
</section>
