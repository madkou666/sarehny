<?php defined('IN_ADMIN') || exit;
$trend=function($now,$prev){
  if($prev==0) return $now>0?['+100٪','up']:['٠٪','flat'];
  $p=round(($now-$prev)/$prev*100); return [($p>0?'+':'').ar_num($p).'٪',$p>0?'up':($p<0?'down':'flat')];
};
$usersWeek=$one('SELECT COUNT(*) FROM users WHERE created_at>NOW()-INTERVAL 7 DAY');
$usersPrev=$one('SELECT COUNT(*) FROM users WHERE created_at<=NOW()-INTERVAL 7 DAY AND created_at>NOW()-INTERVAL 14 DAY');
$msgWeek=$one('SELECT COUNT(*) FROM messages WHERE created_at>NOW()-INTERVAL 7 DAY');
$msgPrev=$one('SELECT COUNT(*) FROM messages WHERE created_at<=NOW()-INTERVAL 7 DAY AND created_at>NOW()-INTERVAL 14 DAY');
$today=$one('SELECT COUNT(*) FROM messages WHERE created_at>NOW()-INTERVAL 1 DAY');
$yesterday=$one('SELECT COUNT(*) FROM messages WHERE created_at<=NOW()-INTERVAL 1 DAY AND created_at>NOW()-INTERVAL 2 DAY');
$kpis=[
  ['المستخدمون',$one('SELECT COUNT(*) FROM users'),'users','violet',$trend($usersWeek,$usersPrev),'جديد هذا الأسبوع: '.ar_num($usersWeek),'users'],
  ['إجمالي الرسائل',$one('SELECT COUNT(*) FROM messages'),'mail','blue',$trend($msgWeek,$msgPrev),'هذا الأسبوع: '.ar_num($msgWeek),'messages'],
  ['رسائل آخر ٢٤ ساعة',$today,'clock','green',$trend($today,$yesterday),'مقارنة بالأمس','messages'],
  ['بلاغات معلّقة',$pending,'flag','amber',null,$pending?'تحتاج إلى مراجعة':'لا يوجد ما يحتاج مراجعة','reports'],
];
$minor=[
  ['حسابات معطّلة',$one('SELECT COUNT(*) FROM users WHERE is_disabled=1'),'ban'],
  ['المديرون',$one('SELECT COUNT(*) FROM users WHERE is_admin=1'),'crown'],
  ['رسائل مخفية',$one('SELECT COUNT(*) FROM messages WHERE is_removed=1'),'eye-off'],
  ['كلمات محظورة',$one('SELECT COUNT(*) FROM banned_words'),'filter'],
  ['مرسلون محظورون',$one('SELECT COUNT(*) FROM sender_bans'),'shield'],
];

$rangeDays=(int)($_GET['range']??14);
if(!in_array($rangeDays,[7,14,30],true)) $rangeDays=14;
$todayDb=$pdo->query('SELECT CURDATE()')->fetchColumn();
$startDate=date('Y-m-d',strtotime($todayDb.' -'.($rangeDays-1).' day'));
$days=[]; for($i=$rangeDays-1;$i>=0;$i--){ $d=date('Y-m-d',strtotime($todayDb.' -'.$i.' day')); $days[$d]=['m'=>0,'u'=>0]; }
$msgDaily=$pdo->prepare('SELECT DATE(created_at) d,COUNT(*) c FROM messages WHERE created_at>=? GROUP BY d');
$msgDaily->execute([$startDate]);
foreach($msgDaily as $r) if(isset($days[$r['d']])) $days[$r['d']]['m']=(int)$r['c'];
$userDaily=$pdo->prepare('SELECT DATE(created_at) d,COUNT(*) c FROM users WHERE created_at>=? GROUP BY d');
$userDaily->execute([$startDate]);
foreach($userDaily as $r) if(isset($days[$r['d']])) $days[$r['d']]['u']=(int)$r['c'];
$max=max(1,max(array_map(fn($d)=>max($d['m'],$d['u']),$days)));
$sumM=array_sum(array_column($days,'m')); $sumU=array_sum(array_column($days,'u'));

$top=$pdo->query('SELECT u.display_name,u.username,u.avatar,COUNT(m.id) c FROM users u JOIN messages m ON m.recipient_id=u.id GROUP BY u.id ORDER BY c DESC LIMIT 5')->fetchAll();
$newest=$pdo->query('SELECT display_name,username,avatar,created_at,is_admin FROM users ORDER BY id DESC LIMIT 5')->fetchAll();
$recentLogs=$pdo->query('SELECT l.*,u.display_name FROM admin_logs l LEFT JOIN users u ON u.id=l.admin_id ORDER BY l.id DESC LIMIT 6')->fetchAll();
$reasonStats=$pdo->query("SELECT reason,COUNT(*) c FROM reports GROUP BY reason ORDER BY c DESC")->fetchAll();
$reasonTotal=max(1,array_sum(array_column($reasonStats,'c')));
?>
<section class="overview-hero" aria-labelledby="overview-title">
  <div class="overview-hero-copy"><span class="overview-eyebrow"><?=icon('chart')?> لوحة متابعة الموقع</span><h1 id="overview-title">مرحبًا، <?=e($me['display_name'])?></h1><p>إليك ملخص نشاط <?=e($siteName)?> وأهم ما يحتاج إلى متابعتك.</p><span class="overview-date"><?=icon('calendar')?><?=ar_num(date('Y/m/d'))?></span></div>
  <div class="overview-hero-actions"><a class="btn primary" href="<?=e(admin_url(['t'=>'messages']))?>"><?=icon('inbox')?><span>إدارة الرسائل</span></a><a class="btn ghost" href="<?=e(admin_url(['t'=>'settings']))?>"><?=icon('settings')?><span>إعدادات الموقع</span></a><?php if($pending): ?><a class="overview-alert-link" href="<?=e(admin_url(['t'=>'reports']))?>"><?=icon('flag')?><span><?=ar_num($pending)?> بلاغات بانتظار المراجعة</span><?=icon('arrow')?></a><?php endif; ?></div>
</section>
<section class="overview-section-heading"><div><span class="overview-section-kicker">نظرة عامة</span><h2>ملخص الأداء</h2></div><span class="overview-live"><?=icon('activity')?>مؤشرات محدثة</span></section>

<div class="kpi-grid">
  <?php foreach($kpis as [$label,$val,$ic,$tone,$tr,$sub,$target]): ?>
  <a class="kpi kpi-link" href="<?=e(admin_url(['t'=>$target]))?>" aria-label="<?=e($label)?>: <?=ar_num(number_format($val))?> — فتح القسم">
    <div class="kpi-top"><span class="stat-icon <?=$tone?>"><?=icon($ic)?></span>
      <?php if($tr): ?><span class="trend <?=$tr[1]?>"><?=icon($tr[1]==='down'?'trend-down':'trend-up')?><?=$tr[0]?></span><?php endif; ?></div>
    <b class="kpi-val"><?=ar_num(number_format($val))?></b>
    <span class="kpi-label"><?=e($label)?></span>
    <span class="kpi-sub"><?=e($sub)?><span class="kpi-open-hint"><?=icon('arrow')?></span></span>
  </a>
  <?php endforeach; ?>
</div>

<div class="mini-row">
  <?php foreach($minor as [$l,$v,$ic]): ?><div class="mini"><?=icon($ic)?><span><?=e($l)?></span><b><?=ar_num($v)?></b></div><?php endforeach; ?>
</div>

<section class="quick-actions" aria-labelledby="quick-actions-heading">
  <div class="quick-actions-head"><div><h2 id="quick-actions-heading">إجراءات سريعة</h2><p>انتقل مباشرة إلى أكثر مهام الإدارة استخدامًا.</p></div></div>
  <div class="quick-actions-grid">
    <a class="quick-action" href="<?=e(admin_url(['t'=>'messages']))?>"><span class="quick-action-icon messages"><?=icon('inbox')?></span><span><b>إدارة الرسائل</b><small>استعراض الوارد ومراجعته</small></span><?=icon('arrow','quick-action-arrow')?></a>
    <a class="quick-action" href="<?=e(admin_url(['t'=>'reports']))?>"><span class="quick-action-icon reports"><?=icon('flag')?></span><span><b>مراجعة البلاغات</b><small><?=$pending?'بلاغات بانتظار المراجعة: '.ar_num($pending):'متابعة البلاغات وإدارتها'?></small></span><?=icon('arrow','quick-action-arrow')?></a>
    <a class="quick-action" href="<?=e(admin_url(['t'=>'announce']))?>"><span class="quick-action-icon announce"><?=icon('megaphone')?></span><span><b>نشر إعلان</b><small>تحديث الرسالة الظاهرة للزوار</small></span><?=icon('arrow','quick-action-arrow')?></a>
    <a class="quick-action" href="<?=e(admin_url(['t'=>'themes']))?>"><span class="quick-action-icon appearance"><?=icon('grid')?></span><span><b>تخصيص المظهر</b><small>إدارة القوالب وألوان الموقع</small></span><?=icon('arrow','quick-action-arrow')?></a>
  </div>
</section>

<div class="adm-grid-2">
  <section class="card span-2" aria-labelledby="chart-h">
    <div class="card-head chart-card-head"><div><h2 id="chart-h">النشاط خلال آخر <?=ar_num($rangeDays)?> يومًا</h2><p class="muted sm"><?=ar_num($sumM)?> رسالة · <?=ar_num($sumU)?> مستخدم جديد</p></div>
      <div class="chart-tools"><div class="chart-period" role="group" aria-label="الفترة الزمنية للرسم">
        <?php foreach([7=>'٧ أيام',14=>'١٤ يومًا',30=>'٣٠ يومًا'] as $period=>$label): ?><a href="<?=e(admin_url(['range'=>$period]))?>" class="<?=$rangeDays===$period?'on':''?>" <?=$rangeDays===$period?'aria-current="true"':''?>><?=$label?></a><?php endforeach; ?>
      </div><div class="legend"><span><i class="dot m"></i>الرسائل</span><span><i class="dot u"></i>مستخدمون جدد</span></div></div></div>
    <div class="chart" style="--chart-days:<?=count($days)?>" role="img" aria-label="رسم بياني لعدد الرسائل والمستخدمين الجدد خلال آخر <?=ar_num($rangeDays)?> يومًا">
      <?php foreach($days as $d=>$v): ?>
      <div class="chart-col" title="<?=e(ar_num(date('m/d',strtotime($d))))?>: <?=ar_num($v['m'])?> رسالة، <?=ar_num($v['u'])?> مستخدم">
        <div class="bars"><span class="bar m" style="height:<?=round($v['m']/$max*100,1)?>%"></span><span class="bar u" style="height:<?=round($v['u']/$max*100,1)?>%"></span></div>
        <small><?=ar_num(date('d',strtotime($d)))?></small>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="card" aria-labelledby="top-h">
    <div class="card-head"><h2 id="top-h">الأكثر استقبالًا للرسائل</h2></div>
    <?php if(!$top): ?><p class="muted pad">لا توجد بيانات بعد.</p><?php else: ?>
    <ul class="rank"><?php foreach($top as $i=>$t): ?><li><span class="rank-n"><?=ar_num($i+1)?></span><?=avatar_html($t,'sm')?><div class="grow"><b><?=e($t['display_name'])?></b><small dir="ltr">@<?=e($t['username'])?></small></div><span class="tag"><?=ar_num($t['c'])?> رسالة</span></li><?php endforeach; ?></ul>
    <?php endif; ?>
  </section>

  <section class="card" aria-labelledby="new-h">
    <div class="card-head"><h2 id="new-h">أحدث المستخدمين</h2><a class="link-more" href="<?=e(admin_url(['t'=>'users']))?>">عرض الكل</a></div>
    <?php if(!$newest): ?><p class="muted pad">لا يوجد مستخدمون.</p><?php else: ?>
    <ul class="rank"><?php foreach($newest as $u): ?><li><?=avatar_html($u,'sm')?><div class="grow"><b><?=e($u['display_name'])?></b><small dir="ltr">@<?=e($u['username'])?></small></div><span class="muted sm"><?=ago($u['created_at'])?></span></li><?php endforeach; ?></ul>
    <?php endif; ?>
  </section>

  <section class="card" aria-labelledby="reasons-h">
    <div class="card-head"><h2 id="reasons-h">أسباب البلاغات</h2></div>
    <?php if(!$reasonStats): ?><p class="muted pad">لا توجد بلاغات حتى الآن.</p><?php else: ?>
    <ul class="bars-list"><?php foreach($reasonStats as $r): $pct=round($r['c']/$reasonTotal*100); ?>
      <li><div class="bl-top"><span><?=e($reasons[$r['reason']]??$r['reason'])?></span><b><?=ar_num($r['c'])?></b></div><div class="bl-track"><span style="width:<?=$pct?>%"></span></div></li>
    <?php endforeach; ?></ul>
    <?php endif; ?>
  </section>

  <section class="card" aria-labelledby="log-h">
    <div class="card-head"><h2 id="log-h">آخر نشاط إداري</h2><a class="link-more" href="<?=e(admin_url(['t'=>'logs']))?>">السجل الكامل</a></div>
    <?php if(!$recentLogs): ?><p class="muted pad">لم يُسجَّل أي نشاط بعد.</p><?php else: ?>
    <ul class="timeline"><?php foreach($recentLogs as $l): ?>
      <li><span class="tl-dot"></span><div><b><?=e($actionLabels[$l['action']]??$l['action'])?></b><?php if($l['details']): ?> <span class="muted">— <?=e($l['details'])?></span><?php endif; ?><small class="muted"><?=e($l['display_name']??'محذوف')?> · <?=ago($l['created_at'])?></small></div></li>
    <?php endforeach; ?></ul>
    <?php endif; ?>
  </section>

  <section class="card" aria-labelledby="status-h">
    <div class="card-head"><h2 id="status-h">حالة الموقع</h2><a class="link-more" href="<?=e(admin_url(['t'=>'settings']))?>">الإعدادات</a></div>
    <ul class="status-list">
      <li><span>التسجيل</span><?=setting('allow_register','1')==='1'?'<span class="tag green">مفتوح</span>':'<span class="tag red">مغلق</span>'?></li>
      <li><span>استقبال الرسائل</span><?=setting('messages_open','1')==='1'?'<span class="tag green">يعمل</span>':'<span class="tag red">متوقف</span>'?></li>
      <li><span>وضع الصيانة</span><?=setting('maintenance','0')==='1'?'<span class="tag amber">مفعّل</span>':'<span class="tag gray">غير مفعّل</span>'?></li>
      <li><span>الإعلان العام</span><?=setting('ann_active','0')==='1'?'<span class="tag violet">ظاهر</span>':'<span class="tag gray">مخفي</span>'?></li>
      <li><span>الحد الأقصى للرسالة</span><b><?=ar_num(setting('max_len','1000'))?> حرف</b></li>
    </ul>
  </section>
</div>
