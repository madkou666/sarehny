(function () {
  var grid = document.getElementById('messageGrid');
  var search = document.getElementById('messageSearch');
  var sort = document.getElementById('messageSort');
  var count = document.getElementById('messageResultCount');
  var exportButton = document.querySelector('[data-export-csv]');
  var exportStatus = document.getElementById('dashboardExportStatus');
  var selectVisibleButton = document.querySelector('[data-select-visible]');
  var selectedExportButton = document.querySelector('[data-export-selected]');
  var selectionCount = document.querySelector('[data-selection-count]');
  var activityBars = Array.prototype.slice.call(document.querySelectorAll('[data-activity-age]'));
  var activityTotal = document.getElementById('activityTotal');
  var activityChart = document.querySelector('.activity-chart');
  var activityRangeButtons = Array.prototype.slice.call(document.querySelectorAll('[data-activity-range]'));

  function setActivityRange(range) {
    var total = 0;
    activityBars.forEach(function (bar) {
      var age = Number(bar.getAttribute('data-activity-age')) || 0;
      var visible = age < range;
      bar.hidden = !visible;
      if (visible) total += Number(bar.getAttribute('data-activity-count')) || 0;
    });
    if (activityTotal) activityTotal.firstChild.textContent = new Intl.NumberFormat('ar-EG').format(total);
    if (activityChart) activityChart.classList.toggle('week-chart', range === 7);
    activityRangeButtons.forEach(function (button) {
      var active = button.getAttribute('data-activity-range') === String(range);
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }

  activityRangeButtons.forEach(function (button) {
    button.addEventListener('click', function () {
      setActivityRange(Number(button.getAttribute('data-activity-range')) === 30 ? 30 : 7);
    });
  });
  setActivityRange(7);

  if (!grid || !search || !sort) return;

  var cards = Array.prototype.slice.call(grid.querySelectorAll('.msg'));
  var emptyState = document.createElement('p');
  emptyState.className = 'dashboard-no-results';
  emptyState.setAttribute('role', 'status');
  emptyState.textContent = 'لا توجد رسائل تطابق بحثك. جرّب كلمات أخرى.';
  emptyState.hidden = true;
  grid.insertAdjacentElement('afterend', emptyState);

  function updateMessages() {
    var query = search.value.trim().toLocaleLowerCase('ar');
    var visibleCount = 0;

    cards.forEach(function (card) {
      var text = (card.getAttribute('data-search') || '').toLocaleLowerCase('ar');
      var visible = !query || text.indexOf(query) !== -1;
      card.hidden = !visible;
      if (visible) visibleCount += 1;
    });

    cards.sort(function (a, b) {
      var aTime = Number(a.getAttribute('data-created')) || 0;
      var bTime = Number(b.getAttribute('data-created')) || 0;
      return sort.value === 'oldest' ? aTime - bTime : bTime - aTime;
    }).forEach(function (card) {
      grid.appendChild(card);
    });

    emptyState.hidden = visibleCount !== 0;
    if (count) {
      count.textContent = 'عرض ' + new Intl.NumberFormat('ar-EG').format(visibleCount) +
        ' من ' + new Intl.NumberFormat('ar-EG').format(cards.length) + ' رسالة';
    }
  }

  function syncSelection() {
    var selectedCards = cards.filter(function (card) { return card.querySelector('[data-message-select]').checked; });
    var visibleCards = cards.filter(function (card) { return !card.hidden; });
    var allVisibleSelected = visibleCards.length > 0 && visibleCards.every(function (card) { return card.querySelector('[data-message-select]').checked; });
    if (selectionCount) selectionCount.textContent = selectedCards.length ? 'تم تحديد ' + new Intl.NumberFormat('ar-EG').format(selectedCards.length) + ' رسائل' : 'لم يتم تحديد رسائل';
    if (selectedExportButton) selectedExportButton.disabled = selectedCards.length === 0;
    if (selectVisibleButton) {
      selectVisibleButton.textContent = allVisibleSelected ? 'إلغاء تحديد الظاهرة' : 'تحديد الرسائل الظاهرة';
      selectVisibleButton.setAttribute('aria-pressed', allVisibleSelected ? 'true' : 'false');
    }
    cards.forEach(function (card) { card.classList.toggle('selected', card.querySelector('[data-message-select]').checked); });
  }

  function exportCards(cardsToExport) {
    if (!cardsToExport.length) {
      if (exportStatus) exportStatus.textContent = 'لا توجد رسائل مطابقة للتصدير.';
      return;
    }
    var rows = [['الرسالة', 'النوع', 'تاريخ الاستلام', 'حالة الإجابة', 'الإجابة', 'المفضلة']];
    cardsToExport.forEach(function (card) {
      var body = card.querySelector('.msg-body');
      var receivedAt = card.querySelector('time');
      var answer = card.querySelector('.answer-form textarea');
      rows.push([
        body ? body.textContent.trim() : 'رسالة صوتية',
        card.classList.contains('question-msg') ? 'سؤال' : 'رسالة',
        receivedAt ? (receivedAt.getAttribute('datetime') || receivedAt.textContent.trim()) : '',
        card.classList.contains('question-msg') ? (card.querySelector('.answer-state') && card.querySelector('.answer-state').classList.contains('published') ? 'تمت الإجابة' : 'بانتظار الإجابة') : '—',
        answer ? answer.value : '',
        card.classList.contains('fav') ? 'نعم' : 'لا'
      ]);
    });
    var csv = '\uFEFF' + rows.map(function (row) {
      return row.map(function (value) {
        var cell = String(value == null ? '' : value);
        if (/^[\t\r ]*[=+@-]/.test(cell)) cell = "'" + cell;
        return '"' + cell.replace(/"/g, '""') + '"';
      }).join(',');
    }).join('\r\n');
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download = 'asrar-messages-' + new Date().toISOString().slice(0, 10) + '.csv';
    link.click();
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    if (exportStatus) exportStatus.textContent = 'تم تجهيز ' + new Intl.NumberFormat('ar-EG').format(cardsToExport.length) + ' رسائل للتنزيل.';
  }

  if (exportButton) exportButton.addEventListener('click', function () {
    exportCards(cards.filter(function (card) { return !card.hidden; }));
  });
  if (selectedExportButton) selectedExportButton.addEventListener('click', function () {
    exportCards(cards.filter(function (card) { return card.querySelector('[data-message-select]').checked; }));
  });
  if (selectVisibleButton) selectVisibleButton.addEventListener('click', function () {
    var visibleCards = cards.filter(function (card) { return !card.hidden; });
    var allVisibleSelected = visibleCards.length > 0 && visibleCards.every(function (card) { return card.querySelector('[data-message-select]').checked; });
    visibleCards.forEach(function (card) { card.querySelector('[data-message-select]').checked = !allVisibleSelected; });
    syncSelection();
  });
  cards.forEach(function (card) {
    card.querySelector('[data-message-select]').addEventListener('change', syncSelection);
  });

  search.addEventListener('input', function () {
    cards.forEach(function (card) { card.querySelector('[data-message-select]').checked = false; });
    updateMessages();
    syncSelection();
  });
  sort.addEventListener('change', updateMessages);
  updateMessages();
})();
