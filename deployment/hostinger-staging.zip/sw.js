self.addEventListener('install',function(){self.skipWaiting()});
self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim())});
self.addEventListener('push',function(e){
  var d={};try{d=e.data?e.data.json():{}}catch(x){d={title:'رسالة جديدة',body:e.data?e.data.text():''}}
  e.waitUntil(self.registration.showNotification(d.title||'رسالة جديدة',{body:d.body||'',icon:d.icon||undefined,badge:d.icon||undefined,image:undefined,dir:'rtl',lang:'ar',tag:d.tag||'asrar-msg',renotify:true,requireInteraction:false,vibrate:[200,100,200],timestamp:Date.now(),data:{url:d.url||'dashboard.php'}}));
});
self.addEventListener('notificationclick',function(e){
  e.notification.close();var url=new URL(e.notification.data.url,self.registration.scope).href;
  e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){for(var c of list){if(c.url.indexOf('dashboard.php')>-1&&'focus' in c){c.navigate(url);return c.focus()}}return clients.openWindow(url)}));
});
